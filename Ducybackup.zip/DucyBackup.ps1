#      ____  
#     /\_\_\ 
#    /\/\_\_\
#    \/\/_/_/
#     \/_/_/ DucyBackup, a wrapper for @gchen's Duplicacy CLI https://duplicacy.com/
#
# Copyright � 2021 Arnt Marius Bakke
#
# (Test edition)
# Requires:
#  Powershell 5.1 (inclued in Windows 10) or newer
#  Storage for backups
# Do not use if you do not have an arangement with the author
# You are NOT allowed to distribute *this* (version of the) script. 
# Please check github for a newer version:
#   https://github.com/akvarius
#
# Note: 
# This script is a helper script (wrapper) for Duplicacy CLI by @gchen
#   1: Duplicacy CLI is 100% developed by @gchen. Copyright � 2017 Acrosync LLC. https://duplicacy.com/
#   2: Duplicacy CLI is free for personal use or commercial trial.
#   3: (Except for restore) Duplicacy CLI is NOT free for commercial use, including when using this script. See more at https://duplicacy.com/buy.html
#
# In addition to this script and the Duplicacy CLI, you will need one or more reliable, long-term storages.
#
# Specify a location for your backup sets ('preferences' and repositories)
# You can put it where you want, for instance %LocalAppdata%\Duplicacy\BackupSets
# This folder will have one subfolder for each backup set.
# Note that the subfolders will also store cache wich might be quite big.
# If you change the settings folder, configuration files will not automatically be moved, 
# but you could copy them over manually if you want.
#
# This scipt (DucyBackup) is created in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
# without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

<#
The script DucyBackup relies on Duplicacy CLI (https://duplicacy.com/)
The lisence for Duplicacy CLI can be found on https://github.com/gilbertchen/duplicacy/blob/master/LICENSE.md
Rendered here for convenience:
Duplicacy License:
______
  Copyright � 2017 Acrosync LLC
  * Free for personal use or commercial trial
  * Non-trial commercial use requires per-computer CLI licenses available from duplicacy.com at a cost of $50 per year
  * The computer with a valid commercial license for the GUI version may run the CLI version without a CLI license
  * CLI licenses are not required to restore or manage backups; only the backup command requires valid CLI licenses
  * Modification and redistribution are permitted, but commercial use of derivative works is subject to the same requirements of this license
______
#>



# Possible console input code
# https://stackoverflow.com/questions/1655318/how-to-set-default-input-value-in-net-console-app
# ... schedule task/storage   prune...
# 
# DucyBackup settings in repository\.something ? (settings for copy/jobs/etc)
# a small settings file in %programdat%\DucyBackup  ? How to find a computer backup if different user...

# Wrapper for Duplicacy CLI (copyright gchen)  
# Manage symbolic links
# Init and Add storages
# Other duplicacy commands

# position of the cursor:
#https://stackoverflow.com/questions/25846889/powershell-overwriting-line-written-with-write-host


#https://stackoverflow.com/questions/57181091/how-do-you-check-if-a-powershell-variable-is-an-ordered-hashtable
using namespace System.Collections.Specialized


Param (
    [ValidateSet('Run-Elevated','Job')] # 'Task',
    [String]$Command,        # Used for running an elevated command
    [String]$Path,           # Used by create-symlinkd and -Task
    [String]$Name,
    [String]$Target,         # Used by create-symlinkd
    [switch]$Force,          # Used by create-symlinkd, allow overwrite existing symlinkd
    [Switch]$Debug,          # Used when chaining, to keep debugging
#    [Switch]$EnableTest = $true ,     # To enable a test
    # [ValidateSet('Backup','Run-Elevated')]
    [ValidateSet('Create_SymLink')]
    [String]$BlockName,      # Name of a scriptblock to run elevated
    [String]$Inputstring,    # Input to blockname

    # What's needed to run a task?
    # repository path (could use registry but let's not in case we runas admin)
    # task name

    [String]$Job,             # Name of Job to run. Also needs -Path to point to full path of repository

#    [String]$DuplicacyPath, 
#    [Switch]$SelectRoot,
#    [Switch]$Interactive,

    # LinkType? (file symlink, dir symlink, hard link?)

    [switch]$Install,        # USed to install DucyBackup.exe and Duplicacy script
    [String]$InstallExe, # $DownloadFile,
    [String]$ExeDestination, #  = "$($ENV:PROGRAMFILES)\Duplicacy\duplicacy.exe",
    [Switch]$InstallScript,
    [String]$ScriptDestination # = "$($ENV:ProgramFiles)\DucyBackup\DucyBackup.ps1"
)


If ($Host.name -notlike "consolehost") {
    #Set-PSBreakpoint -Variable "Task"
    $ISEHost = $True

    # $_Debug = $True

    # $_DebugInstall = $True
    $_DebugNoInstall = $True

    # $Job = "ceXXmmmmm"
    # $Path = "C:\Users\Arnt Marius\Documents\TestBackup\3"
    # $Command = 'Job'


} else {
    $ISEHost = $false
}

# $_DebugNoInstall = $True
$ScriptVersion = "0.0.10"
$ScriptDate = "October 10, 2021"


# Also update $ScriptVersion
<#PSScriptInfo
.VERSION 0.0.7
.GUID 3899de25-825f-4db3-93f6-b97b31613995
.Description A wrapper for Duplicacy by @gchen https://duplicacy.com/
.AUTHOR Arnt Marius Bakke
.COPYRIGHT 2021 Arnt Marius Bakke
.TAGS Wrapper Duplicacy
.LICENSEURI https://github.com/akvarius/Dcy-Backup/blob/master/LICENSE
.PROJECTURI https://github.com/akvarius/Dcy-Backup
.RELEASENOTES This is a test version.
#>




$_Debug = 1  # Allow test without installing

If ($Job) {$Command = 'Job'}


$TaskPath = "\DucyBackup\"

#  [OrderedDictionary]

If ($host.version.Major -lt 4) {
    Write-Host "You are running an old powershell version: $($host.version)" -ForegroundColor Red
    Write-Host "Update to Powershell 5.1 or newer to run this script"
    Write-host "(This script is not testet on Powershell Core (6))"
    sleep -Seconds 5
    exit
}

$Scriptpath = $PSScriptRoot    # PSScriptRoot is a system variable but not available inside a script block
$ScriptFile = $PSCommandPath


Function Breakpoint {
    Param (
        [String]$Text
    )
    $Line = $MyInvocation.ScriptLineNumber + 1
    $Script = $MyInvocation.ScriptName
    If (!$Script) {$Script = read-host "file path?"}

    If ((Get-PSBreakpoint).Line -contains $Line) { Return }

    Set-PSBreakpoint -Line $Line -Script $Script 
    Write-Host "$Text Breakpoint line $Line" -ForegroundColor Yellow
}

# ScriptLineNumber returns the line number where a function was called. So need this to be a function 
Function Script-Line {
    Return $MyInvocation.ScriptLineNumber
}




# Set-PSBreakpoint -Command "Breakpoint"

<#
# Try to read from external file. Appears this does not help with breakpoints in script blocks
$Func = "$( Split-Path -Parent $PSCommandPath )\DucyBackup_Func.ps1"
If (Test-Path $Func) {
    Try {
        . $Func
    }
    Catch {
        Write-Host "Error detected in func '$Func'" -ForegroundColor White
        If ($_.Exception.CommandName) {
            Write-Host "Command with error: $($_.Exception.CommandName)" -ForegroundColor White
        }
        Write-Host $_.Exception.Message -ForegroundColor White
        exit
    }
} Else {
    Write-Host "Not found: $Func"
    $Func = ""
}#>



#https://powershell.org/2019/01/clear-host-deconstructed/
#PS > (Get-Command -Name Clear-Host).ScriptBlock
# hastable works better in PS5:
<#Function Clear-Rect {
    Param (
        $x = 0,
        $y = 0
    )
    $RawUI = $Host.UI.RawUI
    # $RawUI.CursorPosition = @{X=0;Y=0}
    $RawUI.SetBufferContents(
        @{Top = -1; Bottom = -1; Right = -1; Left = -1},
        @{Character = ' '; ForegroundColor = $rawui.ForegroundColor; BackgroundColor = $rawui.BackgroundColor})
# .Link
# https://go.microsoft.com/fwlink/?LinkID=225747
# .ExternalHelp System.Management.Automation.dll-help.xml
}#>



$Title = "DucyBackup"
$TitleLong = "DucyBackup - (Duplicacy wrapper)"


$Top = ""
$Settings = @{}

$AppKey = "Registry::HKCU\SOFTWARE\DucyBackup"
$DuplicacyPath = ""
$SettingsPath = ""
$DefaultSettingsPath = "$ENV:LocalAppData\DucyBackup\BackupSets"  # ...\Duplicacy\BackupSets"
$ThisRepoPath = ""
$Script:Repositories = @()
$Script:SelectRepo = 1

$Script:Storages = @()
$Script:SelectStorage = 1

$DefaultAutoListUpdate = $true    # Set default for dialogs. 
# If $false; for exception actions set $UpdateList=$true or $NoUpdateList=$true, for exception dialogs set .NoAutoListUpdate=$true


# Ask-Dialog parameters
$Script:Parameters = @{}

#$Debug = $false
#$Script:Debug = $false


# Color scheme (not completely implemented)
$Color = @{      #foreground                         background
    Title     = @{f = [System.consolecolor]"Yellow"; b = [System.consolecolor]"Black" }    # Title
    Text      = @{f = [System.consolecolor]"Gray";   b = [System.consolecolor]"Black" }    # Text/normal
    List      = @{f = [System.consolecolor]"White";  b = [System.consolecolor]"Black" }    # List items   
    ListSel   = @{f = [System.consolecolor]"Yellow"; b = [System.consolecolor]"Blue"  }    # List selection
    ListSelOK = @{f = [System.consolecolor]"Yellow"; b = [System.consolecolor]"Darkgray" } # Opened a sub menu
    ListCur   = @{f = [System.consolecolor]"White";  b = [System.consolecolor]"Blue"  }    # Selection marker
    Field     = @{f = [System.consolecolor]"Yellow"; b = [System.consolecolor]"Black" } # 
    FieldEdit = @{f = [System.consolecolor]"Black";  b = [System.consolecolor]"White" } # 

}


If ($Host.name -like "consolehost") { 
    # https://en.wikipedia.org/wiki/ANSI_escape_code#CSI_sequences
    # Define colors to use in ANSI formatted output:
    $e = [char]27
    $a_BrightRed =    "$e[91m"
    $a_BrightGreen =  "$e[92m"
    $a_BrightYellow = "$e[93m"
    $a_Reset = "$e[0m"
    $a_ColNotScheduled = "" # "$e[95m" # BrightMagenta
}


# Get/Set default settings.
Function SetDefautSettings {
    # "$AppKey\Settings"

    $Settings = Get-RegistrySettings "$AppKey\Settings"

    If (!$Settings -or !$Settings.Keys -or $Settings.Keys.count -eq 0) {

        If (!$Settings.SettingsPath -or ($Settings.SettingsPath -and !(Test-Path $Settings.SettingsPath))) {
            # programdata\ducybackup_global
            # userprofile\appdata\Ducybackup
            $Settings.SettingsPath = $DefaultSettingsPath
            Set-RegistryValue "$AppKey\Settings" 'SettingsPath' $DefaultSettingsPath

            $x = New-item $Settings.SettingsPath -itemtype directory -Force

        }

        If ($Settings.CheckForUpdateDays -eq $null) {
            Set-RegistryValue "$AppKey\Settings" 'CheckForUpdate'              ($Settings.CheckForUpdate = $true)
            Set-RegistryValue "$AppKey\Settings" 'CheckForUpdateScript'        ($Settings.CheckForUpdateScript = $true)
            Set-RegistryValue "$AppKey\Settings" 'CheckForUpdateDays'          ($Settings.CheckForUpdateDays = 60)
            Set-RegistryValue "$AppKey\Settings" 'CheckForUpdateChannelLatest' ($Settings.CheckForUpdateChannelLatest = $false)
        }
        $Settings = Get-RegistrySettings "$AppKey\Settings"
    }

    $Settings
}

 Function FindDuplicacyPath {
    $Settings = SetDefautSettings

    If ((!$Settings.DuplicacyPath) -or !(Test-Path $Settings.DuplicacyPath)) {
        $DuplicacyPath = ""
        $ENV:ProgramFiles, ${ENV:ProgramFiles(x86)} | ForEach-Object {
            If (!$DuplicacyPath -and (Test-Path "$_\Duplicacy\Duplicacy.exe")) {
                $DuplicacyPath = "$_\Duplicacy\Duplicacy.exe"
                $Settings.DuplicacyPath = $DefaultSettingsPath
                Set-RegistryValue "$AppKey\Settings" 'DuplicacyPath' $DuplicacyPath

            }
        }
        If (!$DuplicacyPath) {
            Write-host "Could not find Duplicacy.exe" -ForegroundColor Red
            Read-Host "Enter to exist"
            exit        
        }
    } Else {
        $DuplicacyPath = $Settings.DuplicacyPath
    }
    $DuplicacyPath
}

#region Update


$VB = @"
' SYNTAX
' filename.vbs [/winstyle:n] [scriptargs[..]]
' /winstyle 0:hidden, 1 normal (default), 2 minimize, 3 maximize. (See vbscript help for more info)
' Other scriptargs passed to the powershell script
Set objShell = CreateObject("WScript.Shell")
File = Replace(WScript.ScriptFullName, WScript.ScriptName, "DucyBackup.ps1", 1, -1, 1)
WinStyle = 1
Set ArgsNamed = WScript.Arguments.Named
If ArgsNamed.Exists("WinStyle") Then WinStyle = ArgsNamed.Item("WinStyle")
For Each NewArg in WScript.Arguments.Unnamed
  If InStr(NewArg, " ") > 0 then NewArg = """" & NewArg & """" ' protect it with quotes
  Args = Args & " " & NewArg
Next
command = "powershell.exe -executionpolicy bypass -file """ & File & """ " & Args
objShell.Run command, WinStyle
"@


# https://stackoverflow.com/questions/66934993/converting-to-and-from-base64-in-powershell-5-1


[String]$DucyIcon = 'AAABAAEAW1sAAAEAIADnHAAAFgAAAIlQTkcNChoKAAAADUlIRFIAAABbAAAAWwgGAAAAHDb5mQAA
HK5JREFUeJztnWuMJNd133/nVlV3z3TPPmaXS5ErKSItyVJIU6ANLfUwHcoIJFuxJdu0TcJBbEQO
JcBIAucB5wFDH/IxHwwEcaTQMhzJcmAnfsRJHImSX5IiOebKkkxZJuNI1oqkKWb52Nf0zPR0Vd2T
D+feqts9PTPdvbO7EpCzKNR0b916/O+pc8/5n3Nvy2Aw4P/L9ZH8Rt/AlKwCtwAvB04DNwMngWPA
AFjB7lmAGtgBNoErwAXgOeBZ4OmwvXh9b39/udFgrwK3Ad8KvDr8fSsG7hFgLRyzAnSAAnAY2B6o
gBIYAVu0wF/GgP4a8BXgL4AngIuh3Q0RuQFmJAdeC9wJvA54JfAyDOQTGLCHIR64hGn6M8BTwGPA
l8J2gesM/PUC22Hm4E7gLuD1GOCvwszD9RDFNP3/AJ8HvgD8GdYJW9fjBq412DlwCgP5XuAMcDem
we5aXvgA2cRA/xPgj8L+XPj+msm1AtsBxzGQvwv4m8AbMZv7jSQ18FXgE8AfAmcxTS+vxcWyTqdz
2OccYHb4rcB7gB8Ln7OZR8fhLm562LezrzjsLbsLGz+OYNo94hpo+WGCnQHrwJuBh4B3YSZjtja7
8D9doBf+zsNZHG3XRGMjh3WbMyXDxpTXAXeEz89itvzQBtHDArsLvBT4IeAfAW/HtGT/FiugK2rO
XQBbnBiwEXSl1fpFJH1j4nkOlg7m478JM4NPA0MOyawcBtgdTIPfA/wk8Jq9r4Zp8QD0iLb7PtAF
6Uir7SthX1g7QXabHKb2Edgs3FXqmcdOmw/0Lq2WXwS+Doznbr2HXC3YDhv8/inwDszz2ONK2MP3
QdcUjthe+wHsaEbycFxiWkRkQsOF5DPsBrpQ6ErbWdN+z3yQZcArMA9qBwuOtudquYdcrTfyAPCP
sQGmy14ve47FguvAcUWPKb2fycj2eGo9K/gzXNP/336vzmuNFdPufw+8H/iruVrNkKsB+yeAf4KF
2gX7WdVVDOibgZsVPan4jqISntaDloqWmA5VoKoWjI9BdgS37exFHoOMBXzQeDA4PIgH7QAdRQox
++8x32JDrH0Vtjrs5wf8CvBLwPswLV9YljUjPw78DMZndNgL6AJzBE8AN4PcAnITyLpAX21wDAOk
dhW6ihZhyxTNFXLQ3P7WQqEIx66CrpoZ0r7CwMYAOaKwBm6V9l2TZNDNpLXhqTO6v2kRzLC9Opz1
SeCFRUFbFOwC+GHgn2MavX/jDqbVJ0BOGtDuuCBHgFVFe4r0wmMUBqjPFHXa2GDNFbIpwDv2yNpT
fM+HjrJryap1oPQEKaDRg1yChzOlF3HQnG/wXMXseI55KgsBvgjYPWww/BfAt3FQNJiDrIIbCLIu
uGOCe51QXBA4bg+ea07v6ZzqVA1o87AKBnRm5qDxLALIdEA7yuDeFVbzgu1hCT1FVxV6gqSeTW4d
IT37TgoQB6iQ/7TQuU2oHgsXnW/g7GOkWY1FmxfnBXBesHuYe/fTGMdxINAAblWQFXDHBP80dB4C
nnNIF8iF+kOQPwh15dHwtIqiAho9i7jlNN6JhregeKRD/iBsf3mMdkGjB9Ox4yS0kRxcEzRJo8X6
mJA/CNXHMNs9n/0WLIZYx6LMJzFf/ECZB+zoAv0k8APYq7S/OJBCcCuCdAW36tB7lOwJcL0MCf6v
3KNoTyh+O6N6tQc1oIFkr61LFzYJdnd865jubR1Wv9hhezA2rc/CG5GbZmsEPXwnBSBieJeKvFko
NoT6yXDv82m3wzj3PpawOIcNtwc2OkhOAN8DvJODosIgEkFxFhE6JxT3Q/0JyMThRHDOQKv+E7gH
7DgtJGguEAfIqNWJdmtH0Y7Z7tie3J5GnQ2uPrdNOz4cbwOr9hRWbZOVqfaLSQ/4dkwBv22eBgeB
PQDuwbyPly9yJ+Ls7JLB+M4Kdxb6b+uRFY6scKZ5OWTvrPGnofO+DurEzIfT3dFiak6CpqtThqeH
+NNw7NGBWVHsrfCZN7BDB5AnW6EWoa4AT3v8aSheuhT5cgx4C+Y03HrQwfuZEYd5HH8P+N5F7kC6
ZkZkILiBQ+5X+Ch0XtpBBuZFaOENEPXUf+jo3As7eYl6j3oMuP0Grfi9h+J/d+ncC1svjhvtJhPz
+DTpMwVRgUpCQs32/orQuReqT7EM7bSGgf4s8Ph+Z9hPs49jhMx3L3x5Ac2ALoxvrsmB1dtXyPoO
1xOkA5oLXpRaFf0E6BlAFbyYau5FPqWhedja9iEY8qC14r3isU3DadUpKoondkrSfnl5OUZX3Lbf
QXtpdo6Zj4cwL2Q+CbyGHBXcMchvzuAtinscuse7ZAOBHvjcU4vHU1N7T/ntY7JzBSvnCkbHx6bZ
cZvWbp3aPIxPj+lsdxlsddiqxrv4cdNuh3hBfNDsUpBSYEfMpzgldL5FqD4399Om0sXGs20sAVHP
OmgvzT4F3Idx0/NLDtIBtwbumGN8viY/A/3jfbIjznzdTAOZpODVPBCF+tMgb6AFOgKcavgs4MM+
to8dQDRF5uSYS6nh/OHJlfAmqLbtl5eXYIPlX9/rgFlgO4xevI953LxEpAMMBDkiyDFB7gM5Czrw
+BVPXXjq3KOZ+dFxT6aM3rpFBRz71KA1E7NMSQSzpuU3FDZu2qACTpxfCzyJILW0x4yBUtFS8bXi
VVEN3r0D/ZxSAd3vWTpLkQN/DRssZ2alZoF9AgN68X4OUaP0BbcGxf1QfdgSBHW3xheeOlO8KN4F
8xzsJpm2blh4XnHs1mqlBTASSUFbGzdSpe2M0jYdKz5utQFttlwbKqC5/vKp6BPAjwK3z/rPWTb7
zcCPYHnD+SWSTgNBToCcgOzZjOKeDN/z+I7HO493Si3BZou3AUxMw8rbS7Y3xkF7jbOOdlbC5wlb
no77CuP+mK2vjg3s0Cmm4UAlaG0DJ2BmxLdtRQSegvJ31NoLy3gm8V28BHx6+j+nXfkcGxDvWvgy
gfjXXC107kLdqfG5vaaCIsEj8OLxUbOiFkXPImjz+hsH+/LRz//VxuykQNjWf3z/9hf/dNvMXug4
Lx6H+f/qFNmRRUL4VAaY7f45jDCegCiVO4DvwOL++SWkrizoUGqU2quZXTGtaayBKjWm0RU+/KUB
lgCOwIWzG0jQxqbILPLcnjZHmQ6G0QfwcOGDRleIl9YURbOkmNckgmRiMUEgrqRrn9kMbaMpml9y
rPjorcAjaetpsO/CApnZZQcHiUQ6yQD0asGgKMHJNRtZq07ArOYW7A5kphO+6eeo1RHsVMsTylSz
lq4lY3IMyIzUch0HuUWdLndt4rnCEg/Bq5kXBcyxeAfw++wB9ioW68807vtKPF0pUFlgIoEy9T6A
6D14mkEpBbrR1qChmoJN+33zd9ohMzwWVW01Og3144a118KO82ULss/tb0WhDPnOqN3zA15gUfe/
wrrLp48DFv28Egs/l5L8p4SVNzlcLbgqo7NWsPpkB/UGuveKJvtGo8NgdmR7wPq5kKZzcIQBJ54Z
tCBN8yVu/+3oawec6A/a79KalGSMoRtIqkBUxa14t6P3I7KrM+cQh3Eld2MBT/NllDuYg0zZS+R2
IT8Do4973FjIS0f9YcyBjBpbB5C9NjlDvJmZ/vsH5GfgxduGQRulbb8X2Ex9TjpARdv2bkb7NNwP
DKN2QtqtMOCb9pF1XBASzLPrxS9SsF+DpWQXl6Mg9wG/CXJaLFzvCdn3KzWw+vsd0+xK0UonA5IQ
eMT28bWXTNh895AaWP/MoAGrSfKmtnf6EbHjhq8P7Z8ZTEalM45PgacACqjXamqg+52yrO99DzPA
XgG+BXPKF5PCWke+Wm4Btw5ZX3BFy1f7Sk2za2yrsGx6BepbvnuCSk347kYzI+CzQI5ARz9bE746
9VZmtFOx3GfMc8Z90345uQPz7DJowb41bL09Gu2WFZryBPdOwZ0FfRO40+BOitEyXZB7K/xpWPvF
VQO5DFsVNg+Dx/u4s3D5p4ZIB8um5IrksPV9m8ZX/8qgjSgTkmmaC5EqCdFr2FwP7T8TxoJZ5NY+
40B9zvj24hVLhfEnsbGwCy3Yr2DOLEwjfZpMXPYG8J8Gd5PgbhJkHWQN67oMyt+E/O9gdrsCDVpO
bWRUbI+TkLqSJofocmnbJ+G7qCCE6FKTKDN4DlIHbsS31081fmKLSDSBlU5cq7n+cvKqgEQD9suY
1wsJYbkeU/QmRW4VcsDfwcQMGF1VWLEyg5YvtoeXyjY89H93QA5cevumBRlOcJngnEOcw4lr2rtM
LNUG7YyaCovTtm2TkbTaHZIFzfWT8HxmYiJot4gkpWwJ371cdfntBLAjN/K9WKLg6IFNV0PTE8Ax
yP+G4B4HXQcZMFUD4qmdp/qOEneuoP9kwehoidTtuLTysg7ucdg5VeIC0OIssnMiOAR/psZ9JWf1
6Q47axU6NnMhgZOWHUHG0gAtddD6UJxT3lpSlAX9YYeRT8LB1M7Tvh1SB657jO03QF4S+O4vMHug
3VueBX4PuBQ1+ybmnTjUoZkg555x5GdgvGLJVy0CwJm3BEEcbDoJ3yzhKb3Q/5C5exdfs4k0/zCQ
JQAftti+EEemAjsgW4IMw7YpyHYAWw1okdbENNcPADba74N5mRUsxYE6vf/F5ZaAWmNGjrPA4BhD
4IavdmrkkhizVztP5WoDPbMqp63v3wx8dT+cpG0vTTYlaJhYuGx7EFH8942pgNVHezgvZFXQ5K0A
8ri10Q1YBNuuwvbRbSrg+Pl+Y35SNrGx56GtiraVWIXiv+iN737rwgPlSYIBimCvcVApWZQaY8Tq
hK8et4R87ZTa+XYfwJ7gi0NnxfYx79g6BdKW6AXgXeIGdsSR43DBdYwAi5PJAChyKYErSfnuxlzE
JEMEPHokMbpMqrGWdAOPhTtqqlj/B/A25omTQgmA3qKwDnpK4ZQitygcU+o+kHvTdkJoHitSQ5Wq
bNMENFIAHcHl5pe73DbJAitHsJ+l4LaMjfNXKspLNeUlxUfmQSwQ0tzqRpoC+vB/kQVSaZnFpmMS
ZY1vhxs5e3M2BHfZIZcEuSjLzEMYYZHk5yMRNatkfLZU2Kh/yR6MdXsA70JBZCCaiEST08C+0bJz
jVulQcvCnmBOvJBhnohT14T0pnlKKdB7oEd/H776wmNbRiZFUFMtVzj2d1f35bsvfXGEpL2wVwR6
sDRVvhHsGdzZHhJ7dYemlnpWjUfzp7Qf4tg4EZDUWGWpAyob1MwLaf8ZjxJZQo8XZfRftimHio5p
I0OhBTi9/oxA6OIHN9v5O2mw5E27Xe3MXw9eyZ4R6MHS3E0EOzK282l3BFzD36XgKjV2L2TLNXDb
DdCR1yZQqGlaq8QCGifmW8eygwA8XkPW3eOlphJPlXnLCLnk7uP1ptNn0x5G+P9dHRPeqrQIn1HY
j5mkeueXqIoN2Dvhy8XoFm8tZQSMJWRTBHEh3RUfMmqFN16k+V4D8D7wJuKJXpg4aew+3rbae8qq
olZvY2oRor14ziQ3KVVLHjURYTQnYDYe2dU5UgXPZqf1dJo3eDkzsh1bxktvsqjZz6D4CcfqazLY
EnQkaLypiaRsGyysvThg/YlBSBjAkd6A4+f7xgjWfmKrvSXPLF/pqeuaus7onO9R+TBGRIauh7EP
ccJSpEljYX0A+ujtA05kg8a70K7Rqpppa9NrWpdyKAbVjnVC/i+F3kMLu34bAZUG7MtMJScPlBEt
37sFbCpsg98BP46Ek/EfWsPqz/XJz8CFVw2bzmjaYw+qHnMhgwej6q0j1DP+gAVQVwabTdZ8wt6m
mZjpZIGDwWcCX54Pdx+Xvs9J+QM72Pyd0iLI/AyMPrCwel9gCuwXDb4FZAz6vPHVKy6DoaBbdhbd
CZORSmkStQ1fnQw0wx81vvn4ZwdtNkeTrdag1dq0r3cEX9L4zmk+UoNHNEEkRVo2Xj8FeYrla0L2
ujUlRGogtl882/4cwWpEsM+z6DIQYRBpHP24vMqW2t9x1lcNeG35bo0DIUjWtjdfQ/Aeaq/UtVLW
nnJcU+5ULd8dOstYQxo7qqKzaVPsmKZ9evy0p0J7fLMP9rxpv7g8Y0i1YH+dOacqNFJiD/0nij8N
vT/PzfJvWRhtGmGv++DPBrizsPFuY/ZcRhO8bL3Z+OajvzYg+AdoGAzruqaqKvKvda3927ZaVzMZ
F9Rrq+nQuIAaks5rXbv+pbcMmzbSTG3Y/WhNQVCw4e5vG19ffnmpEfJJgol2yRdXFj5NBWwmfPEw
8BTB1kkpuEoavjrLHFlXcN1QOtyzeo0Jvjp4ILX3VLWnqnzTPpaNpe5cA3TqSsIE39Hw5Wk8kLqE
0YOJXElaReuT9sstGfCXhJnBKdiLr58U01qfML5XNsMoPnK40pHVwsrHVsmBzb81Mp46E1xHkI7D
FQ5XtHyzxFkFYv66r5TVT/bJgYvfutm6jyFhvMuXjoAnoA5eML78wkuGk/53mt2JiYayfSYJ4417
gyMHdj62lFZX2CIyI2jBfh5b0mdjmTPqeaU6C/3bctyWIxsLWS0478i+E/SPIZOQEAiUaQN8Luy8
Z0R1Fo6d69t8nCRBENtHs9Voo0+0OgUvmJnIcTTtkxLi1O/Hh3OHIEZGiW+9k7RfTr6GzZecsNlg
PXB+qVNqy/e6HcGNHdnYkf9yl/wM7Lx2jFObuJSJI3O25Zkjyxx57tr24nBWEMjgV8xdu1BsNlOh
m4KeVIvTqtYItMLgs8Hd2xhOdkY8rmy9Drft7K3caoMZd4u5m6NfmBp855fPknh5KdhPAP93qVN6
0C9ZfXOvzAzs0rV8tXc4hEwN7FwceZaRZRl5lpHnDt5eUgFrv7uCU9e4W3IW07IYLicmQ2ppwYus
YqK1TXuhdenq1rWz6DeMM5uC23DIhjF9bCXtlwMa4H+xB9hfwtyUxU4dH7Bs3Tg3Mu2OfHXmHZk6
MnJyycldTi4ZuTPQc2egN3xzKPNt+O7UfERJbfeUhxI5j6Z94oujtMmD0syG23K4TddkfBjZAN+0
X0488CmSZTPSVRkybJWFv48lgOeXMM1ZTmJTp28Bd0rguCJHQFfAdaWdkhc5ZIkVUhZt+tJTlzXl
2LOzWeG31HykFMSUWfTRJUnuJeWmk3nqaSYmFstHsLPLGXLFeGs2baCPA+WSUmGrqv0AVqs9QUSB
6cZjmKuyGNjRZm5hpbhDq4iiEzyPAptC7ZwNfs6eWkTwIhCiPi9KqZ6yqvGlmo2OM3yTAAWF9R87
oH77LzdQ0aaCqim2DJp97F3789nb713edmBd9TskJBTsLhn+U+CL2Oox88+niXzCtjFtsipI7pAV
wa3aZxdpVwcqRmFbYtYiRxsTldKbb228Cm0ojraOaQ0v/seNSZcvdkZaPBlq/iK7p17Nzgtc/sC2
mY8rDnfBIRcD8TQiVOLOj+yUeMzR+K9MkXvTlOrzwOewudiLSQU6UnQb/KaaCYiZ7Bh3JKXB3gfw
VVHvqeqKcVXhxx4da8sbh5m8+5JHUVKuZNYW/y8Mrin/MWuOzpKyDfxPzEJMsN/Tt+wx7f7CUpf0
wLZlT/woFFF6mqlxRjD5wOjZ7IRaldrXlHVNVQbzkdRCxyz3BIhTecNG0mMS4BseJH4fI8a05mSc
eDbLi2IM6m8xI80wSz++irksTy11tbhERUcp764oqzEVNZXW1Op3b76mqmvq0tMfr7IeSw2mc35T
xNKu7wSOvWqNk/na5P8pTbHOrnNN+er5e4Xeexbmq1PZwizDrslLMBvsIfDHocFi/SxYCUCm+KKt
b658TVV76tpT1QZu5QP4dU1VeYqHexbADDabqqaU3wAmadUppm7t0TXyM/BCtTHRSU2JMe05Jopy
AtBya+CrH156YPRYnPKf2WOFnb3SYF/G1iddTLuTwUkzRe42vts9CtW4phrXBrjaNOq69NQl+LLl
m2NJGVVIbUWCKFQ5TTsQsQinaR8/hy0NhJrvYrVr9M/T+vDlZYhp9e/tdcBeYG9gfuIjLLKWXZpn
HIMv28IcP1bqUqnHHl8pvvLUlcdXHj9O+O6RNIwhVRt6N3Z2Fpgp35wye2lOMla4hk6MoXr0p6+C
r8bOwJeBX2OfKHy/JTCuYIHyndiS+AdLht18rELpgZ70ZPc63L92VHfW5oEIzcQlXyrdr/YohrBx
046FySNph+eQQZkof0gYOzysHRlQDOGi22xrPRIzE01RBNiNHG7LIka34ch+0FEMYefXlzYhzwG/
jS1Ft2cudz+wa0yru8y7HLNnYgEW7YN2ga/ZeiKjcTJAh2J4RkL3jhw+CmXmLYIby4QvFP3kiSrT
OhRRVsLKd3fgo7CTVcSseVNUGbS/yZpPh+dDoXiXwEehXmq1PkqMcHo/5lzsKQeVLnwd+A0Wzb6F
EgfGtm/qm8MiiJanNL+8+0dd47uPl8gLodRrU1pzEreq/TueV8ZCf2h89+Vsuy0hrpJ9WpqwnbB6
Q9u71we++pGltFoxTulDmAe3r8yzMtJTwMPYtL03znULkRTaAUZQ3V2Rnc1Zu9Rh4+g42E0DK/LF
8oIgl8Vyiw6kI+3srUzNy4mjY2JGsu8K7XfMZshYmiL2GBCJD4mA7dCRwzZavEq++inMp/7IPAfP
A/YYW47nF7Blmw/mTSLYo0Dq9IzvLh7Axmtndrn4ZEH+b2H7v3nclUACOWnqQeIKlU3oHbLmkZDq
XOiQn4GNj4ytTC2K0HSS5NIGMJuCu2KAswHuJYGv/tmltPoi8HHgv2Nk04EyD9gxKnoEA/ufYTNq
Znv/ZTjrZtBOjAyq12oqMgZf6bC1VtkrfV/gi58Lg+JO0MRMwuppMhE9NitZhs+xvbviJr2PAHYD
eEh5yXar0bKTXH9x2QE+iXkfTzCniZ13gTWP8Sa/jBV3P8R+RNU29rAXDUQdK7Jp9dW9B8C938EQ
in8I1T8AeSr0m6MtdoRdLlwTCYbl5or7Q/tNaRMJNXZMmAkRF79tkgVbrQsY2y8oHuM+/gO2RNF4
3oaLrjLsgFdg2v0gB80wi6tEhoXHtReo1SoMcpuYjpS0Q3VSizcRsqcheuQ/wtrGjV1Ojw+BVROy
x84op867mCiWEPh5wjyZRRovunSgx9ybfxM+34/NhtzbpJQ0YZHscVhzZkfzQnYfkf355p/VRqdm
nbf7cdmzsr9pv5hEjX4f8AcsCDQsrtmp3IUtvf8ObJLOcstmfHPIGAP6YUyj517sNpWrWYb/PLZK
usMm6h3hxv9W2bWQS9i6IQ+H/cIaHeVqf/PgPOZr7tCu3Njdt8U3j3is5uMjwAcwW71Yid6UHMav
ecRfp7uApX5PYK7hN7OMgT8HfhX4IBYdLFZSPUMO63dqNrDfAXgKGyzjvMpD/3mnaywV5uJ+HuM6
Pow903KzaabkMH+BqcRu7EvYDfcwO77CotNHrr94zET8BZao/XlsuuJiNesHyLX4bbHL2E//fQHr
gJO0C+hfVc7pGohigD6LeRv/DvhFDmDvlpVr/ROFK5iL+CC2MOPR8N2NdhM9ZpeHWBT4q5hLt1z5
3ZxyvX58M8eWsHsAC4Ruw7Q9Lb+5HhL5wuexnyT8dSzXuvDPoCwj1/NnZWMRQh9b1v/t2EKDp7g+
gMcI8BGMqTuHeRjLB+8Lyo34DV/BBs8eBvTd2Jyx+FOzxw/pOiVW5P854FHgM9gAPiTUPR3SdeaW
GwF2Khlmw/sYixjXVHoltjzyS7EV2U5g9j7+mKHQpu2GWPgcfwb8KWyA+woW4cZfrR5yNVNHD0Fu
NNjTkoK/QjudNPzyTFv/Slv1Ebm8kCxjmzBvjUMIRA5TvtG4jBrTwKsKi79R5f8Bg0XnjwZKcq4A
AAAASUVORK5CYII='


#https://stackoverflow.com/questions/9701840/how-to-create-a-shortcut-using-powershell
Function Set-Shortcut {
    param (
        [string]$LinkPath,
        [string]$Target, 
        [string]$Arguments,
        [string]$Description,
        [string]$WorkingDirectory,
        [string]$IconLocation,
        [int]$WindowStyle
    )
    $LinkPathParent = Split-Path $LinkPath -Parent
    
    $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($LinkPath)
    $Shortcut.TargetPath = $Target
    $Shortcut.Arguments = $Arguments
    
    If (!(test-path $LinkPathParent)) {
        new-item $LinkPathParent -Type "Directory" -Force
    }
    
    If ($Description) { $Shortcut.Description = $Description }
    If ($WorkingDirectory) { $Shortcut.WorkingDirectory = $WorkingDirectory }
    If ($IconLocation) { $Shortcut.IconLocation = $IconLocation } # "notepad.exe, 0"
    If ($WindowStyle) { $Shortcut.WindowStyle = $WindowStyle }
        # 1 Activates and displays a window.
        # 3 Activates the window and displays it as a maximized window. 
        # 7 Minimizes the window and activates the next top-level window.

    
    $Shortcut.Save()
}

Function InstallShortcuts {
    Param (
        [Parameter(Mandatory=$true)] [String]$Target,
        [String]$Path,
        [switch]$userprofile,
        [String]$IconLocation
    )
    
    If (!$Path) {
        $Path = "$($ENV:ProgramData)\Microsoft\Windows\Start Menu\Programs"
        If ($userprofile) {
            $Path = "$($ENV:UserProfile)\Microsoft\Windows\Start Menu\Programs"
        }
    }

    # -Target "$([System.Environment]::SystemDirectory)\wscript.exe"  `
    Set-Shortcut -LinkPath "$Path\DucyBackup.lnk" `
        -Description "Use DucyBackup to manage Duplicacy backups" `
        -Target "powershell.exe" `
        -Arguments " -nologo -noprofile -executionpolicy bypass -file  `"$($Target)`"" `
        -IconLocation $IconLocation # "$([System.Environment]::SystemDirectory)\SHELL32.dll, 122"
        
}

# Check for updates of Duplicacy or Ducybackup script
Function Check-UpdateJson {
    <#
    .Synopsis
        Get available version information from the duplicacy web page
    .DESCRIPTION
        Default https://duplicacy.com/latest_web_version
        Should be the same as $Version = curl $URL | ConvertFrom-Json
    .OUTPUTS
        Typical from Duplicacy:
        {"latest":"1.4.1","stable":"1.4.1"}    
    #>
    Param (
        # URL to check
        $URL = "https://duplicacy.com/latest_cli_version"
    )

    Invoke-RestMethod $URL
}

Function GetDuplicacyVersion {
    Param (
        [String]$Path
    )

    If (!$path) {
        If ($ExeDestination) {
            $Path = $ExeDestination
        } Else {
            $Path = $Settings.DuplicacyPath
        }
    }

    If ($Path -and ((Split-Path $path -Leaf) -match '[.]exe$')) {
        If ($Path -and (Test-Path $Path)) {
            # $CurrentVersion   = [system.version]((& $Settings.DuplicacyPath) -join "|" -replace '^.*VERSION:[|] *([0-9.]*) .*','$1')
            # This executes Duplicacy CLI and get's the version from output:

            #If ($_Debug) {
            #    set-psdebug -Step
            #}
            Try {
                $CurrentVersion   = [system.version]((& $Path) -join "|" -replace '^.*VERSION:[|] *([0-9.]*) .*','$1')
            }
            Catch {
                $CurrentVersion = "0.0.0"
            }
        } Else {
            $CurrentVersion = "0.0.0"
        }
    } ElseIf ($Path) {
        If ($ScriptVersion) {
            $CurrentVersion = $ScriptVersion
        } Else {
            $x = test-scriptfileinfo -path $path
            #"\\concept\Documents\Arnt Marius\Documents\My Projects\DucyBackup\DucyBackup.ps1"
            $CurrentVersion = $x.Version
        }
        If (!$CurrentVersion) {$CurrentVersion = "0.0.0"}
    }

    Return $CurrentVersion
}

Function CheckVersion {
    <#
    .Synopsis
       Check available version
    .DESCRIPTION
       Check if there is a newer version of Duplicacy and return a version if user accepts
    .OUTPUTS
       If user accepts, returns the version in format "1.2.3"
       If user does not accept, or no available, or not scheduled to test, no return
    #>

    Param (
        # Force check now. Default is to check if update days has passed
        [Switch]$Force,
        # Show information even if no update
        [switch]$verbose,
        [String]$URL = "https://duplicacy.com/latest_cli_version",

        [ValidateSet('latest','stable')]
        [String]$UpdateChannel,

        # File to check version
        [String]$path,
        [String]$Title = 'Duplicacy',
        [String]$ScriptVersion, # Use this if .ps1 script version is known. Much faster
        [Int]$Indent  # Use to indent text
    )
    If ($Indent) {
        $PreString = "".PadRight($Indent)
    }
    

    #$Settings = Get-RegistrySettings "$AppKey\Settings"

    $DateCheckName = "DateCheckDuplicacy_$Title"

    $Settings = SetDefautSettings
    
    $CheckDays = $Settings.CheckForUpdateDays
    If (!$CheckDays) { $CheckDays = 60 }
    $LastCheckString = Get-RegistryValue -path $AppKey -name $DateCheckName
    If ($LastCheckString) {
        $LastCheck = get-date -Date $LastCheckString 
    } Else {
        $LastCheck = ((get-date) - (New-TimeSpan -Day $CheckDays))
    }

    If (!$UpdateChannel) {
        $UpdateChannel = switch($Settings.CheckForUpdateChannelLatest) {
            $true   {'latest'}
            Default {'stable'}
        }
    }
    
    If (!$path) {
        If ($ExeDestination) {
            $Path = $ExeDestination
        } Else {
            $Path = $Settings.DuplicacyPath
        }
    }

    If ($Path -and !(Test-Path $Path)) {
        $Force = $true
    }

    If ($LastCheck) {    
        $Timespan = New-TimeSpan -Start $LastCheck -End (get-date)
    }

    Function ClearTheLine {
        Param (
            [System.Management.Automation.Host.Coordinates]$Pos
        )
        SetPos $Pos
        Write-Host "                                                                            "
        SetPos $Pos
    }

    If ($Force  -or $Timespan.Days -ge $Settings.CheckForUpdateDays) {
        $TempCursor = $host.UI.RawUI.CursorPosition
        Write-Host "$($PreString)Checking for new version of $Title in channel '$UpdateChannel'..."
        # Set-RegistryValue -path $AppKey -name $DateCheckName -value "$((get-date).datetime)" #(Get-Date)
        $VersionInfo =  Check-UpdateJson -URL $URL
        $AvailableVersion = [system.version]($VersionInfo.$UpdateChannel)
        If (!$Force) {
            $IgnoreVersion = Get-RegistryValue -path "$AppKey\Settings" -name 'CheckForUpdateIgnoreVersion'
            If ($IgnoreVersion) {
                If ($IgnoreVersion -like $AvailableVersion) {
                    ClearTheLine $TempCursor
                    Return [String]""
                }
            } #Else {
              #  Set-RegistryValue -path $AppKey -name $DateCheckName -value "$((get-date).datetime)"
              #  ClearTheLine $TempCursor
              #  Return [String]""
            #}
        }

        Set-RegistryValue -path $AppKey -name $DateCheckName -value "$((get-date).datetime)"
    
        If ($ScriptVersion) {
            $CurrentVersion = $ScriptVersion
        } Else {
            If ($Path) {
                $CurrentVersion = GetDuplicacyVersion $Path
            } Else {
                Return [String]""
            }
        }

        ClearTheLine $TempCursor

        If (!$Path -and $AvailableVersion) {
            If (!$verbose) {
                ClearTheLine $TempCursor
            }
            Return [String]$AvailableVersion
        }
        
        If ($AvailableVersion -gt $CurrentVersion) {
            Write-Host "$($PreString)Existing version of $($Title): $CurrentVersion. A new version is available: $AvailableVersion"
            #SetPos $TempCursor
            Return [String]$AvailableVersion
        } Else { # if ($verbose) {
            # Write-Host "$($PreString)You have the latest version for the selected channel ($CurrentVersion)"
            Write-Host "$($PreString)$Title is up-to-date in channel '$UpdateChannel'"
        }
    } Elseif ($verbose) {
        Write-Host "$($PreString)$($Timespan.Days) days since last check. Last checked $($LastCheck), checking evry $($Settings.CheckForUpdateDays) days."
    }
}

Function UpdateDuplicacy {
    <#
    .Synopsis
       Propose to download the available version
    .DESCRIPTION
        Download version of Duplicacy.
        Examples:
        https://github.com/gilbertchen/duplicacy/releases/download/v2.7.2/duplicacy_win_x64_2.7.2.exe
        https://github.com/gilbertchen/duplicacy/releases/download/v2.7.2/duplicacy_win_i386_2.7.2.exe

        When downloaded, copy to program files\Duplicacy\duplicacy.exe (or where it is installed according to settings)
    #>
    Param (
        [String]$VersionString,
        [switch]$force,
        [switch]$UpdateScript,
        [Int]$Indent,  # Use to indent text
        [String]$Title = 'Duplicacy'
    )


    $DateCheckName = "DateCheckDuplicacy_$Title"

    If ($Indent) {
        $PreString = "".PadRight($Indent)
    }

    $Settings = Get-RegistrySettings "$AppKey\Settings"

    If (!$UpdateScript -and !$VersionString) {
        Return
    }

    If ($Scriptpath -match '^\\\\') {
        Write-Host "$($PreString)Script is on a network share. Your administrative account needs read access, or run from local copy."
        $Tryacc = Get-Choice -Menu "Run a &local copy;Run from &network"
        If ($Tryacc -eq 'Cancel') {exit}
        If ($Tryacc -eq 'OK' -or $Tryacc.KeyName -eq 'L') {
            $TempScriptFile = "$($ENV:Temp)\$((Split-Path $Scriptfile -Leaf) -replace '[.]ps1','_TMP.ps1')"
            Copy-Item $Scriptfile $TempScriptFile -force
            $Scriptfile = $TempScriptFile
        }
    }


    $ArgumentList = @(
        #"-noexit",
      #  "-WindowStyle", 
      #  "minimized",
        #"hidden",
        "-nologo", "-noprofile", "-Executionpolicy", "Bypass"
        "-File", """$ScriptFile""",
        "-Install"
    )


    If ($VersionString) {
        If ([Environment]::Is64BitOperatingSystem) {
            $OSBit = "x64"
        } Else {
            $OSBit = "i386"
        }

        $DownloadBase = "https://github.com/gilbertchen/duplicacy/releases/download"
        $NewFile = "duplicacy_win_$($OSBit)_$($VersionString).exe"

        $DownloadURL = "$DownloadBase/v$($VersionString)/$NewFile"
        $DownloadFile = "$($ENV:USERPROFILE)\Downloads\$NewFile"
    
        If ($Settings.DuplicacyPath -and (test-path $Settings.DuplicacyPath) -and $Settings.DuplicacyPath -notmatch '^\\$' ) {
            $DestinationFolder = Split-Path -Parent $Settings.DuplicacyPath
            $DestinationFile = Split-Path -Leaf $Settings.DuplicacyPath

        } Else {
            $DestinationFolder = "$($ENV:PROGRAMFILES)\Duplicacy"
            $DestinationFile = "duplicacy.exe"
        }
        $ExeDestination = "$DestinationFolder\$DestinationFile"

        If ($force) { $IgnoreTxt = "" } Else {$IgnoreTxt = ";&Ignore this version"}

        # $DownloadExist = (Test-Path $DownloadFile) 

        If (Test-Path $DownloadFile) {
            $QDownload = Get-Choice -Menu "&Use the $NewFile in your Downloads folder;&Download new copy$($IgnoreTxt)"
            If ($QDownload.KeyName -eq "D" -or $QDownload -eq 'OK') {
                Invoke-WebRequest $DownloadURL -OutFile $DownloadFile
            }
        } Else {
            $QDownload = Get-Choice -Menu "&Download duplicacy $VersionString from github$($IgnoreTxt)"
            If ($QDownload -like 'Cancel') {
                Write-Host "$($PreString)No download..."
                return
            }
            write-host ""
            Invoke-WebRequest $DownloadURL -OutFile $DownloadFile
        }


        If ($QDownload.KeyName -eq 'I') {
            Set-RegistryValue -path $AppKey -name $DateCheckName -value "$((get-date).datetime)"
            Set-RegistryValue -path "$AppKey\Settings" -name 'CheckForUpdateIgnoreVersion' -value $VersionString
            return
        }
        If ($QDownload -like 'Cancel') {return}


        $OKToCopy = Get-Choice -Menu "&Install to '$DestinationFolder'"
        If ($OKToCopy -eq 'Cancel' -or $OKToCopy.KeyName -eq 'C') {return}

        $ArgumentList += "-InstallExe", """$DownloadFile""",
            "-ExeDestination", """$ExeDestination"""
        
        $ActionText = "Copy Duplicacy.exe to program folder"
    }

    If ($UpdateScript) {
        $ArgumentList += "-InstallScript", "-ScriptDestination", """$($ENV:ProgramFiles)\DucyBackup\DucyBackup.ps1"""
        If ($ActionText) {
            $ActionText = "Update Duplicacy.exe and Ducybackup script to program folder"
        } Else {
            $ActionText = "Update Ducybackup script to program folder"
        }
    }
 
    $TryCount = 0
    Do {
        $TryCount ++
        Try {
            Write-Host "$($PreString)About to $ActionText"
            $InstallResult = Start-Process -FilePath "powershell.exe" -Verb "Runas" -ArgumentList $ArgumentList -Wait -PassThru -WindowStyle Minimized    # ).waitforexit()

            Write-host "$($PreString)DucyBackup components updated"

            # These are per user:
            If ($VersionString) {
                $Settings.DuplicacyPath = "$DestinationFolder\$DestinationFile"        
                Set-RegistryValue -path "$AppKey\Settings" -name 'DuplicacyPath' -value $Settings.DuplicacyPath
                Set-RegistryValue -path $AppKey -name $DateCheckName -value "$((get-date).datetime)"
            }
        }
        Catch {
            Write-host "$($PreString)Failed to run the command" -ForegroundColor Red
        }
    } until ($InstallResult -or $TryCount -gt 0 -or ($Retry -eq 'Cancel' -or $Retry.KeyName -eq 'C'))

    #Write-Host "Copy $($ENV:USERPROFILE)\Downloads\$NewFile to $($env:ProgramFiles)\Duplicacy"
    #Write-Host "and configure Ducybackup to use this in settings"
    #Read-Host "Any key to continue" | Out-Null
    # $InstallResult
}

<# InstallFiles
.Synopsis
    Copy executable and script to program files
    exctract vbs file used by task
    Create shortcuts to these
.DESCRIPTION
    These are the tasks needed to install Duplicacy.exe and the DucyBackup script.
    Install into programfiles for security - in case they need to be run elevated.
    (You want the scripts not to be modified)
#>
Function InstallFiles {
    Param (
        [String]$InstallExe,  # Path to downloaded exe (in downloads folder probably)
        [String]$ExeDestination = "$($ENV:PROGRAMFILES)\Duplicacy\duplicacy.exe",
        [Switch]$InstallScript,
        [String]$ScriptDestination = "$($ENV:ProgramFiles)\DucyBackup\DucyBackup.ps1"
    )

    # If (!$ExeDestination) {$ExeDestination = "$($ENV:PROGRAMFILES)\Duplicacy\duplicacy.exe"}


    # Copy new executable
    If ($InstallExe) {
        If (!(Test-Path $InstallExe)) {
            exit 10
        }
        $DestinationFolder = Split-Path $ExeDestination -Parent
        If (!(test-path $DestinationFolder)) {
            New-Item -ItemType Directory $DestinationFolder|out-null
        }
        Copy-Item $InstallExe $ExeDestination -force
    }
    
    # Copy new script
    If ($InstallScript) {
        $DestinationFolder = Split-Path $ScriptDestination -Parent
        If (!(test-path $DestinationFolder)) {
            New-Item -ItemType Directory $DestinationFolder|out-null
        }
        Copy-Item $ScriptFile $ScriptDestination -force

        # VBS file used by scheduled task to launch ducybacup silently:
        $VB | Set-Content -Path "$DestinationFolder\$((Split-Path $ScriptDestination -Leaf) -replace '[.]ps1','.vbs')"


        $picDecoded = [Convert]::FromBase64String($DucyIcon)
        $IconFile = "$DestinationFolder\$((Split-Path $ScriptDestination -Leaf) -replace '[.]ps1','.ico')"
        [IO.File]::WriteAllBytes($IconFile,$picDecoded)

        # Create shortcut(s) for all users
        InstallShortcuts -Target $ScriptDestination -IconLocation $IconFile
    }

}


# If installing, do that here:
If ($Install) {
    If (!$ExeDestination) {$ExeDestination = "$($ENV:PROGRAMFILES)\Duplicacy\duplicacy.exe"}

    $InstallArgs = @{
        InstallExe =        $InstallExe  # Path to downloaded exe (in downloads folder probably)
        ExeDestination =    $ExeDestination  # = "$($ENV:PROGRAMFILES)\Duplicacy\duplicacy.exe",
        InstallScript =     $InstallScript
        ScriptDestination = $ScriptDestination # = "$($ENV:ProgramFiles)\DucyBackup\DucyBackup.ps1"
    }
    InstallFiles @InstallArgs
    Exit # Install/update is done
}


Function UpdateDC {
    Param (
        [switch]$Force
    )

    $Settings = SetDefautSettings

    If (!$ScriptFile) { $ScriptFile = $PSCommandPath }

    If ($Force -or ($Settings.DuplicacyPath -and $Settings.CheckForUpdate)) {

        # Check Duplicacy version. $Settings.CheckForUpdateDays (e.g. 30 days stable or 2 days latest)
        If ($NewVersion = CheckVersion -Force:$Force) {
            write-host "A new version '$NewVersion' of duplicacy is available"
            UpdateDuplicacy $NewVersion
        }

        # Check script version
        If ($NewVersion = CheckVersion -Title 'DucyBackup script' -URL "https://github.com/akvarius/Dcy-Backup/blob/master/Version.json?raw=true" -path $ScriptFile -ScriptVersion $ScriptVersion -Force:$Force) {
            # If ($NewVersion = CheckVersion -Title 'DucyBackup script' -URL "https://github.com/akvarius/Dcy-Backup/blob/master/Version.json?raw=true" -path $Test) {
            # UpdateDuplicacy $NewVersion
            # write-host "A new version '$NewVersion' of the duplicacy script is available"
            write-host "Download latest version from https://github.com/akvarius"
            write-host "Extract to a folder and run to install. (Please make sure the script is safe)"
            $Result = Get-Choice -Menu "&Open download page"
            If ($Result -ne 'Cancel') { 
                Start-Process -FilePath "https://github.com/akvarius"
            }
        }
    }
}




#endregion Update

Function Main {

    # A test...
    If ($ISEHost -and $false) {
        ######################################## TEST
        $TestRepo = "C:\Users\Arnt Marius\Documents\TestBackup\3" # \.duplicacy

        #$Jobs = Get-DCJob $TFile   # Task is a bad choice for this term. Job instead
        $Jobs = Get-DCJob $TestRepo # Read all jobs from this repo
        If (!$Jobs) {
            exit
        }


        # One job can have multiple commands
        write-host "Jobs:"
        $Jobs.keys

        # A test job:
        $SelectedJob = $Jobs.'Backup to CTestTarget'

        <# How to add an action:
            # A new command to add:
            $CommandName = "TestCommand"
            $Command = @{
                Arguments = @("backup";"-dryrun")
                Fields = @{
                    Command = "Check"
                    DryRun = $true
                }
            }

            # Edit it?
            # $TestAction = $SelectedJob.Actions[0]
            $Command = Edit-Action $Command

            # $Order = 1
            # Add to job (to end of list if Order is not defined)
            $SelectedJob = Add-DCJobAction -Job $SelectedJob -Action $Command -Name $CommandName -Order $Order
        #>

        # Select an action
        $SelectedAction = $SelectedJob.Actions[0]
        $SelectedActionName = $SelectedAction.Name

        # Edit it?
        # $TestAction = $SelectedJob.Actions[0]
        $SelectedAction = Edit-Action $SelectedAction
        
        write-host "SelectedJob after adding:"
        $SelectedJob
        write-host "`nAction names:"
        $SelectedJob.Actions.name

        #Clean-Job $Jobs
        Save-DCJob $TestRepo $Jobs
        exit
        ######################################## TEST
    }


    Set-ConsoleSize
    Show-Title -splash

    $NotAdmin = !(Test-IsAdmin)

#    $Color_JobOrder = HashCopy $Color
#    $Color_JobOrder.ListSel = @{f = [System.consolecolor]"White";   b = [System.consolecolor]"Black"    }
#    $Color_JobOrder.ListCur = @{f = [System.consolecolor]"Yellow";  b = [System.consolecolor]"DarkBlue" }
    
    $Do_GetDuplicacyPath = $false

    $TerminalSettings = Get_ConsoleSettings

    $Settings = SetDefautSettings

    $UpdateChannel = switch($Settings.CheckForUpdateChannelLatest) {
        $true   {'latest'}
        Default {'stable'}
    }

    # Detect that this file is not in programfiles, meaning this is the installer file...
    If ($Scriptpath -notlike "$ENV:ProgramFiles\*" -and !$_DebugNoInstall -or $_DebugInstall) {

        

        If ($Settings.DuplicacyPath -match "\\.*.exe" -and (Test-Path $Settings.DuplicacyPath)) {
            $ExeDestination = $Settings.DuplicacyPath
        } Else {
            $ExeDestination = "$($env:ProgramFiles)\Duplicacy\Duplicacy.exe"
        }

        $ScriptDestination = "$($env:ProgramFiles)\DucyBackup\$(Split-Path -Leaf $ScriptFile)"
        
        If (Test-Path $ScriptDestination ) {
            Write-host "DucyBackup is already installed. To run DucyBackup, run the script from the Program Files folder"
            Write-host "To check for updates, continue!"
        }

        If ((Get-Choice -Menu "&Install DucyBackup") -eq 'Cancel') {
            exit
        }


        # Set-RegistryValue "$AppKey\Settings" 'Shown_LinewrapInfo' $true
        write-host "Install"
        #Write-Host "Download and save duplicacy.exe to program files..."
        Write-host ""
        Write-host "DucyBackup consists of two parts; this script (wrapper) and the Duplicacy software"
        Write-host "1. Checking that this install script is up-to-date"

        # Check script version
        If ($NewVersion = CheckVersion -Indent 3 -Title 'DucyBackup script' -URL "https://github.com/akvarius/Dcy-Backup/blob/master/Version.json?raw=true" -path $ScriptFile -ScriptVersion $ScriptVersion) {
            #write-host "   A newer version '$NewVersion' of the duplicacy script is available"

            write-host "   Download latest version from https://github.com/akvarius"
            write-host "   Extract to a folder and run to install. (Please make sure the script is safe)"
            $Result = Get-Choice -Menu "&Open download page"
            If ($Result -eq 'Cancel') { exit }
            Start-Process -FilePath "https://github.com/akvarius"
            exit
        } Else {
            #write-host "This installer is current"
        }

        If (!(test-path $ExeDestination)) {
            Write-host "2. Install the Duplicacy backup tool"
        } Else {
            Write-host "2. Checking for new version of the Duplicacy backup tool"
        }
        If ($NewVersion = CheckVersion -Indent 3 -Force -path $ExeDestination) {
            write-host "   Version '$NewVersion' of Duplicacy is available"
        } Else {
            #write-host "Version '$NewVersion' of Duplicacy is available"
            # already up to date
        }

        # Is installed script up to date? $ScriptVersion
        $UpdateScript = $true
        If (test-path $ScriptDestination) {
            Write-host "3. Checking installed script"
            $ScriptInstalledVersion = test-scriptfileinfo -path $ScriptDestination
            If ($ScriptVersion -le $ScriptInstalledVersion.version) {
                write-host "   Installed script is up to date"
                $UpdateScript = $false
            } Else {
                write-host "   Update script"
            }
        } Else {
            Write-host "3. Install script"
        }     

        UpdateDuplicacy $NewVersion -force -UpdateScript:$UpdateScript -Indent 3 

        $Result = Get-Choice -Menu "&Enter to exit" # -NoEscape
        exit
    }

    FindDuplicacyPath | Out-Null # (Silent, just find, or die trying)

    # Linewraps? (Can store in CU\Console\linewrap as well)
    If ($TerminalSettings.LineWrap -and !$Settings.Shown_LinewrapInfo) {
        #     Get-Content -Encoding byte shortcut-file
        Write-host "Line Wrap on resize is enabled for powershell consoles by default." -ForegroundColor White
        write-host "This might cause console layout to be messed up if you resize this console window."
        Write-host "Recommend disabling Line wrap:"
        Write-host "   Right click title bar, Properties/Layout: Disable 'Wrap text output on resize'."
        $Result = Get-Choice -Menu "&Don't remind me again;Ignore (Enter) to continue"
        If ($Result.KeyName -eq 'D') {
            Set-RegistryValue "$AppKey\Settings" 'Shown_LinewrapInfo' $true
        }
        # Show-Title -splash
    }

    # Update?
    UpdateDC
    <#
    If ($Settings.DuplicacyPath -and $Settings.CheckForUpdate) {
        # Check Duplicacy version. $Settings.CheckForUpdateDays (e.g. 30 days stable or 2 days latest)
        If ($NewVersion = CheckVersion) {
            write-host "A new version '$NewVersion' of duplicacy is available"
            UpdateDuplicacy $NewVersion
            # Show-Title
        }

        # Check script version

        If ($NewVersion = CheckVersion -Indent 3 -Title 'DucyBackup script' -URL "https://github.com/akvarius/Dcy-Backup/blob/master/Version.json?raw=true" -path $ScriptFile -ScriptVersion $ScriptVersion) {
            # If ($NewVersion = CheckVersion -Title 'DucyBackup script' -URL "https://github.com/akvarius/Dcy-Backup/blob/master/Version.json?raw=true" -path $Test) {
            #UpdateDuplicacy $NewVersion
            # write-host "A new version '$NewVersion' of the duplicacy script is available"

            write-host "Download latest version from https://github.com/akvarius"
            write-host "Extract to a folder and run to install. (Please make sure the script is safe)"
            $Result = Get-Choice -Menu "&Open download page"
            If ($Result -ne 'Cancel') { 
                Start-Process -FilePath "https://github.com/akvarius"
            }
        }
    }
    #>



    # Could be used in a command prompt:
#    set-alias Duplicacy $Settings.DuplicacyPath
#    set-alias dc $Settings.DuplicacyPath

    If ($EnableTest) {
       #############################################################################################

        $Repo = "C:\Users\Arnt Marius\Documents\TestBackup\3"
    #    Write-Host "Testing Invoke-Executable 'list' command"
    #    $ListARg = @("-log", "list", "-reset-passwords")
        $ListARg = @("-log", "-background", "list", "-reset-passwords")
        $ListARg = @("list") #, "-reset-passwords")

    #    StartCommand -FilePath $DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg
    #    $LASTEXITCODE
        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg -simple -Interactive -noclr

        #$R = StartCommand -FilePath $DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg -simple -Interactive -noclr
        "LastExitCode: $LASTEXITCODE"

        #ProcessStartDC -FilePath $DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg

    #    $X = Invoke-Executable -sExeFile $DuplicacyPath -WorkingDirectory $Repo -cArgs $ListARg


        #For interactive, does not return ecitcode
        #StartCommand -FilePath $DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg # -Log "$Repo\.Duplicacy\Logfile.txt"
    
        #$CmdResult = Execute-Command -commandTitle "Test" -commandPath $DuplicacyPath -commandArguments $ListARg
        #If ($R -gt 0) { write-host "Exit code: $R" }

        #    $proc = Start-Process -FilePath $FilePath -WorkingDirectory $WorkingDirectory -ArgumentList $ArgumentList -NoNewWindow -PassThru -Wait -RedirectStandardOutput

        exit
    #############################################################################################
    }

    # Show-Title
    Ask-Dialog $Dialog_Main -Parameters @{SettingsPath = $Settings.SettingsPath}
}


$Action_AddAction = @{
    Text = "Add to &job"
    Help = "Add command to the job list (allow scheduling)"
    Clear = "DialogTop"
    #Debug = 1
    Name = "-"
    EnableScript = {
        # If -Values (edit action) don't enable this action:
        $Values -eq $null
    }
    Action = {
        $DucyParameters = GetDialogParameters $Data
        Ask-Dialog $Dialog_AddAction -Parameters @{
            Arguments = $DucyParameters
            Fields = $Data.Fields
            Repository = $Repo
        }
    }
}


<#
    Global CLI options:
    -verbose, -v                 show more detailed information
    -debug, -d                   show even more detailed information, useful for debugging
    -log                         enable log-style output
    -stack                       print the stack trace when an error occurs
    -no-script                   do not run script before or after command execution
    -background                  read passwords, tokens, or keys only from keychain/keyring or env
    -profile <address:port>      enable the profiling tool and listen on the specified address:port
    -comment <text>              add a comment to identify the process
    -suppress, -s <id> [+]       suppress logs with the specified id
Not useful here:
    -help, -h                    show help
#>

# For these global parameters, text starts with a number - to not create shortcut conflicts with other commands/fields
$Global_Fields = [ordered]@{
    Global_Verbose = @{
        Parameter = "v"
        Text = '1 Verbose'
        Help = "Show more detailed information"
        Type = 'Boolean'
        Value = $false
        #Enable = $Settings.ShowGlobal
        InitScript = {$Field.Enable = $Settings.ShowGlobal}
    }

    Global_Debug  = @{
        Parameter = "d"
        Text = '2 Debug'
        Help = "Show debugging information"
        Type = 'Boolean'
        Value = $false
        # Enable = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal}
    }

    Global_Log  = @{
        Parameter = "log"
        Text = '3 Show log times'
        Help = "Add date and time to log lines"
        Type = 'Boolean'
        Value = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal}
    }

    Global_Stack = @{
        Parameter = "stack"
        Text = '4 Show stack if error'
        Help = "Show the stack trace when an error occurs"
        Type = 'Boolean'
        Value = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal -and $Settings.ShowAdv }
    }

    Global_NoScript = @{
        Parameter = "no-script"
        Text = '5 Disable CLI script'
        Help = "Do not run script before or after command execution. Does not stop DucyBackup scripts..."
        Type = 'Boolean'
        Value = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal -and $Settings.ShowAdv }
    }

    Global_Background = @{
        Parameter = "background"
        Text = '6 Disable manual input'
        Help = "Read passwords, tokens, or keys only from keychain/keyring or env"
        Type = 'Boolean'
        Value = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal -and $Settings.ShowAdv }
    }

    Global_Profile  = @{
        Parameter = "profile"
        Text = '7 Profiling address:port'
        Help = "Enable the profiling tool and listen on the specified address:port"
        InitScript = {$Field.Enable = $Settings.ShowGlobal -and $Settings.ShowAdv }
        Config = @{
            ValidateScript = {
                If ($FieldValue) {
                    If ($FieldValue -notmatch ":") { Return "To use this field, specify address:port" }
                }
            }
        }
    }

    Global_Comment = @{
        Parameter = "comment"
        Text = '8 Comment'
        Help = "Add a comment to identify the process if several run at the same time"
        # Value = $false
        InitScript = {$Field.Enable = $Settings.ShowGlobal}
    }


    # -suppress, -s <id> [+]       suppress logs with the specified id
    <#
    Global_Suppress = @{
        Parameter = "suppress"
        Text = '9 Suppress'
        Help = "Suppress logs with the specified id"
        Value = $false
        Enable = $false
    }
    #>

}


$Dialog_Main = @{
    # Definition of the Manage backup (repositories) dialog 
    Title = "Backup sets"

    # Main dialog. Chose a repository
    NoEnter = $True
    NoEscape = $True

    Help = "DucyBackup - a wrapper for @gchen's Duplicacy CLI`nScript Version: $ScriptVersion"


    # NoAutoListUpdate = $True # Don't update list after every action. For exception actions set.UpdateList=$true or dialogs: $UpdateList=$true 
    # AutoListUpdate = $AutoListUpdate   # Set default. If $false, for exception actions set $UpdateList=$true or $NoUpdateList=$true, for exception dialogs set .NoAutoListUpdate=$true
    
    Actions = [ordered]@{
        New = @{
            Text = "&New"
            Help = "Create a backup set (subfolder for backup information)"
            Action = {
                Ask-Dialog $Dialog_Init -Parameters @{Mode = "NewBackupSet";Repository = $Data.List[$ListSelectedItem].FullName}
                $RefreshList = $true
                $UpdateList = $true
            }
        }

        Manage = @{
            Text = "&Manage storages"
            Help = "Manage Backup set and storages. Add storage, backup, copy between storages, check snapshots etc"
            Action = { 
                Ask-Dialog $Dialog_Manage -Parameters @{Repository = $Data.List[$ListSelectedItem].FullName}
            }
            EnableScript = {($Data.List.count -gt 0 )}
        }

        ManageJobs = @{
            Text = "&Jobs"
            Help = "Manage jobs for the repository. Schedule, modify actions"
            Action = {
                Ask-Dialog $Dialog_ManageJobs -Parameters @{Repository = $Data.List[$ListSelectedItem].FullName }
            }
            EnableScript = {($Data.List.count -gt 0 )}
        }

        Explore = @{
            Text = "&Explore"
            Help = "Explore settings folder"
            Action = {
                # Open repository folder in file manager
                $Path = $Data.List[$ListSelectedItem].FullName
                If (Test-Path $Path) {
                    Start-Process -FilePath $Path
                } Else {
                    Write-Host "Not found: $Path) " -ForegroundColor Red
                    sleep -Seconds 5
                }
            }
            EnableScript = {($Data.List.count -gt 0 )}
        }        

        Logs = @{
            Text = "&Logs"
            Help = "Explore Ducybackup logs folder for this repository"
            Action = {
                # Open log folder in file manager
                
                # $ListLog = LogfilePath -Main $Settings.SettingsPath -Repository (Split-Path -Leaf $Repo) 
                $Path = "$($Settings.SettingsPath)\.DucyBackup\Logs\$($Data.List[$ListSelectedItem].Name)"

                If (Test-Path $Path) {
                    Start-Process -FilePath $Path
                } Else {
                    Write-Host "Not found: $Path) " -ForegroundColor Red
                    sleep -Seconds 5
                }
            }
            EnableScript = {($Data.List.count -gt 0 )}
        }        


        Settings = @{
            Text = "&Settings"
            Help = "Configure main backup settings"
            Action = { 
                Ask-Dialog $Dialog_Config
                $Settings = Get-RegistrySettings "$AppKey\Settings"
                $RefreshList = $true
                $UpdateList = $true
            }
        }

        Quit = @{
            Text = "&Quit"
            Help = "Exit this script"
            Action = { exit }
        }
    }
        
    ListUpdateScript = {
        # Load data.list from $SettingsPath
        $Data.List = @(Get-RepositoryList $settings.SettingsPath)
    }
    
    # Format of the list
    ListFormat = @(
        @{
            Name = "Name"
            Expression = {$_.Name}
            Width = 20
        },
        @{
            Name = "Id"
            Expression = {$_.LastID}
            Width = 20
            #Formatstring = ""
        },
        @{
            Name = "Repository"
            Expression = {$_.RepoPath}
            Width = 30
        },
        @{
            Name = "Stor"
            Expression = {$_.Storages}
            Width = 4
        }
     )
} # Main




$Dialog_Config = @{
    # Definition of the Config dialog 
    # (Duplicacy exe path, and settingsfolder)
    #'Menu' = "Learn|Open Duplicacy forum to learn more"  # Menu options for action choices (return key (Or perhaps "Learn" based on options)
    Title = "Configure settings"
    Registry = "$AppKey\Settings"   # \Settings
    StoreInRegistry = 1         # Store all values from this dialog in registry if not excluded

    # Clear

    Actions = @{
        Forum = @{
            NoValidate = 1
            Text = "Duplicacy &Forum"
            Help = "Open web browser to Duplicacy forum and join the community and learn more about Duplicacy (https://forum.duplicacy.com/t/duplicacy-user-guide)"
            Action = { Start-Process -FilePath "https://forum.duplicacy.com/t/duplicacy-user-guide" }
        }

        DownloadPage = @{
            NoValidate = 1
            Text = "&Duplicacy home"
            Help = @"
Open web browser to Duplicacy home page for download and information about the Duplicacy binary
"@
            Action = { 
                Start-Process -FilePath "https://github.com/gilbertchen/duplicacy/releases" 
            }
        }

        UpdateDuplicacy = @{
            NoValidate = 1
            Text = "&Update now"
            Help = @"
Check available version and download file, then copy to "C:\Program Files\Duplicacy"
"@
            Action = {

                UpdateDC -Force
                
                #If ($v = CheckVersion -verbose -Force) {
                #    UpdateDuplicacy $v
                #}
                Read-Host "Any key to continue" | Out-Null
            }
        }

        DucyBackup = @{
            NoValidate = 1
            Text = "Visit script &GitHub"
            Help = @"
Open web browser to DucyBackup github page (wrapper script for Ducplicacy)
"@
            Action = { Start-Process -FilePath "https://github.com/akvarius" }
        }

        About = @{
            NoValidate = 1
            Text = "About"
            Help = "About Duplicacy and DucyBackup (this script)"
            Action = {
                # Start-Process -FilePath "https://github.com/akvarius" 
                # Ask-Dialog $Dialog_About
                Write-Host -ForegroundColor White "`nAbout"
                write-host -ForegroundColor Yellow  "`n   DucyBackup - a wrapper for @gchen's Duplicacy CLI"
                Write-Host ""
                $CurrentVersion = GetDuplicacyVersion
                write-host -ForegroundColor Yellow "   Duplicacy Version: $CurrentVersion"
                write-host -ForegroundColor Yellow "     Author: @gchen"
                Write-Host ""
                write-host -ForegroundColor Yellow "   Script Version:    $ScriptVersion"
                write-host -ForegroundColor Yellow "     Author: @akvarius"
                write-host -ForegroundColor Yellow "     Date:   $ScriptDate"
                

                Read-Host "   Enter to continue"
            }
        }

    }
    
    Fields = [ordered]@{
        GeneralCaption = @{
            Text = "General:"
            Type = 'Caption'
        }

        DuplicacyPath = @{
            Hidden = $True
            Text = '&Path to Duplicacy exe'
            Help = 'Specify path to your duplicacy.exe'
            #Value = "C:\Test\Default"
            Valuename = "DuplicacyPath"    # Sync with this variable
            Type = 'File'
            Config = @{
                Title = "Select Duplicacy executable"
                Filter = "Exe files (*.exe)|*.exe|All sort of files (*.*)|*.*"
                Validate = 'Exist'
            }
        }
        SettingsPath = @{
            Text = 'Path to &settings folder'
            Help = 'Specify path where you want all backup configuration files and cache' 
            #Value = "C:\Backupfolder\A default Settings test"
            Valuename = "SettingsPath"
            Type = 'Folder'
            Config = @{
                Title = "Select folder for backup settings. This folder will contain all repositories (backup definitions)"
                ShowNewFolderButton = $true
                Validate = 'Exist'
            }
        }

        ShowAdv = @{
            Text = "Show advanced options"
            Type = 'Boolean'
            Enable = $true
            Help = "Show more settings in dialogs. (Some options might not be implemented in this script). Use the Duplicacy forum to learn more about Duplicacy"
            Config = @{
                States = @{
                    $True  = "On"
                    $False = "Off"
                }
            }
        }

        ShowGlobal = @{
            Text = "Show global options"
            Type = 'Boolean'
            Enable = $true
            Help = "Show global options in dialogs. "
            Config = @{
                States = @{
                    $True  = "On"
                    $False = "Off"
                }
            }
        }

        InitCaption = @{
            Text = "Storage:"
            Type = 'Caption'
        }

        InitAdvanced = @{
            Text = "Advanced &Init"
            Type = 'Boolean'
            Enable = $true
            Help = "Allow more settings when adding a storage"
            # like individual repository path per storage. Normally this is not what you want
            Config = @{
                States = @{
                    $True  = "On"
                    $False = "Off  (Auto, Recommended)"
                }
            }
        }

        InitAllowSymlink = @{
            Text = "Allow sy&qmlink"
            Type = 'Boolean'
            order = 11
            Enable = $true
            Help = @"
Allow Symlink type repositories. (Backup the repository folder within Settings folder)
It is often best to use the Repository folder field to point to your data folder.
Use blank Repository Folder field to allow a direct folder type and allow Symlink. 
(If you enter a path in Repository Folder field, any files or symlinks in the backup set folder will not be backed up)
"@
            Config = @{
                States = @{
                    $True  = "On   (Allow symlinks in repository folder)"
                    $False = "Off  (recommended) Require a folder path for backup"
                }
            }
        }

        UpdateCaption = @{
            Text = "Update:"
            Type = 'Caption'
        }

        CheckForUpdate = @{
            Text = "Enable check for update"
            Type = 'Boolean'
            Enable = $true
            Help = "Check for updates of Duplicacy binary and Duplicacy script"
            Config = @{
                States = @{
                    $True  = "On (Recommended)"
                    $False = "Off"
                }
            }
        }

        CheckForUpdateChannelLatest = @{
            Text = "Update &channel"
            Type = 'Boolean'
            Enable = $true
            Help = "Select stable or latest versions"
            Config = @{
                States = @{
                    $True  = "Latest"
                    $False = "Stable"
                }
            }
        }

        CheckForUpdateDays = @{
            Text = "Update &interval"
            Type = "int32"
            Enable = $true
            Help = "Days between update check for new versions of Duplicacy. (Recommend 30 days for 'stable', 1 for 'latest')"
            Config = @{
                Min = 1  # Min ignores empty. If a value exist, it must be more than Min
            }
        }

    }
        
    ValidateScript = {
        # Validatescript for Config
        $DPath = $Data.Fields.DuplicacyPath.Value
        If (!$DPath) {
            $Data.Fields.DuplicacyPath.Hidden = $false
            Return "Duplicacy executable file path required"
        }
        If (!(Test-Path -Path $DPath))  {
            $Data.Fields.DuplicacyPath.Hidden = $false
            Return "Select path to the Duplicacy CLI executable" 
        }
        #If ($DPath -notmatch "duplicacy[^.]*\.exe")  {Return "Make sure you select the Duplicacy CLI executable?" }
        If ($DPath -notmatch "duplicacy.*[.]exe") {
            $Data.Fields.DuplicacyPath.Hidden = $false
            Return "Select path to the Duplicacy CLI executable" 
        }
        

        $SettingsPath = $Data.Fields.SettingsPath.Value
        If (!$SettingsPath) {Return "Duplicacy settings path required"}
        If (!(Test-Path -Path $SettingsPath))  {Return "Duplicacy settings path must be set to an existing path" }
    }


} # Dialog_Config


$Dialog_NewSymLink = @{
    # Definition of the New Symlink dialog 
    Title = "Create New Symlink"
    Help = @"
A SymlinkD is a kind of shortcut.
SymlinkDs in your repository root tells Duplicacy to backup those destination folders
SymlinkDs in subfolders will be backed up as a file (not the folders they point to)
"@
    
    ShowName = $false # Initial value

    Wizzard = $True # Enter first field. On [Enter], move to next if passing validation
    Fields = [Ordered]@{
        Path = @{
            Text = '&Target path'
            Help = 'Specify path that symlink shall point to'
            Type = 'Folder'
            Config = @{
                Title = "Select target folder for symlink"
                ShowNewFolderButton = $true
                Validate = 'Exist'
                ValidateScript = {
                    # populates the next field if empty:
                    If ($FieldValue) {
                        If (!$Data.Fields.Name.Value -or (!$Settings.ShowAdv -and !$Data.ShowName) ) {
                            $Data.Fields.Name.Value = (Split-Path $FieldValue -Leaf) -replace "[\\:]", ""
                        }
                    }
                }
            }
        }

        Name = @{
            Text = 'Name for the new Symlink'
            Help = 'Specify name for the new symlink. Default is a simplified version of the target folder' 
            Config = @{
                Title = "Filename for the new link"
                ValidateScript = {
                    If (!$FieldValue) { 
                        # Return "Name is required!" 
                        $FieldValue = (Split-Path $Data.Fields.Path.Value  -Leaf) -replace "[\\:]", ""
                    }
                    $Repo = $Data.Parameters.Repository
                    If ($FieldValue -and !(Test-Path -isvalid -Path "$Repo\FieldValue"))  { 
                        $Data.ShowName = $True
                        $RefreshMenu = $True
                        Return "Invalid file name format!"
                    }
                    If ($FieldValue -and (Test-Path -Path "$Repo\$FieldValue")) {
                        $Data.ShowName = $True
                        $RefreshMenu = $True
                        write-host "ShowName:$($Data.ShowName),,,"
                        Return "A file with name '$FieldValue' already exist!"
                    }
                }
            }
            EnableScript = {
                $Settings.ShowAdv -or $Data.ShowName
            }
        }
    }

    ValidateScript = {
        # Validatescript for symlink
        $Repo = $Data.Parameters.Repository
        $Name = $Data.Fields.Name.Value
        $Path = $Data.Fields.Path.Value
        $Scut = "$Repo\$Name"
        If (!$Name) {Return "Name required"}
        If (!$Path) {Return "Target path required"}
        If (Test-Path -Path $Scut) { Return "Shortcut with same name already exist" }
    }

    ExecuteScript = {
        $Name = $Data.Fields.Name.Value
        $Path = $Data.Fields.Path.Value
        Run-Elevated Create_SymLink "$Repo;$Name;$Path"

        If (!(Test-Path "$Repo\$Name")) {
            return @{
                Reason = "Was not able to create symlink"
                Cancel = $true
            }
        }
    }
} # Dialog_NewSymLink


# This part # NOT IN USE
$Dialog_NewStorage = @{
    Title = "Add a storage"
    Wizzard = $True
    Fields = @{
        StorageName = @{
            Order = 1
            Text = 'Storage Name'
            Help = 'A name for the new storage. E.g. Friend-SFTP' 
            Value = 'Default'
            Config = @{
                Required = $True
                #ValidateScript = {
                    #If (!$FieldValue) { Return "Name is required!" }
                    # name exist??? { Return "Storage name must be unique!" }
                #}
            }
        }

        <#Type = @{
            Order = 2
            Text = '&Storage type'
            Help = 'Specify type for this storage. E.g. SFTP or local'
            #Value = "C:\Test\Default"
            #Valuename = "DuplicacyPath"    # Sync with this variable
            #StoreInRegistry = '1'         # Store this value in registry
            #DontStoreInRegistry = '1'    # Don't store this value in reg. (if \StoreinRegistry is defined)
            Config = @{
                List = @(
                    "SFTP","Local"
                )
                ValidateScript = {
                    # Populate the next field if empty:
                    If ($Data.Fields.Type.Value) {
                        If (!$Data.Fields.Name.Value) {
                            # $Data.Fields.Name.Value = $Data.Fields.Type.List.Item($Data.Fields.Type.Value)
                            $Data.Fields.Name.Value = "$FieldValue-"
                        }
                    }
                }
            }
        }#>

        Path = @{
            Order = 3
            Text = '&Storage path'
            Help = 'Specify path for this storage'
            Config = @{
                ValidateScript = {
                    If (!$FieldValue) { Return "Path is required!" }
                    #$FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                }
            }
        }
        
        # You can get a field with another form:
        Encrypt = $Dialog_init.Fields.Encrypt

    } # Newstorage Fields 
} # $Dialog_NewStorage
# NOT IN USE





<#
# init storage (not add)
SYNOPSIS:
        duplicacy init - Initialize the storage if necessary and the current directory as the repository

    USAGE:
        duplicacy init [command options] <snapshot id> <storage url>

    OPTIONS:
        -encrypt, -e                    encrypt the storage with a password

        -chunk-size, -c <size>          the average size of chunks (default is 4M)
        -max-chunk-size, -max <size>    the maximum size of chunks (default is chunk-size*4)
        -min-chunk-size, -min <size>    the minimum size of chunks (default is chunk-size/4)
        -iterations <i>		   the number of iterations used in storage key derivation (default is 16384)
        -pref-dir <path>                alternate location for the .duplicacy directory (absolute or relative to current directory)

        -storage-name <name>            assign a name to the storage
        -repository <path>              initialize a new repository at the specified path rather than the current working directory
        -erasure-coding <data shards>:<parity shards>        enable erasure coding to protect against storage corruption
                
#>
$Dialog_Init = @{
    # Get info required to create a storage and init the first storage 
    Title = "Init repository and storage"
    Wizzard = $True
#    FirstInfo = @"
#This repository (folder) is empty and needs to be initialized.
#At the same time a storage target will be defined. (Hit F to learn more)
#"@


    Fields_ParameterOrder = 1

    Help = @"
Hit F to find more info on 'init' in the Duplicacy Forum User Guide
Also look up info on storage backends! https://forum.duplicacy.com/t/supported-storage-backends
"@

    Actions = @{
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum

        Advanced = @{
            NoValidate = 1
            Text = "Advanced options"
            Help = "Toggle showing more options"
            Action = { 
                If ($Data.ShowAdv -eq $null) {
                    write-error 'Error in form, $Data.ShowAdv should be set during init'
                    $Data.ShowAdv = !$Settings.ShowAdv
                } Else {
                    $Data.ShowAdv = !$Data.ShowAdv
                }
            }
        }
    }

    Fields = $Global_Fields + [Ordered]@{
        Command = @{
            ParameterOrder = 0
            Hidden = $True
            Parameterbuild = "Value"
            Value = "init"
        }

        Name = @{
            # Enable this field to let users create a new backup set (repository) and initialize it.
            Parameterbuild = "Hide"
            EnableScript = { $Data.Parameters.Mode -eq "NewBackupSet" }  #-and $Settings.InitAdvanced 
            Text = 'Name (repository)'
            Help = 'Folder name for the new backup. (This is known as a repository in Duplicacy)' 
            Config = @{
                Required = $True
                ValidateScript = {
                    #write-host "Name" ; set-PSDebug -step
                    DebugType 1
                    If ($Data.Parameters.Mode -eq "NewBackupSet") {

                        If (!$FieldValue) { 
                            $n = 1
                            Do {
                                $Propose = "Folder_{0:d3}" -F $n
                            } until (!(Test-Path -Path "$($Data.Parameters.SettingsPath)\$Propose") -or ++$n -gt 999)

                            If ($n -gt 999) {
                                Write-Error "Too many folders in $($Data.Parameters.SettingsPath), exits"
                                Exit
                            }
                            $FieldValue = $Propose
                            Return "Folder name required - made a proposal" 
                        }
                        If ($FieldValue) {
                            If ($FieldValue -match ":") { Return "':' is not allowed in a folder name!" }
                            If (!(Test-Path -isvalid -PathType Container -Path $FieldValue))  { Return "Invalid name format!"}
                            If ($FieldValue -like ".Duplicacy") {Return '".Duplicacy" is a reserved name'}
                            $Folder = "$($Data.Parameters.SettingsPath)\$FieldValue"
                            If (!(Test-Path -isvalid -Path "$Folder"))  { Return "Invalid folder format!"}
                            If (Test-Path -Path "$Folder\.Duplicacy\preferences" -PathType Leaf) { Return "Backup folder already initialized!"}
                        }
                    }
                }
            }
        }

        repository = @{
            Text = 'Folder to back up'
            Type = 'Folder'
            Help = @"
Select a folder to back up.
(In Advanced mode you can leave this blank to use links instead)
"@
            Config = @{
                Title = "Folder to back up"
                ShowNewFolderButton = $true
                #Validate = "Exist"
                ValidateScript = {
                    If ($FieldValue -and !(Test-Path -isvalid -Path $FieldValue))  { Return "Invalid folder format!"}
                    If ($FieldValue -and !(Test-Path -Path $FieldValue)) { Return "repository folder does not exist!"}
                    If (!$FieldValue -and !$Settings.InitAdvanced) { Return "Select a folder to back up! (In advanced mode you can leave it blank)"}

                    If (!$Data.Fields.Name.Value) {
                        $n = 1
                        Do {
                            $Propose = "Repository_{0:d3}" -F $n
                        } until (!(Test-Path -Path "$($Data.Parameters.SettingsPath)\$Propose") -or ++$n -gt 999)

                        If ($n -gt 999) {
                            Write-Error "Too many repository folders in $($Data.Parameters.SettingsPath), exits"
                            Exit
                        }
                        $Data.Fields.Name.Value = $Propose
                    }

                    # If no remote repository folder, suggest local repo folder
                    If (!$Data.Fields.ID.Value) {
                        If (!$FieldValue) {
                            $ID = "$env:COMPUTERNAME-$($Data.Fields.Name.Value)"
                        } Else {
                            $ID = "$env:COMPUTERNAME-$FieldValue"
                        }
                        $Data.Fields.ID.Value = $ID  -replace " ", "_" -replace "[\\:]+", "-" -replace "[^a-z0-9-_]", ""
                    }
                }
            }
        }

        ID = @{
            Text = '&ID'
            ParameterOrder = 10
            Parameterbuild = "Value"
            Help = "Specify 'Snapshot ID'. This identifies this backup in a shared storage. Accepts '-', '_' and alphanumerics"
            # EnableScript = { $Settings.InitAdvanced }

            Config = @{
                ValidateScript = {
                    DebugType 1 1
                    If (!$FieldValue) {
                        If ($Data.Fields.Repository.Value) {
                            $FieldValue = "$env:COMPUTERNAME-$($Data.Fields.repository.Value)" -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Repository ID is required! Suggesting repository path info"
                        }
                        If ($Data.Fields.Name.Value) {
                            $FieldValue = $Data.Fields.Name.Value -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Repository ID is required! Suggesting the backup set name"
                        }
                        Return "Repository ID is required!"
                    } Else {
                        $Temp = $FieldValue
                        $FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                        If ($Temp -ne $FieldValue) {
                            Blink "Removed unaccepted characters!"
                        }
                    }
                }
            }
        }


        Path = @{
            ParameterOrder = 20
            Parameterbuild = "Value"
            Type = 'Folder'
            Text = '&Storage path'
            Help = @"
Specify path for this storage. Two examples: 
Local drive:  F:\Store\AMB\Duplicacy\Bilder
SFTP: sftp://user@192.168.1.100//path/to/storage
(Note how to specify user and the double // to separate servername and path - required on some SFTP servers)
Learn more on https://forum.duplicacy.com/t/supported-storage-backends
"@
            Config = @{
                Title = "Backup target"
                ShowNewFolderButton = $true
                Required = $True


                #    If (!$FieldValue) {
                #        Return "Storage path is required!" 
                #    } Else {
                #        # If (!(Test-Path -isvalid -PathType Container -Path $FieldValue))  { Return "Invalid name format!"}
                #        # If ($FieldValue -like ".Duplicacy") {Return '".Duplicacy" is a reserved name'}
                #            
                #        #If (!$Data.Fields.Name.Value) {
                #        #    $Data.Fields.Name.Value = "---"
                #        #}
                #    }
                

            }
        }

        StorageName = @{
            Parameter = "storage-name"
            #Order = 4
            Text = 'Storage &Name'
            Help = 'Specify a name for this storage (used for operations later)' 
            Config = @{
                Required = $True
                ValidateScript = {
                    write-host "storagename" -ForegroundColor Yellow
                    If (!$FieldValue) {
                        If ($Data.Fields.Path.Value) {
                            $FieldValue = $Data.Fields.Path.Value -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Name is required! Suggesting path info but you decide!" # $FieldValue
                        } Else {
                            Return "Name is required!"
                        }
                    }
                }
            }
        }

        Encrypt = @{
            Text = '&Encrypt this storage'
            # Used by GetDialogParameters: 
            Parameter = 'e'
            # ParameterOrder = 20
            # Parameterbuild = "V"   # Value only
            # Parameterbuild = "PV"  # Default: Parameter and Value
            # Parameterbuild = "Param"     # Parameter only
            # ValueBuild = "State"  # Use string from state (for boolean but shoukd work for others if defined. (replaces 0 and empty string))

            Type = 'Boolean'
            Help = 'Specify if storage should be encrypted (Recommended).'
            Value = $True
            Config = @{
                #ValidateScript = {
                    # For boolean, blink doesnt work now, just disblays "On". Can use State instead to show a message; $False = "Off (Not recommended!)"
                #}
                States = @{
                    $True = "On"
                    $False = "Off (Not recommended!)"
                }
            }
        }

        #  -erasure-coding <data shards>:<parity shards>        enable erasure coding to protect against storage corruption
        ErasureCoding = @{
            Parameter = 'erasure-coding'
            Enable = $true
            Text = 'Erasure coding'
            Help = @"
Enable Erasure coding to protect against storage corruption.
Recommended on private FTP servers and local disks. 
Format: <data shards>:<parity shards>
Example 5:2
"@
            Config = @{
                # Match = '[0-9]+:[0-9]+'
                ValidateScript = {
                    # If storage path points to SFTP, FTP, local drive or UNC, recommend using erasure encoding

                    # Set-PSDebug -Step

                    If (!$FieldValue) { 
                        If ($Data.Fields.Path.Value -match '^[A-Z]:|^\\|^s?ftp:|^\\\\') {
                            If (!$Data.ShowedErasureWarning) {
                                Write-Host "EC First time"
                                $Data.ShowedErasureWarning = $True
                                Return "Consider using erasure encoding!"
                            }
                        }
                    }

                    If ($FieldValue) {
                        If ($FieldValue -notmatch '[0-9]+:[0-9]+') { Return "To use this field, specify <data shards>:<parity shards>" }
                    }
                }
            }
        }


        ChunkSize = @{
            Parameter = "chunk-size"
            Text = 'Chunk size'
            #EnableScript = { 
                # $Dialog_Init.Parameters.Advanced
                # .. $Data.Parameters.Advanced
                #Write-host "param adv: $($Data.Config.Advanced)" 
                # Return  $Data.Config.Advanced 
                
                #Return $Settings.ShowAdv
            #}

            # InitScript = { $Field.Enable = $Settings.ShowAdv }
            EnableScript = { $Data.ShowAdv }

            #Enable = $Settings.ShowAdv
            Help = 'The average size of chunks (default is 4M)' 
            Type = "int32"
            #Value = -1
            Config = @{
                Min = 0
                #ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        MaxChunkSize = @{
            Parameter = "max-chunk-size"
            Text = 'Maximum chunk size'
            EnableScript = { $Data.ShowAdv }
            Help = 'The maximum size of chunks (default is chunk-size*4)' 
            Type = "int32"
            #Value = 0
            Config = @{
                Min = 0
                #ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        MinChunkSize = @{
            Parameter = "min-chunk-size"
            Text = 'Minimum chunk size'
            EnableScript = { $Data.ShowAdv }
            Help = 'The minimum size of chunks (default is chunk-size*4)' 
            Type = "int32"
            #Value = 0
            Config = @{
                Min = 0
                ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        <#
        # Obsolete.
        #-pref-dir <path>  alternate location for the .duplicacy directory (absolute or relative to current directory)
        "pref-dir" = @{
            Enable = $false # Or advanced.... { $Data.Parameters.Mode -eq "NewBackupSet" }
            Text = 'Preferences dir'
            Help = 'Alternate location for the .duplicacy settings directory. For advanced users.'
        }
        #>

        #-iterations <i>  the number of iterations used in storage key derivation (default is 16384)
        iterations = @{
            EnableScript = { $Data.ShowAdv }
            Text = 'Iterations'
            Help = 'The number of iterations used in storage key derivation (default is 16384). If you use this value you must use this whenever you specify a storage password'
            Config = @{
                Min = 0
            }
        }
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        $Data.ShowAdv = $Settings.ShowAdv

        If ($Data.Parameters.Mode -match "NewBackupSet") {
            $Data.Title = "New Backup Set (Create and initialize)"
        }
    }

    ValidateScript = {
        If ($Data.Parameters.Mode -match "NewBackupSet") {
            $Name = $Data.Fields.Name.Value
            $repo = "$($Data.Parameters.SettingsPath)\$Name"
            If (!$repo) {Return "Repository folder required"}
            If (!$Name) {Return "Name required"}
            If ($Name -like ".Duplicacy") {Return ".Duplicacy is a reserved name"}
            If (Test-Path -Path "$repo\.Duplicacy\preferences" -PathType Leaf) { Return "Backup folder already initialized!"}
        } Else {
            $repo = $Data.Parameters.Repository
            If (!(Test-Path -Path $Repo))  {Return "Backup set (repository) does not exist: '$Repo'"  }
        }
    }

    ExecuteScript = {
        If ($Data.Parameters.Mode -match "NewBackupSet") {          # New backup set? Create folder
            $Name = $Data.Fields.Name.Value
            $repo = "$($Data.Parameters.SettingsPath)\$Name"
            Write-Host "Creating new backup set folder: $Repo"
            Try {
                New-Item -ItemType Directory $Repo -Force  | Out-Null
            }
            Catch {
                Return @{Cancel = $true; Reason = "Create backup set failed"}
            }
        } Else {
            $repo = $Data.Parameters.Repository
        }

        $DucyParameters = @(GetDialogParameters $Data ) # -verbose


        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"
        Write-Host "Initializing repository"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }

        IF ($Data.Fields.Encrypt.Value) {
            Write-Host "Invoking the 'list' command to store encryption password"
            $ListARg = "list", "-storage", $Data.Fields.StorageName.Value
            StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg
            If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
        }
    }
} # Dialog_Init



# Add
<#
SYNOPSIS:
   duplicacy add - Add an additional storage to be used for the existing repository

USAGE:
   duplicacy add [command options] <storage name> <snapshot id> <storage url>

OPTIONS:
   -encrypt, -e                         encrypt the storage with a password
   -chunk-size, -c <size>               the average size of chunks (default is 4M)
   -max-chunk-size, -max <size>         the maximum size of chunks (default is chunk-size*4)
   -min-chunk-size, -min <size>         the minimum size of chunks (default is chunk-size/4)
   -iterations <i>                      the number of iterations used in storage key derivation (default is 16384)
   -copy <storage name>                 make the new storage compatible with an existing one to allow for copy operations
   -bit-identical                       (when using -copy) make the new storage bit-identical to also allow rsync etc.
   -repository <path>                   specify the path of the repository (instead of the current working directory)
#>
$Dialog_AddStorage = @{
    # Get info required for adding a storage
    Title = "Add storage"
    Wizzard = $True

    Help = @"
Hit F to find more info on 'add' in the Duplicacy Forum User Guide
Also look up info on storage backends! https://forum.duplicacy.com/t/supported-storage-backends
"@

    Actions = @{
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum
        Advanced = $Dialog_init.Actions.Advanced
    }

    Config = @{Advanced = $false}

    Fields = [ordered]@{  # Add
        repository = @{
            Hidden = $true
            #Enable = $false
            ParameterOrder = 10
            Text = 'Repository folder'
            Help = @"
Select a folder to back up. Recommend using same path and ID as for the default job.
Leave this blank to back up the Backup set folder instead
"@
            Type = 'Folder'
            Config = @{
                Title = "Folder to back up"
                ShowNewFolderButton = $true
                # Validate = 'Exist'
                ValidateScript = {
                    If ($FieldValue) {
                        If (!(Test-Path -isvalid -Path $FieldValue))  { Return "Invalid repository folder format!"}
                        If (!(Test-Path          -Path $FieldValue))  { Return "Repository folder does not exist!"}
                    } Else {
                        If (!$Settings.InitAdvanced) {
                            Return "Repository folder is not specified!"
                        }
                    }
                    If (!$Data.Fields.ID.Value) { $Data.Fields.ID.Value = $FieldValue -replace " ", "_" -replace "[\\:]+", "-" -replace "[^a-z0-9-_]", "" }
                }
            }
        }

        # If not advanced, InitScript can set repository and ID. Same ID as initial storage for this repository.
        # Use the same ID ($dialog_init.fields.ini)
        ID = @{
            EnableScript = {$Settings.InitAdvanced}
            Hidden = $True
            Text = 'Repository &ID'
            ParameterOrder = 31
            Parameterbuild = "Value"
            Help = @"
Repository ID identifies the backup source.  (Recommend using same as default).
This identifies this backup in a shared storage. Only accepts '-', '_' and alphanumerics
"@
            Config = @{
                
                ValidateScript = {
                    If (!$FieldValue) {
                        If ($Data.Fields.Repository.Value) {
                            $FieldValue = $Data.Fields.Repository.Value -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Repository ID is required! Suggesting repository path info"
                        }
                        If ($Repo) {
                            $FieldValue = (Split-Path $Repo -Leaf) -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Repository ID is required! Suggesting local Repository path"
                        }
                        If ($Data.Fields.Name.Value) {
                            $FieldValue = $Data.Fields.Name.Value -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Repository ID is required! Suggesting the backup set name"
                        }
                        Return "Repository ID is required!"
                    } Else { 
                        $Temp = $FieldValue
                        $FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                        If ($Temp -ne $FieldValue) {
                            Blink "Removed unaccepted characters!"
                        }
                    }
                }
            }
        }

        Cap_Storage = @{
            Hidden = $true
            Type = 'Caption'
            Text = "Storage:"
            Order = 2
        }

        Path = @{
            Order = 3
            ParameterOrder = 32
            Parameterbuild = "Value"
            Type = 'Folder'
            Text = '&Storage path'
            Help = @"
Specify path for this storage. Two examples: 
Local drive:  F:\Store\AMB\Duplicacy\Bilder
SFTP: sftp://user@192.168.1.100//path/to/storage
(Note how to specify user and the double // to separate servername and path - required on some SFTP servers)
Learn more on https://forum.duplicacy.com/t/supported-storage-backends
"@
            Config = @{
                Title = "Backup target"
                ShowNewFolderButton = $true
                Required = $True
                # Validate = 'Exist'
                #ValidateScript = {
                #    If (!$FieldValue) {
                #        Return "Path cannot xx be empty!"
                #    }
                #}
            }
        }

        StorageName = @{
            Parameter = "storage-name"
            ParameterOrder = 30
            Parameterbuild = "Value"
            Order = 4
            Text = 'Storage &Name'
            Help = 'Specify a name for this storage (used for operations later)' 
            Config = @{
                ValidateScript = {
                    If (!$FieldValue) {
                        If ($Data.Fields.Path.Value) {
                            $FieldValue = $Data.Fields.Path.Value -replace " ", "_" -replace "[\\:/]+", "-" -replace "[^a-z0-9-_]", "" 
                            Return "Name is required! Suggesting path info but you decide!" # $FieldValue
                        } Else {
                            Return "Name is required!"
                        }
                    }
                }
            }
        }

        copy = @{
            EnableScript = {$Settings.InitAdvanced}
            ParameterOrder = 5
            Order = 21
            Text = 'Copy-compatible with'
            Help = @"
Make this storage copy-compatible with the selected storage (Default).
This is required if you intend to copy between storages. (Clear this field to disable)
"@
            Config = @{
                ValidateScript = {
                    If ($FieldValue) {
                        #Set-PSDebug -Step
                        If (($Data.Storages).name -notcontains $FieldValue) {
                            Return "Name is not found in storages!"
                        }
                    }
                }
            }
        }

        BitIdentical = @{
            Text = 'Make it &Bit-identical'
            Parameter = 'bit-identical'
            ParameterOrder = 20
            Parameterbuild = "Param"     # Parameter only
            Type = 'Boolean'
            Order = 22
            Help = "Make the new storage bit-identical with the current storage, to also allow rsync etc"
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Make bit-identical copy)"
                    $False = "Off "
                }
            }
        }


        # You can get a field with another form:
        Encrypt =       $Dialog_init.Fields.Encrypt
        ErasureCoding = $Dialog_Init.Fields.ErasureCoding
        ChunkSize =     $Dialog_Init.Fields.ChunkSize
        MaxChunkSize =  $Dialog_Init.Fields.MaxChunkSize
        MinChunkSize =  $Dialog_Init.Fields.MinChunkSize
        iterations  =   $Dialog_Init.Fields.iterations
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        If (!$Data.RepoIsInitialized) {
            Write-Warning "Add command, but repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        $Data.ShowAdv = $Settings.ShowAdv

        $Data.Repo = $Repo
        # $Data.Storages = @(Read-Preferences $Repo)
        $Data.Storages = @(Get_Storage $Repo)

        # Get storage list
        $Data.Fields.Repository.Value = $Data.Parameters.Storage.repository
        $Data.Fields.ID.Value         = $Data.Parameters.Storage.id
        $Data.Fields.Copy.Value       = $Data.Parameters.Storage.name
    }

    # Actions
    ExecuteScript = {
        # New backup set? Create folder

        $Command = "add"
        $DucyParameters = @($Command) + @(GetDialogParameters $Data)
        If ($GlobalOpt) {
            $DucyParameters = @($GlobalOpt) + $DucyParameters
        }

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"
        Write-Host "Adding a storage"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        $R = $LASTEXITCODE
        If ($R -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $R"} }

        IF ($Data.Fields.Encrypt.Value) {
            Write-Host "Invoking the 'list' command to store encryption password"
            $ListARg = "list", "-storage", $Data.Fields.StorageName.Value
            StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg -Log '-'
            $R = $LASTEXITCODE
            If ($R -gt 0) { Return @{Cancel = $true; Reason = "List command failed with error: $R (was trying to save password. You can do this manually later)"} }
        }
    }
} # Dialog_Add












# Shoud allow piping...
# $Data.List | Format-DCList

<#
Write-ListLine
Use an array of hashtables to format a list.
Format: 
    @{
        Name = "Column name"
        Width = 20
        Color = @{
            f = "Yellow"
            b = "Black"
        }
        Fill = "_"
        Justify = "Right" or "Left"

    }
#>
<#
Function Write-ListLine {
    Param (
        $Format,
        $Object,            # Elements for this line.
        $Property,          # Like for Select-Object -property ---, for getting properties from Objects
        [Switch]$Header,
        [Char]$Fill = " ",
        $Color = @{f = [System.consolecolor]"White"; b = [System.consolecolor]"Black" }
    )

    If (!$Format) { $Format = $Data.ListFormat }
    If (!$Property) {
        $n = 0
        $Format | ForEach-Object {
            If ($_.Property) {
                $_.Property.Label = [String]$n
            } Else {
                $_.Property = @{
                    Label = [String]$n
                    Expression = $_.Expression
                }
                If (!$_.Property.Expression) {
                    $_.Property.Expression = " "
                }
            }
            $n++
        }
        $Property = @($Format.Property)
    }
    If ($Property -and $Object) {
        $PropertyStrings = $Object | Select-Object $Property
    }
    
    $n = 0
    $Format | ForEach-Object {
        If ($_.Color) {$ThisCol = $_.Color} Else {$ThisCol = $Color} 
        If ($_.Fill)  {$ThisFill = $_.Fill} Else {$ThisFill = $Fill}
        If ($Header) {
            $String = $_.Name
        } Else {
            $String = [String]$ThisFill
            If ($PropertyStrings) {
                $String = [String]$PropertyStrings.$n      # Select column named $n
            } Else {
                If ($n -lt $Objects.Count) {
                    $String = [String]$Objects[$n]         # Select array element numbe $n
                }
            }

        }
        If (!$String) {$String = [String]$ThisFill}
        If ($_.Width) {
            If ($_.Width -le $String.length) {
                $String = $String.substring(0, $_.Width)
            }
            If ($_.Justify -like "Right") {
                $String = $String.padLeft($_.Width, $ThisFill) #  $_.PadChar
            } Else {
                $String = $String.padRight($_.Width, $ThisFill) #  $_.PadChar
            }
        }
        Write-Host $String -NoNewline -ForegroundColor $ThisCol.f -BackgroundColor $ThisCol.b
        $n++
    }
    Write-Host ""
}
#>
<#
Function TaskList_List {
    Write-ListLine -Header -Fill "_"
    $Data.List | ForEach-Object {
        $Sch = $Data.Task.$_.Schedule
        $Sch_Inf = $Data.Task.$_.ScheduleInfo
        Write-ListLine -Object $_
        # Write-ListLine -Format $Data.ListFormat2 -Object $_
    }
} #>



# Make $Data.Task with hashtable 
# Make $Data.List with some properties, as a list that can be shown as format-table
# $Data.Format contains an array with properties/widths
Function TaskList_Init {
    Param (
        [Parameter(Mandatory=$true)]
        [String]$Repo
    )

    # Write-Host "Init TaskList"

    $Data.Task = Get-DCJob -Path $Repo   # Get all tasks for this repo. A hashtable with actions etc.
    #$Data.List = $Data.Task.keys      # The names of the tasks 
    
    #$Data.List = @()
    #$Data.Task.keys | ForEach-Object {
    #    $Data.List += [PSCustomObject]@{
    #        Name = $_
    #        Actions = $Data.Task.$_.Actions
    #        Schedule = ""
    #        ScheduleInfo = ""
    #    }
    #}

    # (We might be able to skip $Data.Task)
    $Data.List = @( $Data.Task | select name,actions,arguments,fields,schedule,scheduleinfo)

    # Find tasks for this repository by name: "DucyBackup (<repofolder>) <taskname>"
    # e.g. "DucyBackup (4) *"
    $RepoName = Split-Path $Repo -Leaf
    $TaskNameBase = "DucyBackup ($RepoName) "

    # $Sch_Tasks = Get-ScheduledTask -TaskPath $TaskPath -ErrorAction SilentlyContinue 
    Get-ScheduledTask -TaskPath $TaskPath -TaskName "$TaskNameBase*" -ErrorAction SilentlyContinue  | ForEach-Object {
        $Schedule = $_
        $Sch_BelongsTo = $_.TaskName -replace "^DucyBackup [(]$RepoName[)] "
        $FoundTask = $false
        $Data.list | Where-Object Name -eq $Sch_BelongsTo | ForEach-Object {
            $_.Schedule = $Schedule
            $_.ScheduleInfo = ($Schedule | Get-ScheduledTaskInfo)
            $FoundTask = $True
        }

        If (!$FoundTask) {
            # Write-Warning "Could not find task '$Sch_BelongsTo'. Consider unscheduling: Schedule/Remove"
            #$Line = "" | Select-Object Name, Action, Schedule, ScheduleInfo
            #$Line.Name = "Missing: '$Sch_BelongsTo'"
            #$Line.Schedule = $Schedule
            #$Line.ScheduleInfo = ($Schedule | Get-ScheduledTaskInfo)
            #$Data.List += $Line

            $Data.List += [PSCustomObject]@{
                Name = $Sch_BelongsTo
                Actions = "Missing job"
                # Actions = $Null
                Schedule = $Schedule
                ScheduleInfo = ($Schedule | Get-ScheduledTaskInfo)
                BelongsTo = $Sch_BelongsTo
            }

        }
    }

    $Data.list | Where-Object Schedule -eq $null| ForEach-Object {
        $_.Schedule = @{State = "(No schedule)"}
    }
}


<#
https://stackoverflow.com/questions/20705102/how-to-colorise-powershell-output-of-format-table
https://stackoverflow.com/users/2797457/jason-shirk   using VT escape sequences (PS 5.1)

https://en.wikipedia.org/wiki/ANSI_escape_code#CSI_sequences

    dir -Exclude *.xml $pshome | Format-Table Mode,@{
        Label = "Name"
        Expression =
        {
            switch ($_.Extension)
            {
                '.exe' { $color = "93"; break }
                '.ps1xml' { $color = '32'; break }
                '.dll' { $color = "35"; break }
               default { $color = "0" }
            }
            $e = [char]27
           "$e[${color}m$($_.Name)${e}[0m"
        }
     },Length

     
    "$e[${color}m$($_.Name)${e}[0m"
    "$e[93mTest$e[0m"



      $e = [char]27
      "$([char]27)[${color}m$($_.Name)${e}[0m"

#>




# Show list with header and data with columns defined by $Data.List, ListFormat, ListSort.
# ListFormat defines column width and format: https://docs.microsoft.com/en-us/dotnet/standard/base-types/standard-date-and-time-format-strings
# ListSort define how to sort the values
# From line Start, show Lines lines.
Function Show_List {
    Param (
        $List = $Data.List,
        $ListFormat = $Data.ListFormat,
        [Char]$Fill = ' ',
        [Char]$Delimiter = ' ',
        [hashtable]$Color = @{f = [System.consolecolor]"White"; b = [System.consolecolor]"Black" },
        [Switch]$HideTableHeaders,
        [Switch]$HideTable,
        $Start = $Data.Numbers.ListStart,
        $Lines, # = $Data.Numbers.ListStart,
        $Indent = 2,   # Indent in the left of the list
        [String[]]$Exclude = $Data.ListExclude # Exclude these columns (Use names in ListFormat)
    )

    # 
    If (!$ListFormat) {
        Write-host "ListFormat not defined! Same as property" -ForegroundColor DarkYellow
        return
    }

    # Width of the list
    $ListWidth = ($ListFormat.width | Measure-Object -sum).sum
    $ListWidth += $ListFormat.count + $Indent 
    
    #write-host "Listwidth $Listwidth"
    #write-host "WinWidth $WinWidth"

    $WinHeight = $host.ui.RawUI.WindowSize.Height
    If (!$WinHeight) {$WinHeight = 44}
    $MaxHeight = $WinHeight - 15
    
    $WinWidth = $host.ui.RawUI.WindowSize.width
    If (!$WinWidth) {$WinWidth = 100}
    $PadColWidth = $WinWidth - $ListWidth - 3
    If ($PadColWidth -lt 0) { $PadColWidth = 0 }

    If (!$Lines) {$Lines = $MaxHeight} 
    Elseif ($Lines -lt 0) {$Lines = $MaxHeight = 0}

    If ($List.count -lt $Lines) {$Lines = $List.count}

    #sleep 2

    $ListFormat = $ListFormat | ForEach-Object {
        If ($_.Width -gt 0 -and $_.Name -notin $Exclude) {
            $_
        }
    }
    
    # Make a empty first column, and fill out on the right side
    $ListFormat = @(
        @{
            Name = ""
            Expression = {" "}
            Width = $Indent
        }
    ) + $ListFormat + @{
            Name = ""
            Expression = { ''.PadRight($PadColWidth,'') }
            Width = [int32]($PadColWidth+1)
    }
    
    $ListHeaderFill = $Fill
    $ListHeaderDelim = $Delimiter

    $ArrowUp = "$([char]9650)"
    $ArrowDn = "$([char]9660)"
    $ArrowRt = "$([char]9658)"
    $Block   = "$([char]9608)" 
    $Dots    = "$([char]8230)" # Not quite ellipsis
    $HighLine = "$([char]8254)"
    
    If ($Start -gt 0) { 
        $ListFormat[0].Name = $ArrowUp
        $ListHeaderFill = '_'
        $ListHeaderDelim = $ListHeaderFill
    }

    If (!$HideTableHeaders) {
        $ListTableHeaderString = ""
        $ListFormat | ForEach-Object {
            If ($_.Width -gt 0) {
                $String = $_.Name
                If ($_.Header) { $String = $_.Header }
                If ($_.Width ) {
                    If ($_.Width -le $String.length) {
                        $String = $String.substring(0, $_.Width)
                    }
                    If ($_.Justify -like "Right") {
                        $String = $String.padLeft($_.Width, $ListHeaderFill)
                    } Else {
                        $String = $String.padRight($_.Width, $ListHeaderFill)
                    }
                }
                $ListTableHeaderString += $String + $ListHeaderDelim
            }
        }

        If ($ListTableHeaderString.length -gt $WinWidth + 1) {
            $ListTableHeaderString = $ListTableHeaderString.substring(0,$WinWidth - 2) + $Dots
        }

        Write-Host $ListTableHeaderString.padright($WinWidth).substring(0,$WinWidth - 1) -NoNewline -ForegroundColor $Color.f -BackgroundColor $Color.b
    }

    $TopOfList = $host.UI.RawUI.CursorPosition

    If (!$HideTable) {
        $List | select-object -skip $Start -first $Lines | Format-Table -Property $ListFormat -HideTableHeaders | Out-Host 

        # Format-table creates two empty lines... Move up 2
        $Pos = New-Object System.Management.Automation.Host.Coordinates
        $Pos.Y = $host.UI.RawUI.CursorPosition.Y - 2
        $Pos.X = $host.UI.RawUI.CursorPosition.X
        $host.UI.RawUI.CursorPosition = $Pos
    }
    
    If (($Start + $Lines) -lt $List.count) {
        Write-host $ArrowDn.PadRight($WinWidth - 1, $HighLine) #  $_.PadChar
        # Write-host $ListTableHeaderString
    } else {
        Write-host ' '.PadRight($WinWidth, $Fill) #  $_.PadChar
    }

    # Show 'scrollbar' as indicator of list position
    <#
    If ($List.Count -gt $Lines) {
        $Factor = $Lines / ($List.Count + 1)
        $Top  = $TopOfList.Y + .5 + ($Start * $Factor)
        $Heigth = $Lines * $Factor
        $Bottom = $Top + $Heigth
        Clear-Rect -Top $Top -Bottom $Bottom -Left 0 -Right 0 -Char $Block
    }
    #>

    Return $Lines
}


$Dialog_ManageJobs = @{
    Title = "Manage jobs"
    Execute_Clear = "DialogTop"
    # NoEnter = $True

    NoAutoListUpdate = $True
    # NoAutoListUpdate = $True # Don't update list after every action. For exception actions set.UpdateList=$true or dialogs: $UpdateList=$true 
    # AutoListUpdate = $AutoListUpdate   # Set default. If $false, for exception actions set $UpdateList=$true or $NoUpdateList=$true, for excep


    # Manage all jobs for this repository (any storage)
    # (A job might not be scheduled so i chose not to call it a Task)

    # $Data.List contains the 0-based clear-text info on job
    # $List.SelectedItem ($ListSelectedItem) points to current selection
    # Just changing selections should not require refresh (if not showing details)
    # ListSelect -item $ListSelectedItem to set selection
    # $Data.Numbers defines info for list.

    # Format of the list
    ListFormat = @(
        @{
            Name = "Job"
            Expression = {
                $Val = $_.Name
                If ($_.Actions -eq "Missing job") {
                    #$Val = "<Missing job>"
                    $ANSIColor = $a_BrightYellow
                    "$ANSIColor$($Val)$a_Reset"
                } Else {
                    $Val
                }
            }
            Width = 20
        }
        @{
            Name = "Storage"
            Expression={
                If ($_.Actions -eq "Missing job") {
                    $Val = "<Missing job>"
                    $ANSIColor = $a_BrightYellow
                    "$ANSIColor$($Val)$a_Reset"
                } Else {
                    $_.Actions[0].Fields.Storage
                }
            }
            Width = 15
        }
        @{
            Name = "Acts" # ions
            Expression = { ($_.Actions).Count }
            Width = 3
        }
        @{
            Name = "ScheduledState"
            Width = 15
            Expression = {
                switch ($_.Schedule.State) {
                    'Disabled' { $ANSIColor = $a_BrightRed;   break }
                    'Ready'    { $ANSIColor = $a_BrightGreen; break }
                    "(No schedule)" { $ANSIColor = $a_ColNotScheduled; break }
                    default    { $ANSIColor = $a_BrightYellow }
                }
                "$ANSIColor$($_.Schedule.State)$a_Reset"
           }
        }

        @{
            Name = "Trigger"
            Expression={
                switch ($_.Schedule.Triggers[0].Enabled) {
                    $True     { $ANSIColor = $a_BrightGreen; $X = 'TEnbld'}
                    $False    { $ANSIColor = $a_BrightRed;   $X = 'TDis'}
                    Default   { $ANSIColor = $a_BrightRed;   $X = 'TDis'}
                }
                "$ANSIColor$("$X")$a_Reset"
            }
            Width = 7
        }
        @{
            Name = "NextRun"
            Expression={$_.ScheduleInfo.NextRunTime}
            Width = 20
        }
        @{
            Name = "LastRun"
            Expression={$_.ScheduleInfo.LastRunTime}
            Width = 20
        },
        @{
            Name = "Days"
            Expression={$_.Schedule.Triggers[0].DaysInterval}
            Width = 5
        }
    )

    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Repo = $Data.Parameters.Repository
        $Data.RepoIsInitialized = Test-Path "$Repo\.Duplicacy\preferences"
        If (!$Data.RepoIsInitialized) {
            Write-Host "This repository is not initialized. From main meny: Manage/Init" -ForegroundColor Red
        }

        # Make $Data.Task with hashtable (all tasks for this repository)
        # Make $Data.List with some properties, as a list that can be shown as format-table
        # TaskList_Init $Repo
    }

    ListUpdateScript = {
        # populate the list for this dialog
        TaskList_Init $Repo     # (This funtion updates $Data.List directly)

        #Set-PSDebug -Step

        If (!$Data.List) {
            Write-host "There are no jobs for this repository."
            Write-host "To make a job: From main screen, go to Manage storages, select an operation (e.g. backup), then Add to task"
            Get-Choice "Enter to continue"
            # $Data.ExitDialog = $True # This will exit the dialog
            return 'Cancel'
        }
    }

    Script_MissingJob = {
        # .BelongsTo
        $ScheduledName = $data.List[$ListSelectedItem].Schedule.Taskname
        write-host "`n`nMissing job for Scheduled Job '$ScheduledName'?`nThis schedule does not match any job for this repository.`nIt might be for the same storage but a different set of settings.`nIf you are sure it's not needed, you can Unregister in the (S)chedule menu."
        Blink "Missing job"
    }

    Script_DontRename = {
        write-host "`n`nThis job has a schedule and should not be changed. Unregister in the (S)chedule menu, and reschedule after."
        Blink "Don't change a scheduled job"
    }

    Actions = [Ordered]@{
        Edit = @{
            Text = "&Edit job"
            Help = "Edit job"
            Action = {
                If ( $data.List[$ListSelectedItem].Actions -match "Missing job") { 
                    Invoke-Command $data.Script_MissingJob
                    return
                }
                Ask-Dialog $Dialog_EditJob -Parameters @{Job = $data.List[$ListSelectedItem]}
            }
        }

        Rename = @{
            Text = "&Rename job name"
            Help = "Rename the selected job"
            Action = {
                If ($data.List[$ListSelectedItem].Actions -eq "Missing job") {
                    Invoke-Command $data.Script_MissingJob
                    return
                }
                If ( $data.List[$ListSelectedItem].Schedule.State -notlike '(No schedule)' ) { 
                    Invoke-Command $data.Script_DontRename
                    return
                }
                $R = Ask-Dialog $Dialog_EditField -ReturnData -Wizzard -Parameters @{ 
                    Title = "Job name"
                    Name = "JobName"
                    Help = "Enter the new job name"
                    Value = $data.List[$ListSelectedItem].Name
                }
                If ($R.OK) {
                    $data.List[$ListSelectedItem].Name = $R.Fields.Input.Value
                }
            }
        }

        ScheduleTask = @{
            Text = "&Schedule"
            Help = "Modify the schedule for the seleted task, or remove"
            Action = {
                If ( $data.List[$ListSelectedItem].Name -match "Missing job: " ) { 
                    #Invoke-Command $data.Script_MissingJob
                    #return
                    Write-host "(Job definition is missing. You can still change schedule even though it will not work)"
                }
                $ScheduleResult = Ask-Dialog $Dialog_ScheduleJob -ReturnData -Parameters @{ Task = $data.List[$ListSelectedItem] }
                If ($ScheduleResult.OK) {
                    Invoke-Command $data.ListUpdateScript
                }
                $RefreshList = $true
                $ClearListBackground = $true
            }
        }

        Delete = @{
            Text = "&Delete"
            Help = "Delete selected job"
            Action = {
                If ( $data.List[$ListSelectedItem].Schedule.State -notlike '(No schedule)' ) { 
                    Invoke-Command $data.Script_DontRename
                    return
                }

                # Ask-Dialog $Dialog_List -Parameters @{Storage = $data.List[$ListSelectedItem]}
                #Write-Host "Name: $($data.List[$ListSelectedItem].Name)"
                # Write-Host "Index: $ListSelectedItem"
                #$data.List[$ListSelectedItem] | Out-Host

              #  If ((Read-Host "Delete the job '$($data.List[$ListSelectedItem].Name)'?") -notlike "y*")  {return}

                # If ((Get-Choice -Menu "Delete the job '$($data.List[$ListSelectedItem].Name)'?").KeyName -ne "D") {return}

                $Jobmsg = $($data.List[$ListSelectedItem].Name)
                $x = Get-Choice -Message "Delete the job '$Jobmsg'?" -help "Changes will be saved when you confirm the Jobs dialog"
                If ($x.KeyName -ne "Y" -and $x -notlike "OK") {return}

                $data.List[$ListSelectedItem].Name = "_DELETED_"
            }
        }



        <#
        Run = @{
            Text = "&Run (?)"
            Help = "Run selected task by starting schedule"
            Action = {
                If ( $data.List[$ListSelectedItem].Name -match "Missing job: " ) { 
                    Invoke-Command $data.Script_MissingJob
                    return
                }
                
                # Ask-Dialog $Dialog_List -Parameters @{Storage = $data.List[$ListSelectedItem]}
                Write-Host "Run task on demand..."
                sleep 3
            }
        }#>
    }


    Executescript = {
        # Save the jobs from the list into the tasks file in the backup set
        $Jobs = $Data.List | GetDCJobFromDataList



        Save-DCJob -Path $Repo -Jobs $Jobs
    }

} # ManageTask


# Take data.list from ManageTask dialog
# Get job properties needed to save
Function GetDCJobFromDataList  {
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
            $collection = @(
                foreach ($object in $InputObject) { ConvertJobfileToObject $object }
            )
            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject] -and $InputObject.Actions -ne $null -and $InputObject.Actions[0] -is [psobject]) {
            # Make jobs
            $hashjob = @{}
            foreach ($Job in ($InputObject | Where-Object Name -ne "_DELETED_")) {
                $hashjob.Name = $Job.Name
                $hashjob.Actions = @(
                    $Job.Actions | Where-Object Name -ne "_DELETED_" | foreach-object {
                        @{
                            Fields = $_.Fields | Get-ActionFieldValues
                         Arguments = $_.Arguments
                              Name = $_.Name
                             Order = $_.Order
                    ActionSettings = $_.ActionSettings
                         }
                    }
                )
            }
            [PSCustomObject]$hashjob
        }
        else { return $null }
    }
}



# General purpose input field. Use -Parameters to populate field properties
$Dialog_EditField = @{
    Title = '%TITLE%'
    Fields = [ordered]@{
        Input = @{
            Text = "Edit"
            Help = "Edit field"
            InitScript = {
                $Field.Text = $Data.Parameters.Text
                $Field.Help = $Data.Parameters.Help
                $Data.Parameters.Value
            }
        }
    }
    InitScript = {
        $Data.Title = $Data.Title -replace '%TITLE%', $Data.Parameters.Title
    }
} # EditField




$Dialog_EditJob = @{
    #Title = 'Edit job (Job name and actions) $($Data.Parameters.Job.Name)'
    Title = 'Manage actions in "%JOB%"'
    #NoEnter = $True
    Execute_Clear = "DialogTop"

    Help = "Note: Changes to actions are not saved until the job is saved!"

    # Edit a job
    # $Data.List contains actions
    # Name of the job can be changed
    # $List.SelectedItem ($ListSelectedItem) points to current action
    
    # Format of the list
    ListFormat = @(
        @{
            Name = "Action"
            Expression = {$_.Name}
            Width = 20
        }
        @{
            Name = "Command"
            Expression={$_.Fields.Command}
            Width = 15
        }
        @{
            Name = "Arguments"
            Expression={$_.Arguments -join ' '}
            Width = 60
        }
    )
    
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Repo = $Data.Parameters.Repository
        $Data.RepoIsInitialized = Test-Path "$Repo\.Duplicacy\preferences"
        If (!$Data.RepoIsInitialized) {
            Write-Host "This repository is not initialized. From main meny: Manage/Init" -ForegroundColor Red
        }
        #Write-host "Job: $($Data.Parameters.Job.Name)"
        $Data.Title = $Data.Title -replace '%JOB%', $Data.Parameters.Job.Name
    }

    ListUpdateScript = {
        $Data.List = $Data.Parameters.Job.Actions
    }

    Actions = [Ordered]@{
        Edit = @{
            Text = "&Edit"
            Help = "Edit selected action"
            Action = {
                $data.List[$ListSelectedItem] = Edit-Action $data.List[$ListSelectedItem]
            }
        }

        Config = @{
            Text = "&Config action settings"
            Help = "Change action settings"
            Action = {
                #$data.List[$ListSelectedItem] = Edit-Action $data.List[$ListSelectedItem]


                If ($R = Ask-Dialog $Dialog_EditActionSettings -ReturnFields -Values $data.List[$ListSelectedItem].ActionSettings) {
                    # Set-PSDebug -Step
                    $data.List[$ListSelectedItem].ActionSettings = $R
                    $R = $null
                }
                # -Parameters @{Action = $data.List[$ListSelectedItem]}
            }
        }


        Rename = @{
            Text = "&Rename action name"
            Help = "Rename the selected action."
            Action = { 
                $R = Ask-Dialog $Dialog_EditField -ReturnData -Wizzard -Parameters @{ 
                    Title = "Action name"
                    Name = "ActionName"
                    Help = "Enter the new action name"
                    Value = $data.List[$ListSelectedItem].Name
                }
                If ($R.OK) {
                    $data.List[$ListSelectedItem].Name = $R.Fields.Input.Value
                }
            }
        }

        Move = @{
            Text = "&Move"
            Help = "Move item in the list"
            Action = {
                # Ask-Dialog $Dialog_List -Parameters @{Storage = $data.List[$ListSelectedItem]}
                Write-Host "Arrange list..."
                sleep 3
            }
        }

        Delete = @{
            Text = "&Delete"
            Help = "Delete selected action"
            Action = {
                # Ask-Dialog $Dialog_List -Parameters @{Storage = $data.List[$ListSelectedItem]}
                #Write-Host "Name: $($data.List[$ListSelectedItem].Name)"
                #Write-Host "Index: $ListSelectedItem"
                #$data.List[$ListSelectedItem] | Out-Host

#                If ((Read-Host "Delete the action '$($data.List[$ListSelectedItem].Name)'?") -notlike "y*")  {return}
                # If ((Get-Choice -Menu "Delete the action '$($data.List[$ListSelectedItem].Name)'?").KeyName -ne "D") {return}
                $Jobmsg = $($data.List[$ListSelectedItem].Name)
                $x = Get-Choice -Message "Delete the action '$Jobmsg'?" -help "Changes will be saved when you confirm the Jobs dialog" 
                If ($x.KeyName -ne "Y" -and $x -notlike "OK") {return}

                $data.List[$ListSelectedItem].Name = "_DELETED_"

                #Return
            }
        }

    }
} # EditJob



$Dialog_EditActionSettings = @{
    # Edit other action settings (send report on success - stop on error - etc)
    Title = "Edit action settings"
    Help = ""

    Fields = [Ordered]@{
        HTTP_TEXT = @{
            Text = 'On action send HTTP'
            Help = 'Send a HTTP report on success. Healthchecks.io' 
            Config = @{
                Title = "URL to post on success"
                ValidateScript = {
                    #If (!$FieldValue) { Return "Name is required!" }
                    #$Repo = $Script:Repositories[$Script:SelectRepo - 1].FullName
                    #$Repo = $Data.Parameters.Repository
                    #If ($FieldValue -and !(Test-Path -isvalid -Path "$Repo\FieldValue"))  { Return "Invalid file name format!"}
                    #If ($FieldValue -and (Test-Path -Path "$Repo\$FieldValue")) { Return "SymLink already exist!"}
                }
            }
        }

        HTTP_TEXT_ERROR  = @{
            Text = 'On error send HTTP'
            Help = 'Send a HTTP report on error. Healthchecks.io' 
            Config = @{
                Title = "URL to post for error"
                ValidateScript = {
                    #If (!$FieldValue) { Return "Name is required!" }
                    #$Repo = $Script:Repositories[$Script:SelectRepo - 1].FullName
                    #$Repo = $Data.Parameters.Repository
                    #If ($FieldValue -and !(Test-Path -isvalid -Path "$Repo\FieldValue"))  { Return "Invalid file name format!"}
                    #If ($FieldValue -and (Test-Path -Path "$Repo\$FieldValue")) { Return "SymLink already exist!"}
                }
            }
            #EnableScript = {
            #    $Settings.InitAdvanced
            #}
        }

        StopOnError = @{
            Type = 'Boolean'
            Text = 'Stop on error'
            Help = "Stop if this action is not succesfull"
            Config = @{
                #Hint = "Interval type (day or week)"
                States = @{
                    $True = "Stop"
                    $False = "Continue"
                }
            }
        }
    }
} 






$Dialog_ScheduleJob = @{
    Title = "Schedule Job"
    
    # Schedule task

    # https://devblogs.microsoft.com/scripting/use-powershell-to-create-scheduled-tasks/

    # Register or change schedule for selected job
    # Weekly (select days and etc. o)
    # Should support at start/logon in case of a healthcheck?

    # If already scheduled, disable?

    # Modify:
    #https://docs.microsoft.com/en-us/powershell/module/scheduledtasks/set-scheduledtask?view=win10-ps
    #$Time = New-ScheduledTaskTrigger -At 12:00 -Once
    #Set-ScheduledTask -TaskName "SoftwareScan" -Trigger $Time
    
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        # Is task already scheduled?
        If ($Data.parameters.task.schedule.triggers.count -gt 0) {
            $ThisTrigger = $Data.parameters.task.schedule.triggers[0]

            If ($ThisTrigger.Enabled) {
                # ...
            }
        } ELse { $ThisTrigger = "" }
    }

    Fields = [Ordered]@{
        StartTime = @{
            Text = 'At'
            Help = "Time to start task"
            # Type = 'Boolean'
            # Value = $false
            InitScript = {
                If ($ThisTrigger) {
                    #$ThisTrigger.startboundary # 2020-06-19T11:11:22+02:00

                    $Test = $ThisTrigger.startboundary -replace "T.*"

                    $SchedDate = [datetime]::ParseExact($Test, 'yyyy-MM-dd', $null) # 2020-06-19T11:11:22+02:00
                    If ($SchedDate -gt (Get-Date)) {
                        Write-host "Dato $SchedDate is in the future"
                        Return $ThisTrigger.startboundary
                    } Else {
                        Write-host "Dato $SchedDate is in the past, only need time"
                        $Test = $ThisTrigger.startboundary -replace "^[0-9-]+T" -replace "[+-][0-9:]*$"
                        Return $Test
                    }

                } Else {
                    #Write-host -ForegroundColor Yellow "NO triggers!"
                    Return get-date -Format "HH:mm:ss"
                }
            }
            Config = @{
                Hint = "Start time as HH:mm"
                ValidateScript = {
                    If ($FieldValue) {
                        If ($FieldValue -match "^[0-2][0-9]:[0-5][0-9]$") {
                            $FieldValue = "$FieldValue:00"

                            # 2020-06-19T11:11:22+02:00
                            # ^[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]T[0-2][0-9]:[0-5][0-9]:[0-5][0-9]$"
                        }

                        # Recognize 3 formats.
                        # 11:11:22
                        # 2020-06-19 11:11:22
                        # 2020-06-19T11:11:22
                        # 2020-06-19T11:11:22+02:00
                        If ($FieldValue -notmatch "^[0-2][0-9]:[0-5][0-9]:[0-5][0-9]$|^[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9][T ][0-2][0-9]:[0-5][0-9]:[0-5][0-9]([+-][0-9][0-9]:[0-9][0-9])*$") {
                            Return "Unrecognized format for date/time - (bug in config)"
                        }
                    }
                }
            }
        }

        <#
        Interval = @{
            Text = 'Every'
            Help = "day or week interval"
            InitScript = {
                If ($ThisTrigger) {
                    $ThisTrigger.DayInterval + $ThisTrigger.WeekInterval
                } Else {
                    Write-host -ForegroundColor Yellow "Int. number: No interval! defined. 1"
                    1
                }
            }
            Config = @{
                Hint = "Every n (day or week)"
            }
        }#>

        Interval = @{
            Text = 'Every'
            #EnableScript = {
                #$Settings.InitAdvanced
                #$T = $Data.parameters.task.schedule.triggers[0]
                #$ThisTrigger.WeeksInterval -or $ThisTrigger.DaysInterval
                #Write-Host "(Test) Interval: " ($T.WeeksInterval + $T.DaysInterval)

            #}
            InitScript = {
                #$T = $Data.parameters.task.schedule.triggers[0]
                #($T.WeeksInterval + $T.DaysInterval)
                write-host "Item interval text: $($_.Text)" -ForegroundColor Yellow
                If (!$ThisTrigger) {
                    Return 1
                } Else {
                    $ThisTrigger.WeeksInterval + $ThisTrigger.DaysInterval
                }
                
            }
            Help = "Interval between schedules"
            Config = @{
                Min = 1
                ValidateScript = {
                    If (!$FieldValue -or $FieldValue -lt 1) {$FieldValue = 1}
                }
            }
        }

        IntervalIsWeek = @{
            Type = 'Boolean'
            Text = ''
            Help = "Interval type (day or week)"
            InitScript = {
                If ($ThisTrigger) {
                    If ($ThisTrigger.DaysInterval) {
                        $false # IsDay
                    } Else {
                        $True  # IsWeek
                        If (!$ThisTrigger.WeeksInterval) {
                            Write-host -ForegroundColor Yellow "Intervaltype: No interval defined"
                            $false
                        }
                    }
                } Else {
                    Write-host -ForegroundColor Yellow "Intervaltype: No trigger defined"
                    $false
                }
            }
            Config = @{
                Hint = "Interval type (day or week)"
                <#ValidateScript = {
                    #If (!$FieldValue) {$FieldValue = "day"}
                    $FieldValue = Switch -Regex ($FieldValue) {
                            "d|da|day"      {"Day"}
                        "w|we|wee|week" {"Week"}
                        Default         {"day"}
                    }
                }#>
                States = @{
                    $True = "Weeks"
                    $False = "Days"
                }
            }
        }


        Weekly = @{
            Text = 'WeekDays'
            Help = "Which days should task run"
            EnableScript = {
                #$Data.parameters.task.schedule.triggers[0].WeeksInterval -gt 0
                $ThisTrigger.WeeksInterval -gt 0 -or !$ThisTrigger
            }
            InitScript = {
                # $Data.parameters.task.schedule.triggers[0].DaysOfWeek
                If ($ThisTrigger.WeeksInterval) {
                    $ThisTrigger.DaysOfWeek
                    # Accepted values:	Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
                } Else {
                    Write-host -ForegroundColor Yellow "NO week interval!"
                    # Return "1,2,3,4,5,6,7"
                    Return "0"
                }
                
                # $Data.parameters.task.schedule.triggers[0].DaysInterval
                # $data.parameters.task.schedule.triggers[0].repetition.interval  
            }
            Config = @{
                Hint = "bit-and list of days"
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *, *", "," -replace " +", "," -replace "[,-] *$", ""
                    If ($FieldValue -and $FieldValue -notmatch "^[a-zA-Z0-9,]+$")  {
                        # "Specify an array of days: "monday", "tuesday"...
                        #Return # "Specify an array of days: "monday", "tuesday"...
                    }
                }
            }
        }
        
        Enabled = @{
            Text = 'Enabled'
            Help = "Enable or disable the trigger"
            InitScript = {
                # $Data.parameters.task.schedule.triggers[0].Enabled
                If ($ThisTrigger) {
                    $ThisTrigger.Enabled
                } Else {
                    $true
                }
            }
            Type = 'Boolean'
            Config = @{
                States = @{
                    $True  = "On  (Scheduled)"
                    $False = "Off "
                }
                ValidateScript = {
                    If ($FieldValue) {
                        #$Temp = $FieldValue
                        #$FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                        #If ($Temp -match "[^a-z0-9-_]") {
                        #    Return "Contains unaccepted characters for ID"
                        #}
                    }
                }
            }
        }
    }


    Actions = [Ordered]@{
        # Weekly 
        # Daily
        # At logon
        # At startup

        # Unschedule task
        
        Unschedule = @{
            NoValidate = 1
            Return = 1
            Text = "Unregister schedule"
            Help = "Unregister the selected job."
            Action = {
                $RepoName = Split-Path $Data.Parameters.Repository -Leaf
                $TaskNameBase = "DucyBackup ($RepoName) "
                $TaskName = "$TaskNameBase$($data.Parameters.Task.Name)"
                write-host "Unregistering '$TaskName'"
                Unregister-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -Confirm:$false
                Return @{OK = $True; Result = 'OK'}
            }
        }
    }

    ExecuteScript = {
        # Make the new trigger
        #  - If registered, just update trigger
        #  - If not, register new scheduled-task
        #  - Read task again (or Update data.list but more complicated)

        $repo = $Data.Parameters.Repository
        $RepoName = Split-Path $Repo -Leaf
        $TaskNameBase = "DucyBackup ($RepoName) "

        $DucyParameters = @(GetDialogParameters $Data)

        $TaskName = "$TaskNameBase$($data.Parameters.Task.Name)"
        $TaskStartTime = $data.Fields.StartTime.Value

        <#      -DaysOfWeek
        Specifies an array of the days of the week on which Task Scheduler runs the task.
        Type:	DayOfWeek[]
        Accepted values:	Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday
        #>

        If (!$Data.Parameters.IntervalIsWeek) { # Daily
            $Time = New-ScheduledTaskTrigger -At $TaskStartTime -Daily -DaysInterval $data.Fields.Interval.Value
        } Else { # Weekly
            $Time = New-ScheduledTaskTrigger -At $TaskStartTime -Weekly -WeeksInterval $data.Fields.Interval.Value # -DaysOfWeek
        }

        $Time.Enabled = $data.Fields.Enabled.Value

        Write-Host "TaskName and time: $TaskName $TaskStartTime"
        Write-Host "VBS: $Scriptpath\ducybackup.vbs"

        $VBSWindowsStyle = 0

        If (!$ThisTrigger) {
            $Action = New-ScheduledTaskAction -Execute "wscript.exe" -Argument   "//nologo `"$Scriptpath\ducybackup.vbs`" /winstyle:$VBSWindowsStyle -Job `"$($data.Parameters.Task.Name)`" -path `"$Repo`""
                # -Argument '"& {write-host $host; sleep 10  }"  '
            
            $x = Register-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName  -Trigger $Time `
                -Action $Action -Description "A scheduled task for DucyBackup. Repository: $Repo"

            # -RunLevel Limited, Highest
            #Specifies the required privilege level to run tasks that are associated with the principal.
        } Else {
            $x = Set-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -Trigger $Time

            # -ThrottleLimit 22 
            # -asjob (long work as background) 

            #Set-PSDebug -Step

            # $ThisTrigger.WeeksInterval + $ThisTrigger.DaysInterval
            # Set-ScheduledTask -TaskName $TaskName -Trigger $Time -Action ... -TaskPath ... -Settings ...
        }

        #StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        #If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
        #IF ($Data.Fields.Encrypt.Value) {
        #    Write-Host "Invoking the 'list' command to store encryption password"
        #    $ListARg = "list", "-storage", $Data.Fields.StorageName.Value
        #    StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg
        #    If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
        #}

    }



} # ScheduleTask





$Dialog_Manage = @{
    # Definition of the Manage backup (repositories) dialog 
    Title = "Manage storages"

    # This dialog lets user chose a storage and perform a command on it

    # $Data.DialogListScript is a script to print the list
    # In this dialog, 
    # $Data.List contains the 0-based clear-text info on storages
    # $Data.Storages contains a 0-based list of storages
    # $ListSelectedItem points to current sect.
    # Set $RefreshList = $true to update (reruns DialogListScript)
    # Just changing selections should not require refresh (if not showing details)
    # ListSelect -item $ListSelectedItem to set selection
    # $Data.Numbers defines info for list. Text
    
    NoEnter = $True

    Actions = [Ordered]@{ 
        Init = @{
            # New Backup Set normally does this but if you already had a folder:
            Text = "&Initialize"
            Help = "Initialize this repository and the first storage"
            Action = {
                Ask-Dialog $Dialog_Init -Parameters $Data.Parameters
                $RefreshList = $true
                $UpdateList = $true

            }
            EnableScript = { !$Data.RepoIsInitialized }
        }

        Add = @{
            Text = "&Add storage"
            Help = "Add another storage destination for selected repository"
            Action = {
                Ask-Dialog $Dialog_AddStorage -Parameters @{Storage = $data.List[$ListSelectedItem]} 
                $RefreshList = $true
                $UpdateList = $true
            }

            # $Data.List[$ListSelectedItem].FullName
            EnableScript = { $Data.RepoIsInitialized }
        }

        Backup = @{
            Text = "&Backup"
            Help = "Backup to the selected storage"
            Action = { 
                #Write-Host "Invoking the 'backup' command"
                #$ListARg = "backup", "-storage", $data.List[$ListSelectedItem].name
                #StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg
                #$RefreshList = $true

                Ask-Dialog $Dialog_Backup -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized -and $Data.List.Count -gt 0}
        }

        List = @{
            Text = "&List"
            Help = "List storage information. (Also stores the encryption password)"
            Action = {
                Ask-Dialog $Dialog_List -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized -and $Data.List.Count -gt 0}
        }

        Check = @{
            Text = "Chec&k"
            Help = "Check snapshots (check that all chunks exist) and display information about snapshots"
            Action = {
                Ask-Dialog $Dialog_Check -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized -and $Data.List.Count -gt 0}
        }

        Copy  = @{
            Text = "&Copy"
            Help = "Copy from one storage to another storage (e.g. local to cloud)"
            Action = {
                Ask-Dialog $Dialog_Copy -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {
                $Data.RepoIsInitialized -and $Data.List.Count -gt 1
            }
        }

        Prune = @{
            Text = "&Prune"
            Help = "Remove snapshots from storage. This is a two-stage process. Read more on Duplicacy.com!"
            Action = {
                Ask-Dialog $Dialog_Prune -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized}
        }
        
        
        Benchmark = @{
            Text = "&Benchmark"
            Help = "Benchmark the storage. Writes and reads data to measure performance"
            Action = {
                Ask-Dialog $Dialog_Benchmark -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized}
        }


        Restore = @{
            Text = "&Restore"
            Help = "Restore the repository to a previous state"
            Action = { 
                # Write-Host "Invoking the 'restore' dialog with parameters"
                Ask-Dialog $Dialog_Restore -Parameters @{Storage = $data.List[$ListSelectedItem]}
            }
            EnableScript = {$Data.RepoIsInitialized -and $Data.List.Count -gt 0}
        }

        # Not now
        <#
        AddStorage = @{
            Text = "Add Storage definition..."
            Help = "Create a new storage definition"
            Action = { Ask-Dialog $Dialog_NewStorage }
            Enable = $false
        }#>


        Symlink = @{
            Text = "S&ymlink"
            Help = "Create symlink"
            Action = {
                #$Data.Parameters.Repository = $Data.List[$ListSelectedItem]
                #$Data.Parameters.Repository
                Ask-Dialog $Dialog_NewSymLink # -Parameters $Data.Parameters
            }

            # Return (clear, execute, return) or just exeute?            
            EnableScript = {
                #Write-host "InitAllowSymlink: $($Settings.InitAllowSymlink)"
                $Settings.InitAllowSymlink -and $data.List.count -and $data.List[0].repository -eq ""
                #Set-PSDebug -Step
            }
        }

        # Not now
        EditFilters = @{
            Text = "Edit filters"
            Help = "Edit the filters file."
            Action = { 
                $Filters = "$($Data.Parameters.Repository)\.Duplicacy\filters"
                write-host "Filters: $Filters"
                $TestFilters = "$($ENV:TEMP)\TempFilters.txt"
                If (!(Test-Path $Filters)) {
                    # "# Filters" | Set-Content $Filters
                    "# Filters" | Out-File $Filters
                }
                Get-Content $Filters | Set-Content $TestFilters
                Start-Process -FilePath 'notepad.exe' -ArgumentList $TestFilters -Wait
                Get-Content $TestFilters | Set-Content $Filters
                

            }
            Enable = $true
        }




    }
        
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Repo = $Data.Parameters.Repository
        $Data.RepoIsInitialized = Test-Path "$Repo\.Duplicacy\preferences"

        # Earlier, this form needed to know number of storages before dialoglistscript (is any repositories initialized)
        #$Data.List = @(Read-Pref erences $Repo)
        #$Data.List = @(Get_Storage $Repo)

        $Data.Actions.Symlink.Enable = $Settings.InitAllowSymlink # -and (!$Data.List.repository)
    }

    ListUpdateScript = {
        $Data.List = @(Get_Storage $Repo)
        
#        Set-PSDebug -Step

        
        $ListSimple = ( 
            ( ($Data.List.ID         | Select-Object -Unique).count -eq 1 -and
              ($Data.List.Repository | Select-Object -Unique).count -eq 1) -and 
            !$Settings.InitAdvanced
        )

        If ($ListSimple) {
            #write-host 'SIMPLE'
            $Data.ListExclude = 'ID', 'Repository'
        } Else {
            #write-host 'NOT SIMPLE'
            $Data.ListExclude = $Null
        }
    }

    

    # Format of the list. Show if password missing.
	# 	If ($Item.encrypted -and !$Item.PasswordStored) {$MissingPwd = $True}
    ListFormat = @(
        @{
            Name = "Name"
            Expression = {$_.Name}
            Width = 12
        },
        @{
            Name = "ID"
            Expression = { $_.ID}
            Width = 15
        },
        @{
            Name = "Encrypted"
            Expression = {
                Switch ($_.encrypted) {
                    $true {
                        "$a_BrightGreen$("Y")$a_Reset"
                    }
                    $false {
                        "$a_BrightRed$("n")$a_Reset"
                    }
                }
            }
            Width = 3
        },
        @{
            Name = "Pwd"
            Expression = { 
                # $_.PasswordStored }
                If ($_.encrypted -like 'True') {
                     If ($_.PasswordStored ) { # -like "Yes"
                        $ANSIColor = $a_ColDefault # Define if you want a color.. Default none
                        Return "$ANSIColor$("OK")$a_Reset"
                    } Else {
                        $ANSIColor = $a_BrightRed
                        Return "$ANSIColor$("No")$a_Reset"
                    }
                } Else { "n/a" }
            }
            Width = 3
        },
        @{
            Name = "Repository"
            Expression = { $_.repository }
            Width = 20
        },
        @{
            Name = "storage"
            Expression = { $_.storage }
            Width = 50
        }
    )
} # Manage







<#
SYNOPSIS:
   duplicacy check - Check the integrity of snapshots

USAGE:
   duplicacy check [command options]

OPTIONS:
   -all, -a                 check snapshots with any id
   -id <snapshot id>        check snapshots with the specified id rather than the default one
   -r <revision> [+]        the revision number of the snapshot
   -t <tag>                 check snapshots with the specified tag
   -fossils                 search fossils if a chunk can't be found
   -resurrect               turn referenced fossils back into chunks
   -files                   verify the integrity of every file
   -stats                   show deduplication statistics (imply -all and all revisions)
   -tabular                 show tabular usage and deduplication statistics (imply -stats, -all, and all revisions)
   -storage <storage name>  retrieve snapshots from the specified storage```
#>
$Dialog_Check = @{
    # Check the integrity of snapshots
    Title = "Check integrity of snapshots"
    # Wizzard = $True

#    Help = @"
#Go to the Duplicacy Forum to find more information
#"@

    Actions = [Ordered]@{
        AddAction = $Action_AddAction
        Advanced = $Dialog_Init.Actions.Advanced
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum

    }
    
    Fields = $Global_Fields + [Ordered]@{
        Command = @{
            Hidden = $True
            Parameterbuild = "Value"
            Value = "check"
        }

        Cap_Include = @{
            Order = 0
            Text = "Include:"
            Type = "Caption"
        }
        
        all = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = "Match &all snapshot IDs"
            Help = @"
Include any snapshots IDs in the storage. 
By default, only snapshots from current repository are included.
"@
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Include all snapshots in storage)"
                    $False = "Off "
                }
            }
        }

        # ID will be calculated from path
        # In advanced mode, enable the field for manual input
        #            EnableScript = {$Settings.InitAdvanced}
        id = @{
            Text = '&ID'
            EnableScript = {$Settings.InitAdvanced}
            Help = "Include this repository ID (Default). (If empty, include any ID in storage)"
            Config = @{
                ValidateScript = {
                    If ($FieldValue) {
                        $Temp = $FieldValue
                        $FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                        If ($Temp -match "[^a-z0-9-_]") {
                            Return "Contains unaccepted characters for ID"
                        }
                    }
                }
            }
        }

        revision = @{
            Parameter = "r"
            ParameterBuild = 'Multi'
            Text = 'Revision(s)'
            Help = 'Revisions to include: Ranges and single revisions, e.g. 1,3-5'
            Config = @{
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *- *", "-" -replace " *, *", ","  -replace " +", "," -replace "[,-] *$", ""
                    If ($FieldValue -and $FieldValue -notmatch "^[0-9]+$|^[0-9]+[0-9-,]*[0-9]$")  { # Currently, 4- and -4 not allowed.
                        Return "Specify a comma separated list, e.g. 1,3,4-6"
                    }
                }
                Hint = "Comma separated (1,3-5)"
            }        
        }

        tag = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "t"
            ParameterBuild = "Multi"
            Text = 'Tag(s)'
            Help = 'Include revisions with this tag.'  
            Config = @{
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *, *", "," -replace " +", "," -replace "[,-] *$", ""
                    If ($FieldValue -and $FieldValue -notmatch "^[a-zA-Z0-9,]+$")  {
                        Return "Specify a comma separated list, e.g. a,b"
                    }
                }
                Hint = "Comma separated"
            }        
        }

        Cap_opt = @{
            EnableScript = { $Data.ShowAdv }
            Order = 0
            Text = "Options:"
            Type = "Caption"
        }

        fossils = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Search &fossils'
            Help = "Search fossils if a chunk cannot be found"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Search fossils)"
                    $False = "Off "
                }
            }
        }

        ressurect = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Ressurect fossils'
            Help = "Turn referenced fossils back into chunks"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Ressurect fossils into chunks)"
                    $False = "Off "
                }
            }
        }

        files = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Verify &files'
            Help = "Verify the integrity of every file. This will download all files. Please read forum info first"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Download and verify all files - are you sure?)"
                    $False = "Off "
                }
            }
        }

        stats = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Show dedup &stats'
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On"
                    $False = "Off "
                }
            }
        }

        tabular = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Show &use and dedup stats'
            Type = 'Boolean'
            Value = $True
        }

        # Storage-name
        StorageName = @{
            Hidden = $true
            Parameter = "storage"
            Text = 'Storage &Name'
            Help = 'Specify which storage to check' 
            Config = @{
                ValidateScript = {
                    If ($FieldValue -and !($Data.Fields.StorageName.Hidden)) {
                        If ($Data.Storages.name -notcontains $FieldValue) {
                            Return "Storage name '$FieldValue' not found for this repository! (Might have to add first)"
                        }
                    }
                }
            }
        }
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        # $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"
        $Data.ShowAdv = $Settings.ShowAdv

        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        #$Data.Storages = @(Read-Pref erences $Repo)
        $Data.Fields.StorageName.Value = $Data.Parameters.Storage.name
        $Data.Fields.id.Value = $Data.Parameters.Storage.id
    }

    ValidateScript = {
        # Validate all fields automatically?
        # Run through and return 
        # If ($Data.Fields.Name.Enable) {
    }

    # Actions
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)
        $Repo = $Data.Parameters.Repository

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
    }
} # Dialog_Check



<# $Dialog_Prune
SYNOPSIS:
   duplicacy prune - Prune revisions by number, tag, or retention policy

USAGE:
   duplicacy prune [command options]

OPTIONS:
   -id <snapshot id>            delete revisions with the specified snapshot ID instead of the default one
   -all, -a                     match against all snapshot IDs
   -r <revision> [+]            delete the specified revisions
   -t <tag> [+]                 delete revisions with the specified tags
   -keep <n:m> [+]              keep 1 revision every n days for revisions older than m days
   -exhaustive                  remove all unreferenced chunks (not just those referenced by deleted snapshots)
   -exclusive                   assume exclusive access to the storage (disable two-step fossil collection)
   -dry-run, -d                 show what would have been deleted
   -delete-only                 delete fossils previously collected (if deletable) and don't collect fossils
   -collect-only                identify and collect fossils, but don't delete fossils previously collected
   -ignore <id> [+]             ignore revisions with the specified snapshot ID when deciding if fossils can be deleted
   -storage <storage name>      prune revisions from the specified storage
   -threads <n>			        number of threads used to prune unreferenced chunks
#>
$Dialog_Prune = @{
    # Remove snapshots
    Title = "Prune snapshots"

#    Help = @"
#Go to the Duplicacy Forum to find more information
#"@

    Actions = [Ordered]@{
        AddAction = $Action_AddAction
        Advanced = $Dialog_Init.Actions.Advanced
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum
    }
    
    Fields = $Global_Fields + [Ordered]@{
        Command = @{
            Hidden = $True
            Parameterbuild = "Value"
            Value = "prune"
        }

        Cap_Include = @{
            Order = 0
            Text = "Include:"
            Type = "Caption"
        }

        id = @{
            Text = '&ID'
            # ParameterOrder = 10
            #Parameterbuild = "Value"
            Help = "Specify ID to delete instead of the default one. Accepts '-', '_' and alphanumerics"
            EnableScript = { $Settings.InitAdvanced }
            Config = @{
                ValidateScript = {
                    $Temp = $FieldValue
                    $FieldValue = $FieldValue -replace " ", "_" -replace "[^a-z0-9-_]", ""
                    If ($Temp -ne $FieldValue) {
                        Blink "Removed unaccepted characters!"
                    }
                }
            }
        }



        all = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Include &all snapshots'
            Help = @"
Include any snapshots in the storage. 
By default, only snapshots from current repository are included.
"@
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (match against all IDs in storage)"
                    $False = "Off "
                }
            }
        }

        revision = @{
            Parameter = "r"
            ParameterBuild = 'Multi'
            Text = 'Revision(s)'
            Help = 'Revisions to include: Ranges and single revisions, e.g. 1,3-5'
            Config = @{
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *- *", "-" -replace " *, *", ","  -replace " +", "," -replace "[,-] *$", ""
                    If ($FieldValue -and $FieldValue -notmatch "^[0-9]+$|^[0-9]+[0-9-,]*[0-9]$")  { # Currently, 4- and -4 not allowed.
                        Return "Specify a comma separated list, e.g. 1,3,4-6"
                    }
                }
                Hint = "Comma separated (1,3-5)"
            }        
        }

        tag = @{
            Parameter = "t"
            ParameterBuild = "Multi"
            Text = 'Tag(s)'
            Help = 'Include revisions with this tag.'  
            Config = @{
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *, *", "," -replace " +", "," -replace "[,-] *$", ""
                    If ($FieldValue -and $FieldValue -notmatch "^[a-zA-Z0-9,]+$")  {
                        Return "Specify a comma separated list, e.g. a,b"
                    }
                }
                Hint = "Comma separated"
            }        
        }

        Cap_opt = @{
            Order = 0
            Text = "Options:"
            Type = "Caption"
        }


        keep = @{
            Parameterbuild = "Multi"
            Text = 'Keep (Retention policy)'
            Help = "<n:m>, keep 1 revision every n days for revisions older than m days. Longest m first"
            Config = @{
                ValidateScript = {
                    $FieldValue = $FieldValue -replace " *, *", "," -replace " *: *",":" -replace " +" -replace "[,-] *$"
                    If ($FieldValue -and $FieldValue -notmatch "^[0-9,]+:[0-9]+(,[0-9]+:[0-9,])*$")  {
                        Return "Specify a comma separated list of pairs, e.g. n:m,n:m"
                    }
                }
                Hint = "Comma separated pairs of n:m"
            }
        }

        exhaustive = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Exhaustive prune'
            Help = "Search storage and remove all unreferenced chunks (not just those referenced by deleted snapshots)"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (exhaustive prune)"
                    $False = "Off "
                }
            }
        }

        exclusive = @{
            EnableScript = { $Data.ShowAdv }
            Parameterbuild = "Param"
            Text = 'Exclusive access'
            Help = "Use this option only if you are sure no other operation is ongoing. This disables two-step fossil collection."
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Assume exclusive access)"
                       $False = "Off "
                }
            }
        }

        dryrun = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "dry-run"
            Parameterbuild = "Param"
            Text = 'Dry-run'
            Help = "Show what would be deleted"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (dry-run)"
                    $False = "Off "
                }
            }
        }

        deleteonly = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "delete-only"
            Parameterbuild = "Param"
            Text = 'Delete only'
            Help = "Delete fossils (if deletable) collected in a previous pass. Don't collect fossils in this pass."
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (delete-only)"
                    $False = "Off "
                }
            }
        }

        collectonly = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "collect-only"
            Parameterbuild = "Param"
            Text = 'Collect only'
            Help = "Identify and collect fossils. (Don't delete fossils from a previous pass)"
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (collect-only)"
                    $False = "Off "
                }
            }
        }

        ignore = @{
            EnableScript = { $Data.ShowAdv }
            Text = 'Ignore ID'
            Parameterbuild = "Multi"
            # ParameterOrder = 10
            # Parameterbuild = "Value"
            Help = "Specify comma separated IDs to ignore when collecting fossils. Accepts '-', '_' and alphanumerics"
            #EnableScript = { $Settings.InitAdvanced }
            Config = @{
                ValidateScript = {
                    $Temp = $FieldValue
                    $FieldValue = $FieldValue -replace " *, *", "," -replace "^ *" -replace " *$" -replace " ", "_" -replace "[^a-z0-9-_,]", ""
                    If ($Temp -ne $FieldValue) {
                        Blink "Unexpected characters!"
                    }
                }
                Hint = "Comma separated"
            }
        }

        #   -storage <storage name>      prune revisions from the specified storage
        StorageName = @{
            Hidden = $true
            Parameter = "storage"
            Text = 'Storage &Name'
            Help = 'Specify which storage to prune'
            Config = @{
                ValidateScript = {
                    If ($FieldValue -and !($Data.Fields.StorageName.Hidden)) {
                        If ($Data.Storages.name -notcontains $FieldValue) {
                            Return "Storage name '$FieldValue' not found for this repository! (Might have to add first)"
                        }
                    }
                }
            }
        }

        #   -threads <n>			        number of threads used to prune unreferenced chunks
        threads = @{
            EnableScript = { $Data.ShowAdv }
            #EnableScript = {$Settings.InitAdvanced}
            Parameter = "threads"
            Text = 'Number of &threads'
            Help = 'Number of threads to use in the process' 
            Type = "int32"
            Config = @{
                Min = 1
                # ValidateScript = { If ($FieldValue -and $FieldValue -lt 1) { Return "Value must be minimum 1"}}
            }
        }

    }

       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.ShowAdv = $Settings.ShowAdv
        # $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"

        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        #$Data.Storages = @(Read-Pref erences $Repo)
        $Data.Fields.StorageName.Value = $Data.Parameters.Storage.name
        $Data.Fields.id.Value = $Data.Parameters.Storage.id
    }

    # ValidateScript = {    }  # Automtic

    # Actions
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)
        $Repo = $Data.Parameters.Repository

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }

        UpdateListLog -Main $Settings.SettingsPath -StorageName $Data.Fields.StorageName.Value -Repository $Repo -DuplicacyPath $Settings.DuplicacyPath


    }
} #$Dialog_Prune




<#
NAME:
   duplicacy benchmark - Run a set of benchmarks to test download and upload speeds

USAGE:
   duplicacy benchmark [command options]

OPTIONS:
   -file-size <size>            the size of the local file to write to and read from (in MB, default to 256)
   -chunk-count <count>         the number of chunks to upload and download (default to 64)
   -chunk-size <size>           the size of chunks to upload and download (in MB, default to 4)
   -upload-threads <n>          the number of upload threads (default to 1)
   -download-threads <n>        the number of download threads (default to 1)
   -storage <storage name>      run the download/upload test agaist the specified storage
#>
$Dialog_Benchmark = @{
    
    Title = "Benchmark the storage"

    Actions = [Ordered]@{
        Advanced = $Dialog_Init.Actions.Advanced
        Forum = $Dialog_Config.Actions.Forum
    }
    
    Fields = $Global_Fields + [Ordered]@{
        Command = @{
            Hidden = $True
            Parameterbuild = "Value"
            Value = "benchmark"
        }

        Cap_opt = @{
            Order = 0
            Text = "Options:"
            Type = "Caption"
        }


        filesize = @{
            Parameter = "file-size"
            Text = 'File size'
            Help = "Size of file to write and read, in MB. Default is 256 MB"
            Type = "int32"
        }

        
        chunkcount = @{
            Parameter = "chunk-count"
            Text = 'Number of chunks'
            Help = "Number of chunks to upload and download. Default is 64"
            Type = "int32"
        }


        #   -storage <storage name>      prune revisions from the specified storage
        StorageName = @{
            Hidden = $true
            Parameter = "storage"
            Text = 'Storage &Name'
            Help = 'Specify which storage to prune'
            Config = @{
                ValidateScript = {
                    If ($FieldValue -and !($Data.Fields.StorageName.Hidden)) {
                        If ($Data.Storages.name -notcontains $FieldValue) {
                            Return "Storage name '$FieldValue' not found for this repository! (Might have to add first)"
                        }
                    }
                }
            }
        }

        uploadthreads = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "upload-threads"
            Text = 'Upload-threads'
            Help = 'Number of threads to use for upload. Default is 1' 
            Type = "int32"
            Config = @{
                #Min = 1
                ValidateScript = { If ($FieldValue -and $FieldValue -lt 1) { Return "Value must be minimum 1"}}
            }
        }

        downloadthreads = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "download-threads"
            Text = 'Download-threads'
            Help = 'Number of threads to use for download. Default is 1' 
            Type = "int32"
            Config = @{
                #Min = 1
                ValidateScript = { If ($FieldValue -and $FieldValue -lt 1) { Return "Value must be minimum 1"}}
            }
        }

    }

       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.ShowAdv = $Settings.ShowAdv
        # $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"

        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        $Data.Fields.StorageName.Value = $Data.Parameters.Storage.name
    }

    # Actions
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)
        $Repo = $Data.Parameters.Repository

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
    }
}










Function LogfilePath {
    Param (
        [String]$Main,
        [String]$Repository,
        [String]$Storage,
        [String]$Name
    )
    # $ListLog = LogfilePath -Main $Settings.SettingsPath -Repository (Split-Path -Leaf $Repo) -Storage ($Data.Fields.StorageName.Value) -Name "List.txt"
    
    # "$Main\.DucyBackup\Logs\$Repository\$Storage\$Name"
    "$Main\.DucyBackup\Logs\$Repository\List\$Storage.txt"
}

<#
    For current repository/storage, run the 'list' command and store in a text file
#>

Function UpdateListLog {
    Param (
        [String]$Main,         # $Settings.SettingsPath
        [String]$StorageName,  # $Data.Fields.StorageName.Value
        [String]$Repository,
        [String]$DuplicacyPath, # $Settings.DuplicacyPath
        [String]$ListLog        # Optional
    )

    If (!$ListLog) {
        $ListLog = LogfilePath -Main $Main -Repository (Split-Path -Leaf $Repository) -Storage $StorageName -Name "List.txt"
    }
    
    # update list of revisions
    Write-Host "Invoking the 'list' command to retrieve revision list for this storage"
    StartCommand -log '-' -FilePath $DuplicacyPath -WorkingDirectory $Repository -ArgumentList @("list", "-storage", $StorageName) | Out-File (New-Item -Path $ListLog -Force) # -Log $ListLog
}


<#
    List revisions (Update if necessary) for the current repository/storage
#>
Function GetListRevisions {
    Param (
        [String]$Main,          # $Settings.SettingsPath
        [String]$StorageName,   # $Data.Fields.StorageName.Value
        [String]$Repository,
        [String]$DuplicacyPath, # $Settings.DuplicacyPath
        [Switch]$Update         # Update even when list exist
    )

    $ListSort = @{
        Expression = {$_.Rev}
        Descending=$true
    }

    $ListLog = LogfilePath -Main $Main -Repository (Split-Path -Leaf $Repository) -Storage $StorageName -Name "List.txt"
    If ($Update -or !(Test-Path $ListLog)) {
        UpdateListLog -Repository $Repository -StorageName $StorageName -DuplicacyPath $DuplicacyPath -ListLog $ListLog
    }
    
    If (!(Test-Path $ListLog)) {
        Write-host "Missing log..."
        Return
    }
        # Snapshot c-intel-logs revision 1 created at 2020-02-12 00:17 -hash
        # Snapshot c-intel-logs revision 10 created at 2020-05-08 23:25 tag as words
    # $Regex = 'Snapshot [^ ]+ revision (?<Rev>[0-9]+) created at (?<Date>[0-9-]+ [0-9:]+)  *(?<Tag>(\w\s*)*)'
    $Regex = 'Snapshot [^ ]+ revision (?<Rev>[0-9]+) created at (?<Date>[0-9-]+ [0-9:]+) *(?<Tag>[^\r\n]*)'
    $Result = @()

    $ListlogContent = Get-Content -Path $ListLog -Raw

    [Regex]::Matches($ListlogContent, $Regex) | ForEach-Object {
        $Result += [pscustomobject]@{
            Rev = [int32]$_.Groups['Rev'].value
            Date = $_.Groups['Date'].value
            Tag = $_.Groups['Tag'].value
        }
    }

    #If (!$Update) {$Result = $Result[0..5] | sort $ListSort}

    $Result | sort $ListSort
}




<#
 -all, -a                    list snapshots with any id
   -id <snapshot id>           list snapshots with the specified id rather than the default one
   -r <revision> [+]           the revision number of the snapshot
   -t <tag>                    list snapshots with the specified tag
   -files                      print the file list in each snapshot
   -chunks                     print chunks in each snapshot or all chunks if no snapshot specified
   -reset-passwords            take passwords from input rather than keychain/keyring or env
   -storage <storage name>     retrieve snapshots from the specified storage
#>
$Dialog_List = @{
    Title = "List snapshots"
    # Wizzard = $True

#    Help = @"
#Go to the Duplicacy Forum to find more information
#"@

    Actions = @{
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum
    }

    Fields = [ordered]@{  # Add
        Command = @{
            Hidden = $True
            Parameterbuild = "Value"
            Value = "list"
        }

        Cap_Include = @{
            Order = 0
            Text = "Include:"
            Type = "Caption"
        }
        all = @{
            Parameterbuild = "Param"
            Text = 'List &all snapshots'
            Help = @"
Select this to list any snapshots in the storage. 
By default, list will only work on snapshots from the current repository.
"@
            Type = 'Boolean'
            Value = $false
            Config = @{
                States = @{
                    $True  = "On"
                    $False = "Off "
                }

            }
        }

        # If not advanced, InitScript can set repository and ID. Same ID as initial storage for this repository.
        # Perhaps use the same ID ($dialog_init.fields.ini)
        id = $Dialog_Check.Fields.id
        revision = $Dialog_Check.Fields.revision
        tag = $Dialog_Check.Fields.tag
        Cap_opt = $Dialog_Check.Fields.Cap_opt

        files = @{
            Parameterbuild = "Param"
            Text = 'List &files'
            Help = "List the files in each snapshot"
            Type = 'Boolean'
            Value = $false
        }

        #-chunks                     print chunks in each snapshot or all chunks if no snapshot specified
        chunks = @{
            Parameterbuild = "Param"
            Text = 'Print chunks'
            Help = "print chunks in each snapshot or all chunks if no snapshot specified"
            Type = 'Boolean'
        }

        # -reset-passwords            take passwords from input rather than keychain/keyring or env
        ResetPasswords = @{
            Parameterbuild = "Param"
            Parameter = "reset-passwords"
            Text = 'Reset passwords'
            Help = "Input password from input instead of the stored password"
            Type = 'Boolean'
        }

        # Storage-name
        StorageName = @{
            Hidden = $true
            Parameter = "storage"
            Text = 'Storage &Name'
            Help = 'Specify which storage to list' 
        }
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        # $Data.RepoIsInitialized = Test-Path "$Repo\.duplicacy"
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"

        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        #$Data.Storages = @(Read-Pref erences $Repo)
        $Data.Fields.StorageName.Value = $Data.Parameters.Storage.name
        $Data.Fields.id.Value = $Data.Parameters.Storage.id
    }

    # Actions
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)
        $Repo = $Data.Parameters.Repository
        # $ListLog = "$($Settings.SettingsPath)\.DucyBackup\Logs\$(Split-Path -Leaf $Repo)\$($Data.Fields.StorageName.Value)\List.txt"
        $ListLog = LogfilePath -Main $Settings.SettingsPath -Repository (Split-Path -Leaf $Repo) -Storage ($Data.Fields.StorageName.Value) -Name "List.txt"

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"
        Write-Host "Log       : $ListLog"

        # C:\Users\Arnt Marius\Documents\TestBackup\3\.duplicacy\cache\CTestTarget\snapshots\c-intel-logs

        # Settingspath\.ducybackup\Logs\reponame\id\storagename
        $Name = $Data.Fields.Name.Value

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters -ListLog $ListLog

        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
    }
} # Dialog_List



$Dialog_Copy = @{
    # Copy between storages
    Title = "Copy to"

<#
   -id <snapshot id>            copy snapshots with the specified id instead of all snapshot ids
   -r <revision> [+]            copy snapshots with the specified revisions

   -from <storage name>         copy snapshots from the specified storage
   -to <storage name>           copy snapshots to the specified storage

   -download-limit-rate <kB/s>  the maximum download rate (in kilobytes/sec)
   -upload-limit-rate <kB/s>    the maximum upload rate (in kilobytes/sec)
   -threads <n>                 number of uploading threads
#>

    # Wizzard = $True

#    Help = @"
#Go to the Duplicacy Forum to find more information
#"@

    Actions = @{ # Copy
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum
        Advanced = $Dialog_Init.Actions.Advanced
        AddAction = $Action_AddAction
    }

    Fields = $Global_Fields + [Ordered]@{
    <#Fields = [ordered]@{  # Copy
        # Global options first
        Verbose = $Global_Verbose
        Debug = $Global_Debug
        Log = $Global_Log
        Stack = $Global_Stack
        NoScript = $Global_NoScript
        Background = $Global_Background
        Profile = $Global_Profile
        Comment = $Global_Comment
        #>

        Command = @{
            #ParameterOrder = -2
            Hidden = $True
            Parameterbuild = "Value"
            Value = "copy"
        }

        Cap_Include = @{
            Order = 0
            Text = "Include:"
            Type = "Caption"
        }

        # InitScript can set repository and ID. Same ID as initial storage for this repository.
        # If Settings/advanced, user can override
        # Perhaps use the same ID ($dialog_init.fields.ini)

        id = $Dialog_Check.Fields.id
        revision = $Dialog_Check.Fields.revision

        Cap_opt = @{
            Order = 0
            Text = "Options:"
            Type = "Caption"
        }

        #   -download-limit-rate <kB/s>  the maximum download rate (in kilobytes/sec)
        DownloadLimitRate = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "download-limit-rate"
            Text = 'Maximum download rate'
            Help = 'Rate in kB/s to limit downloading from source' 
            Type = "int32"
            Config = @{
                Min = 0
                Step = 1024
                ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        #   -upload-limit-rate <kB/s>    the maximum upload rate (in kilobytes/sec)
        UploadLimitRate = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "upload-limit-rate"
            Text = 'Maximum upload rate'
            Help = 'Rate in kB/s to limit uploading to target' 
            Type = "int32"
            Config = @{
                Min = 0
                Step = 1024
                ValidateScript = { 
                    If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}
                }
            }
        }

        #   -threads <n>                 number of uploading threads
        Threads = @{
            EnableScript = { $Data.ShowAdv }
            Parameter = "threads"
            Text = 'Uploading &threads'
            Help = 'Number of upload threads' 
            Type = "int32"
            Config = @{
                ValidateScript = { 
                    If ($FieldValue -and $FieldValue -lt 1) { Return "Value must be minimum 1"}
                }
            }
        }

        # Storage-name
        From = @{
            Hidden = $true
            Parameter = "from"
            Text = "From"
            Help = 'Specify which storage to copy from' 
        }

        To = @{
            Hidden = $true
            Parameter = "to"
            Text = "To"
            Help = 'Storage to copy to'
            Config = @{
                ValidateScript = {
                    # $FieldValue 
                    $Data.Fields.To.Value = $data.List[$ListSelectedItem].name
                }
            }
        }
    }
    
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.ShowAdv = $Settings.ShowAdv
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"
        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
            exit
        }

        $Data.Fields.From.Value = $Data.Parameters.Storage.name
        $Data.Fields.id.Value   = $Data.Parameters.Storage.id
    }

<#
    DialogListScript = {
        # populate the list for this dialog
        # Read storages

        # $Data.List = @(Read-Pref erences $Data.Parameters.Repository -Exclude $Data.Parameters.Storage.name)

        $Data.List = @(Get_Storage $Data.Parameters.Repository -Exclude $Data.Parameters.Storage.name)
       
        
        # This means the list has a header line, move focus n lines down:
        #$ListheaderLines = 1

        # $Item.name, $Item.id, $Item.repository, $Item.storage, $Item.encrypted, $Item.PasswordStored

        # Display list
        # Show-Repository $Data.Parameters.Repository -exclude $Data.Parameters.Storage.name  | Out-Host

        #Set-PSDebug -Step
    }
#>



    # Actions
    ExecuteScript = {
        # Validatescript fixes this:
        # $Data.Fields.To.Value = $data.List[$ListSelectedItem].name

        $DucyParameters = GetDialogParameters $Data
        $Repo = $Data.Parameters.Repository
        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters

        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
    }


    ListUpdateScript = {
        # Load data.list from $SettingsPath
        $Data.List = @(Get_Storage $Data.Parameters.Repository -Exclude $Data.Parameters.Storage.name)

        #$Data.List = @(Get-RepositoryList $Data.Parameters.SettingsPath) # $SettingsPath  -Showlines
        #$ListheaderLines = 1
    }
    
    ListFormat = $Dialog_Manage.ListFormat

    # Format of the list
    <#
    ListFormat = @(
        @{
            Name = "Name"
            Expression = {$_.Name}
            Width = 20
        },
        @{
            Name = "Id"
            Expression = {$_.LastID}
            Width = 20
            #Formatstring = ""
        },
        @{
            Name = "Repository"
            Expression = {$_.RepoPath}
            Width = 30
        },
        @{
            Name = "Stor"
            Expression = {$_.Storages}
            Width = 4
        }
    )#>


} # Dialog_Copy









# $Dialog_Backup
<#
 -hash                        detect file differences by hash (rather than size and timestamp)
   -t <tag>                     assign a tag to the backup
   -stats                       show statistics during and after backup
   -threads <n>                 number of uploading threads
   -limit-rate <kB/s>           the maximum upload rate (in kilobytes/sec)
   -dry-run                     dry run for testing, don't backup anything. Use with -stats and -d
   -vss                         enable the Volume Shadow Copy service (Windows and macOS using APFS only)
   -vss-timeout <timeout>       the timeout in seconds to wait for the Volume Shadow Copy operation to complete
   -storage <storage name>      backup to the specified storage instead of the default one
   -enum-only                   enumerate the repository recursively and then exit
#>

$Dialog_Backup = @{
    Title = "Backup"

#    Help = @"
#Hit F to find more info on 'add' in the Duplicacy Forum User Guide
#Also look up info on storage backends! https://forum.duplicacy.com/t/supported-storage-backends
#"@

    #Clear = "DialogStart"

    Actions = @{
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum

        Advanced = $Dialog_Init.Actions.Advanced
        <#
        Advanced = @{
            NoValidate = 1
            #Enable = $false 
            Text = "Advanced options"
            Help = "Toggle showing more options"
            Action = { 
                $Data.ShowAdv = !$Data.ShowAdv
                
                #$EnableAdv = !$Data.Fields.hash.Enable
                ## $Data.Fields.Storage.Enable = $EnableAdv
                ## Set-PSDebug -Step
                #$Data.Fields.hash.Enable = $EnableAdv
                #$Data.Fields.vss.Enable = $EnableAdv
                #$Data.Fields.vsstimeout.Enable = $EnableAdv
                #$Data.Fields.EnumOnly.Enable = $EnableAdv
                
            }
        }
        #>

        # Backup
        AddAction = $Action_AddAction
    }

    Fields = $Global_Fields + [ordered]@{
        Command = @{
            #ParameterOrder = -2
            Hidden = $True
            Parameterbuild = "Value"
            Value = "backup"
        }

        Storage = @{
            #ParameterOrder = 1
            Parameter = "storage"
            # EnableScript = {$Settings.ShowAdv}
            Enable = $false
            Text = 'Storage &Name'
            Help = 'Backup to this storage. If empty, the default storage for this repository is used' 
        }

        Tags = @{
            Parameter = "t"
            Text = 'Tag'
            Help = "Assign a tag for this revision"
        }

        stats = @{
            Text = 'Show &statistics'
            Help = "Show statistics for the backup"
            Type = 'Boolean'
            Value = $True
        }

        hash = @{
            EnableScript = {$Data.ShowAdv}
            Text = 'Detect change by hash'
            Help = "Detect file differences by hash rather than by size and timestamp (slower)"
            Type = 'Boolean'
        }

        # Uploading threads
        Threads = $Dialog_Copy.Fields.Threads

        LimitRate = @{
            EnableScript = {$Data.ShowAdv}
            Parameter = "limit-rate"
            Text = 'Limit upload rate'
            Help = 'Maximum upload limit rate in kb/s'
            Type = "int32"
            Config = @{
                Min = 0
                Step = 1024
                #ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        DryRun = @{
            parameter = "dry-run"
            Text = 'Dry Run (no backup)'
            Type = 'Boolean'
            Help = "Dry run is for testing, don't backup anything. Use with -stats (global option -d)"
            Value = $false
            EnableScript = {$Data.ShowAdv}
        }

        vss = @{
            Text = '&Volume Shadow Copy'
            EnableScript = {$Data.ShowAdv}
            Type = 'Boolean'
            Help = "Use Volume Shadow Copy to copy locked databases etc. (Requires administrator privileges for the account running the task)"
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Requires admin priv)"
                    $False = "Off "
                }
            }
        }

        vsstimeOut = @{
            parameter = "vss-timeout"
            EnableScript = {$Data.ShowAdv}
            Text = 'VSS &Timeout'
            Type = 'int'
            Help = "Volume Shadow Copy timeout in seconds."
        }

        EnumOnly = @{
            EnableScript = {$Data.ShowAdv}
            Text = 'Enumerate only'
            Parameter = 'enum-only'
            Type = 'Boolean'
            Help = "Enumerate the repository. No backup will be performed"
            Value = $false
            Config = @{
                States = @{
                    $True  = "On  (Only enumerate the repository)"
                    $False = "Off "
                }
            }
        }
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.ShowAdv = $Settings.ShowAdv
        $Data.Fields.Storage.Value = $Data.Parameters.Storage.name
    }

    #ValidateScript = {
        # Validate all fields automatically?
        # Run through and return 
        # If ($Data.Fields.Name.Enable) {
    #}

    # Actions
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"
        Write-Host "Backing up to a storage"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        $R = $LASTEXITCODE
        If ($R -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $R"} }
        
        UpdateListLog -Main $Settings.SettingsPath -StorageName $Data.Fields.Storage.Value -Repository $Repo -DuplicacyPath $Settings.DuplicacyPath

        #IF ($Data.Fields.Encrypt.Value) {
        #    Write-Host "Invoking the 'list' command to store updated list of revisions"
        #    $ListARg = "list", "-storage", $Data.Fields.StorageName.Value
        #    StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $ListARg
        #    $R = $LASTEXITCODE
        #    If ($R -gt 0) { Return @{Cancel = $true; Reason = "List command failed with error: $R (was trying to save password. You can do this manually later)"} }
        #}

    }
} # $Dialog_Backup




# $Dialog_Restore
<#
   duplicacy restore [command options] [--] [pattern] ...

OPTIONS:
    -r <revision>                 the revision number of the snapshot (required)
    -hash                         detect file differences by hash (rather than size and timestamp)
    -overwrite                    overwrite existing files in the repository
    -delete                       delete files not in the snapshot
    -ignore-owner                 do not set the original uid/gid on restored files
    -stats                        show statistics during and after restore
    -threads <n>                  number of downloading threads
    -limit-rate <kB/s>            the maximum download rate (in kilobytes/sec)
    -storage <storage name>       restore from the specified storage instead of the default one

   -key <private key>            the RSA private key to decrypt file chunks
   -key-passphrase <passphrase>  the passphrase to decrypt the RSA private key

#>

$Dialog_Restore = @{
    Title = "Restore"
    NoEnter = $True


#    Help = @"
#Hit F to find more info on 'Restore' in the Duplicacy Forum User Guide
#Also look up info on storage backends! https://forum.duplicacy.com/t/supported-storage-backends
#"@

    # Backup
    Actions = @{
        Forum = $Dialog_Config.Actions.Forum  # A command to open web to Forum

        Advanced = $Dialog_init.Actions.Advanced
        <#
        Advanced = @{
            Text = "Advanced options"
            NoValidate = 1
            Help = "Toggle showing more options"
            Action = { 
                $EnableAdv = !$Data.Fields.Storage.Enable
                $Data.Fields.Storage.Enable = $EnableAdv
                $Data.Fields.hash.Enable = $EnableAdv
                $Data.Fields.Overwrite.Enable = $EnableAdv
                $Data.Fields.delete.Enable = $EnableAdv
                $Data.Fields.IgnoreOwner.Enable = $EnableAdv
                $Data.Fields.Stats.Enable = $EnableAdv
                $Data.Fields.Threads.Enable = $EnableAdv
                $Data.Fields.LimitRate.Enable = $EnableAdv
            }
        }
        #>

        UpdateList = @{
            Text = "Update restore points"
            NoValidate = 1
            Help = "Update the list of available restore points from the storage. Recommended but might take some time"
            Action = {
                Write-Host "Updating list of restore points..."
                $Data.List = GetListRevisions -Update -Main $Settings.SettingsPath -StorageName $Data.Fields.Storage.Value -Repository $Repo -DuplicacyPath $Settings.DuplicacyPath 
                $RefreshList = $true
            }
        }

        Restore = @{
            Text = "Execute Restore"
            Help = "Restore based on your selections"
            Action = {

                ValidateFields

                #$Data.Fields.Rev.Value = $data.list[$listselecteditem].Rev
                $Data.Fields.Rev.Value = $data.list[$Data.SelectedItem].Rev

                Write-host "Selected rev: $($Data.Fields.Rev.Value)"
                Write-host "        Date: $($data.list[$Data.SelectedItem].Date)"
                
                $DucyParameters = @(GetDialogParameters $Data)
                If (!$Data.Fields.Pattern.Value) { Write-host "No pattern specified!"}

                Write-host "Restore complete repository to specified revision?"
                If (($Conf = read-host "Confirm...") -notlike "Yes") {
                    Write-host "Cancelled..."
                    sleep 2
                    Return
                }

                <# 

                If ($true) {
                    $Data.Fields.Rev.Value = $data.list[$Data.SelectedItem].Rev
                    $Repo2 = "C:\Users\Arnt Marius\Documents\TestBackup\.DucyBackup\RestoreRepo\4"

                    Set-PSDebug -Step

                    StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo2 -ArgumentList $DucyParameters
                    #read-host "done???"

                    Set-PSDebug -Step

                    return
                }#>




                
                # Write-Host "Parameters: $DucyParameters"
                # Write-Host "Path      : $Repo"

                StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
                $R = $LASTEXITCODE
                If ($R -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $R"} }
            }
        }
    }

    Fields = $Global_Fields + [ordered]@{
        Command = @{
            #ParameterOrder = -2
            Hidden = $True
            Parameterbuild = "Value"
            Value = "restore"
        }

        Storage = @{
            #ParameterOrder = 1
            Parameter = "storage"
            #EnableScript = {$Settings.InitAdvanced}
            Enable = $false
            Text = 'Storage &Name'
            Help = 'Restore from this storage' 
        }

        Rev = @{
            Parameter = 'r'
            Hidden = $True
            Text = 'Revision'
            Help = "The revision number of the snapshot (required)"
            Type = "int32"
            Config = @{
                # Min = 1
                #ValidateScript = {
                    # $FieldValue = $data.list[$listselecteditem].Rev
                    #$Data.Fields.Rev.Value =  $data.list[$Data.SelectedItem].Rev

                    #Write-host "Selected rev:______________: $FieldValue"
                    #sleep 1
                #}
            }
        }

        Overwrite = @{
            EnableScript = {$Data.ShowAdv}
            parameter = "overwrite"
            Text = 'Overwrite'
            Type = 'Boolean'
            Help = "Overwrite existing files in the repository"
            Value = $false
        }

        delete = @{
            EnableScript = {$Data.ShowAdv}
            parameter = "delete"
            Text = 'Delete extra files'
            Type = 'Boolean'
            Help = "Delete extra files in the repository which are not in the snapshot"
            Value = $false
        }

        IgnoreOwner = @{
            EnableScript = {$Data.ShowAdv}
            parameter = "ignore-owner"
            Text = 'Ignore owner'
            Type = 'Boolean'
            Help = "Do not set the original uid/gid on restored files"
            Value = $false
        }

        hash = @{
            EnableScript = {$Data.ShowAdv}
            Text = 'Detect change by hash'
            Help = "Detect file differences by hash rather than by size and timestamp (slower)"
            Type = 'Boolean'
        }

        stats = @{
            EnableScript = {$Data.ShowAdv}
            Text = 'Show &statistics'
            Help = "Show statistics for the restore"
            Type = 'Boolean'
            Value = $True
        }

        Threads = $Dialog_Copy.Fields.Threads

        LimitRate = @{
            EnableScript = {$Data.ShowAdv}
            Parameter = "limit-rate"
            Text = 'Limit download rate'
            Help = 'Maximum download limit rate in kb/s'
            Type = "int32"
            Config = @{
                Min = 0
                Step = 1024
                #ValidateScript = { If ($FieldValue -and $FieldValue -lt 0) { Return "Value must be positive"}}
            }
        }

        ProtectPatternSeparator = @{
            Parameter = "NextIsPattern"
            Hidden = $True
            Parameterbuild = "Value"
            Value = ""
            Config = @{
                ValidateScript = {
                    If ($Data.Fields.Pattern.Value) {
                        $Data.Fields.ProtectPatternSeparator.Value = '--'
                    } else {
                        $Data.Fields.ProtectPatternSeparator.Value = ''
                    }
                }
            }
        }

        Pattern = @{
            #Parameter = "storage"
            Parameterbuild = "Value"
            Text = 'Pattern'
            Help = 'A regexp pattern for selecting folders/files to restore. Use forward slash (/) to delimit folders' 
            Config = @{
                ValidateScript = {
                    If ($Fieldvalue) {
                        $Fieldvalue = $Fieldvalue -replace '\\','/'
                    } 
                }
            }
        }
    }
       
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    # Get storages definition
    InitScript = {
        $Data.Fields.Storage.Value = $Data.Parameters.Storage.name
        $Data.List = GetListRevisions -Main $Settings.SettingsPath -StorageName $Data.Fields.Storage.Value -Repository $Repo -DuplicacyPath $Settings.DuplicacyPath 
        $Data.ShowAdv = $Settings.ShowAdv

        # $Data.Fields.Rev.Value = $Data.List[-1].Rev

        If (!($Data.List.Count -gt 0)) {
            write-host "  No restore points are available. No backups done? (List to udpdate from storage)"
            #sleep 3
            #Set-PSDebug -Step
            return 'Cancel'
        }

    }

    #DialogListScript = {
    #    $ListheaderLines = 1
    #    Show_List
    #}

    # Format of the list
    ListFormat = @(
        @{
            Name = "Rev"
            Expression = {$_.Rev}
            Width = 5
        },
        @{
            Name = "Date"
            Expression = {$_.Date}
            Width = 20
            #Formatstring = ""
        },
        @{
            Name = "Tag"
            Expression = {$_.Tag}
            Width = 60
        }
     )

    #ValidateScript = {
        # Validate all fields automatically?
        # Run through and return 
        # If ($Data.Fields.Name.Enable) {
    #

    # Actions
    <#
    ExecuteScript = {
        $DucyParameters = @(GetDialogParameters $Data)

        Write-Host "Parameters: $DucyParameters"
        Write-Host "Path      : $Repo"

        StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters
        $R = $LASTEXITCODE
        If ($R -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $R"} }
    }#>
} # $Dialog_Restore






# Add job to job list 
$Dialog_AddAction = @{
    Title = "Add action"

    Fields = [ordered]@{  # AddAction
        Name = @{
            Text = 'Action name'
            Help = "Name for this action"
            Value = "Set a name"
        }
    }
    
    # Format of the list
    ListFormat = @(
        @{
            Name = "Job"
            Expression = {$_.Name}
            Width = 20
        }
        @{
            Name = "Storage"
            Expression={$_.Actions[0].Fields.Storage}
            Width = 15
        }
        @{
            Name = "Acts" # ions
            Expression = { ($_.Actions).Count }
            Width = 3
        }
    )

    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Repo = $Data.Parameters.Repository
        $Data.RepoIsInitialized = Test-Path "$Repo\.Duplicacy\preferences"
        If (!$Data.RepoIsInitialized) {
            Write-Host "This repository is not initialized. From main meny: Manage/Init" -ForegroundColor Red
            return
        }

        #Arguments = $DucyParameters
        #Fields = $Data.Fields
        #Repository = $Repo

        $NameParts  = @(
            $Parameters.Fields.Command.Value
            $Parameters.Fields.Id.Value
            $Parameters.Fields.Storagename.Value
            $Parameters.Fields.Storage.Value
        )
        
        If ($Parameters.Fields.From.Value) {
            $NameParts += "From"
            $NameParts += $Parameters.Fields.From.Value
        }
        
        IF ($Parameters.Fields.To.Value) {
            $NameParts += "To"
            $NameParts += $Parameters.Fields.To.Value
        }
        $Data.Fields.Name.Value = $NameParts -join " " -replace "  *", " "
    }
    
    ListUpdateScript = {
        # Get all jobs for this repo
        
        $Data.List = @( Get-DCJob -Path $Repo | select name,actions,arguments,fields)
        $Data.List += [pscustomobject]@{
            Name = "<A new job>"
            Actions = @()
            NewJob = 1
        }
    }

    #Execute_Debug = 1
    #Execute_Clear = "DialogTop"
    ExecuteScript = { # AddAction
        # User selected task
        # * If new, first get a task name
        # * Show dialog for selecting position in task
        # * And maybe details
        # * This might be a command edit window.
        Write-host $Title -ForegroundColor White


        #$Task = Get-DCJob $Data.Parameters.Repository
        $Job = $data.list[$listselecteditem]
        
        #If (!$Task) { $Task = @{} } # a blank hash table for tasks

        #If ($listselecteditem -eq ($Data.List.Count - 1)) {        
        If ($Job.NewJob) {        
            # If ($Data.List[$ListSelectedItem].AddDummy) {

            $Job.Name  = @(
                $Parameters.Fields.Command.Value
                $Parameters.Fields.Id.Value
            ) -join " " -replace "  *", " "

            #$Job.Name = $Data.Fields.Name.Value
            <#
            Write-host "Enter name for the new task: " -NoNewline
            $Input = Edit-ConsoleField -Default "" -foregroundcolor $Color.Field.f -backgroundcolor $Color.Field.b -Length $FieldWidth `
                -Config @{
                Hint = "Task name is required"
                ValidateScript = {
                    If (!$FieldValue) { Return "Task name is required!" }
                }
            }
            If ($Input.Result -like "Cancel") { Return }
            $TaskName = $Input.Data
            
            $Job.$TaskName = @{
                Actions = @(
                    @{
                        Name       = $Data.Fields.Name.Value      # $Data.Parameters.ActionName
                        Order      = 0                            #  $ListSelectedItem - 0.5 # Data.ListSelected
                        Arguments  = $Data.Parameters.Arguments
                        Fields     = $Data.Parameters.Fields
                        # Repository = $Data.Parameters.Repository
                    }
                )
            }
            #>
        }   <#Else {
            #$TaskName = $data.list[$listselecteditem]
            $Actions = $Job.Actions
            Write-Warning "Ask task action order"
            $x = Ask-Dialog $Dialog_SelectTaskJobOrder $TaskName -ReturnData -DialogColor $Color_JobOrder -CursorX 3 -CursorText "_$ActionName___ " -Parameters @{
                TaskName = $TaskName
                Name = $Data.Fields.Name.Value
            }
            $ThisTaskOrder = $x.SelectedItem
            Write-Host "Selected: $ThisTaskOrder"

        }#>

        $Job.Actions += [pscustomobject]@{
                    Name       = $Data.Fields.Name.Value      # $Data.Parameters.ActionName
                    # Order      = $x.SelectedItem              #  $ListSelectedItem - 0.5 # Data.ListSelected
                    Arguments  = $Data.Parameters.Arguments
                    Fields     = $Data.Parameters.Fields | Get-ActionFieldValues
                    
                    # Arguments = @(GetDialogParameters -InputObject @{ Fields = $Updated.Fields })

                    # Repository = $Data.Parameters.Repository
        }

        #Set-PSDebug -Step

        $Jobs = $data.list | GetDCJobFromDataList

        Save-DCJob -jobs $Jobs -Path $Repo

        #$Actions = $Actions | sort { $_.Order }
        
        # Set-PSDebug -Step

        #$Task | ConvertTo-Json -Depth 6 | Set-Content "$($Data.Parameters.Repository)\.Duplicacy\Jobs.json"
        Clear-Rect -Top ($AskFirstChoice.Y) # Clear to bottom of console.

        # Write-host "Save task and jobs... $TaskName"
        #Write-Host "About to end AddAction"
        #Set-PSDebug -Step
        
        Return
    
        <#
        #$JobParameters = GetDialogParameters $Data
        $Jobdata = @()
        $Jobdata += $Data.List  + @{
            Name = $Data.Fields.Name.Value
            Arguments = $Parameters.Arguments.GetEnumerator()
            Fields = $Parameters.Fields.GetEnumerator()
            Repository = $Parameters.Repository
        }

        #Write-Host "Parameters: $JobParameters"
        Write-Host "Path      : $Repo"
        Write-Host "Args      : $($Parameters.Arguments)"
        Write-Host "Fields    : $($Parameters.Fields.GetEnumerator())"

        #Set-PSDebug -Step
        $Jobdata | Where-Object {!$_.AddDummy} | sort { $_.Order }  | ConvertTo-Json | Set-Content "$($Data.Parameters.Repository)\.Duplicacy\Jobs.json"

        # StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Repo -ArgumentList $DucyParameters

        If ($LASTEXITCODE -gt 0) { Return @{Cancel = $true; Reason = "$command failed with error: $LASTEXITCODE"} }
        #>
    }
} # Dialog_AddAction







# Edit a task command
# Select order in the job list for the command
# from the main list; schedule task/conditions (leave much to Task Scheduler)
# Also need a task edit:
# li|st tasks, and select a new command to edit,
$Dialog_SelectTaskJobOrder = @{
    Title = "Select job order in a task"  # To set a dynamic title, use initscript

    Fields = [ordered]@{
        Command = @{
            Text = 'Command'
            Help = "Command"
            #Value = "command.exe /to Execute"
        }
    }
    
    # InitScript is run early by Ask-Dialog.
    # Data can be stored as sub.items of $Data and used by validatescripts and Enable checks
    InitScript = {
        $Data.RepoIsInitialized = Test-Path "$($Data.Parameters.Repository)\.duplicacy"
        If (!$Data.RepoIsInitialized) {
            Write-Warning "Repository is not initialized"
            Write-Warning "Must be a bug, exits"
        }
        # $Parameters contains only the last calls parameters
        # $Data.Parameters are aggregated

        $Data.Title = "Task: '$($Parameters.TaskName)'. Select position for the new action: '$($Parameters.Name)'"
        $Data.Fields.Command.Value = $Data.Parameters.Fields.Command.Value
    }

    # SelectTaskJobOrder
    DialogListScript = {
        # populate the list for this dialog
        $Data.List = @(Get-DCJob $Data.Parameters.Repository -Task $Parameters.TaskName -Action "*" )

        #$ListheaderLines = 0
        # This means the list has a header line, move focus n lines down:
        # $Step = 2

        $n = 0
        $f = $Color.List.f; $b = $Color.List.b

        Write-Host "Before first" -ForegroundColor $f -BackgroundColor $b
        $Data.List | ForEach-Object {
            #If ($n -eq 0) { 
            #    write-host ("First {0,1}:" -F $n) -ForegroundColor $f -BackgroundColor $b
            #} Else        { 
            #    write-host ("Pos   {0,1}:" -F $n) -ForegroundColor $f -BackgroundColor $b
            #}
            #write-host " $($_.Name)    $($_.Description)         $($_.ScheduleTime)"  -ForegroundColor $f -BackgroundColor $b
            write-host "            ______$_"  -ForegroundColor $f -BackgroundColor $b
            #$n++
        }
        # write-host ("Last  {0,1}:" -F $n)  -ForegroundColor $f -BackgroundColor $b
        write-host ("(Last)")  -ForegroundColor $f -BackgroundColor $b
        #$Data.List += @{ Name = "Last" }
        $Data.List += "Last"
    }

    # Actions
    Execute_Clear = "DialogTop"
} # Dialog_SelectTaskJobOrder









Function Add-DCJobAction {
    Param (
        [Parameter(Mandatory=$true)][hashtable]$Job,
        [Parameter(Mandatory=$true)][String]$Name,
        [Parameter(Mandatory=$true)][hashtable]$Action,
        [Single]$Order
    )

    If (!$Action.Fields -or !$Action.Arguments) {
        Write-Error "Add action data with Fields and Arguments"
        exit
    }

    If (!$Order) { $Order = $Job.Actions.count }
    $Action.Order = $Order + 0.1
    $Action.Name = $Name
    $Action.Fields = $Action.Fields | Get-ActionFieldValues

    #$Job.Actions.Add($Action)
    $Job.Actions = @(($Job.Actions + $Action) | sort { $_.Order })
    $Job
}

# Extract the field values. (Don't store full field definitions in job file)
function Get-ActionFieldValues {
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )
    process {
        if ($null -eq $InputObject) { return $null }
        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string])  {
            $Fields = @{}
            $InputObject.GetEnumerator()  | ForEach-Object {
                If ($_.Value -is [hashtable]) {
                    $Fields.($_.Key) = $_.Value.Value
                } else {
                    $Fields.($_.Key) = $_.Value
                }
            }
            Write-Output -NoEnumerate $Fields
        }
        elseif ($InputObject -is [psobject]) 
        {
            $hash = @{}
            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash.($property.Name) = $property.Value
                # $hash.($property.Name) = $property.Value.Value
            }
            [PSCustomObject]$hash
        }
        else
        {
            $InputObject
        }
    }
}

<#
    If (Test-Path -PathType Container $Path) {
        $TaskFile = "$Path\.Duplicacy\Jobs.json"
    } ElseIf (Test-Path -PathType Leaf $Path) {
        $TaskFile = $Path
    } 
#>
#         [Parameter(Mandatory=$true)][String]$Path
# $Taskdef | ConvertTo-Json -Depth 4 | Set-Content $TaskFile

# 
function Save-DCJob {
    param (
        # Path to repository (or a json file)
        [Parameter(Mandatory=$true)][String]$Path,
        # The list of jobs for this repository
        [Parameter(Mandatory=$true)]$Jobs   # (can be hashtable or psobject)
    )

    If ($Jobs -eq $null) { return $null }
    If ($Jobs -isnot [psobject] -and $Jobs -isnot [System.Collections.IEnumerable]) { return $null }
    
    If (Test-Path -PathType Container $Path) {
        $ThisFile = "$Path\.Duplicacy\Jobs.json"
    } ElseIf (Test-Path -PathType Leaf $Path) {
        $ThisFile = $Path
    } 

    Set-PSDebug -Step

    If ($Jobs | Where-Object Name) {
        $Jobs | Where-Object Name | ConvertTo-Json -Depth 4 | Set-Content $ThisFile
    } Else {
        Remove-Item -Path $ThisFile
    }
    
}


# https://stackoverflow.com/questions/22002748/hashtables-from-convertfrom-json-have-different-type-from-powershells-built-in-h
function ConvertJobfileToObject {
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
            $collection = @(
                foreach ($object in $InputObject) { ConvertJobfileToObject $object }
            )
            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject] -and $InputObject.Actions -and $InputObject.Actions[0] -is [psobject]) {
            $InputObject
        }
        elseif ($InputObject -is [psobject]) {
            $hash = @{}
            foreach ($property in $InputObject.PSObject.Properties) {
                If ($Property -ne $null) {
                    $hash.Name = $property.Name
                    $hash.Actions = $property.Value.Actions
                }
            }
            [PSCustomObject]$hash
        } else {
            $InputObject
        }
    }
}




# https://stackoverflow.com/questions/22002748/hashtables-from-convertfrom-json-have-different-type-from-powershells-built-in-h
function ConvertPSObjectToHashtable {
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) 
        {
            $collection = @(
                foreach ($object in $InputObject) { ConvertPSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject]) 
        {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties)
            {
                $hash[$property.Name] = ConvertPSObjectToHashtable $property.Value
            }

            $hash
        }
        else
        {
            $InputObject
        }
    }
}





# Read Jobs/actions
# Read the list of jobs stored in a repository
# Path: path of the repository. The jobs file is found at $Path\.Duplicacy\Jobs.json
# Default: complete structure
# -Name: * for a list of all jobs, or all details of a specific job
# -Action (requires job): To return all details of a specific job/action
# If no switch or -Name, return whole structure
Function Get-DCJob {
    Param (
        [Parameter(Mandatory=$true)][String]$Path,
        [String]$Name,           # Return this job (default all)
        [String]$Action          # Return this action from $Name
    )

    $JobFile = "$Path\.Duplicacy\Jobs.json"

    If (Test-Path $JobFile) {
        Try { 
            $Dataset = Get-Content $JobFile | ConvertFrom-Json | ConvertJobfileToObject
        }
        Catch { 
            $Line = (Script-Line) - 4
            Write-Host "Error in $JobFile, could not read settings. Script line $Line"
            sleep 2
            Return $null
        }

        # If (!$Dataset.Actions) {
        IF (!($Dataset|where name)) {
            Return $null
        }

        If ($Dataset) {
            If (!$Name -and !$Action) {
                $Dataset | where Name | ForEach-Object {
                    $n = 0
#Write-host "Job: $($_.Name)"
                    $_.Actions | where Name | ForEach-Object {
#Write-host "Action: $($_.Name)"
#Set-PSDebug -Step
                        $_ | Add-Member -MemberType NoteProperty -Name "Order" -Value ($n++) -Force
                        $_.Fields  = $_.Fields | Get-ActionFieldValues
                        
                        # Make sure ActionSettings is a property:
                        If (!$_.ActionSettings) {
                            $_ | Add-Member -Force -MemberType NoteProperty -Name "ActionSettings" -Value ""
                        }

                    }
                }

                Return $Dataset
            } # No filter; Return the full structure

            # Filters not working yet...
            If ($Name) {
                If ($Name -eq "*")   { 
                    Return $Dataset.keys }                # List of all job names - list
                If ($Action -eq "*") { 
                    Return $Dataset.$Name.Actions.Name }  # List of this jobs actions Names - list
                If (!$Action)        { 
                    Return $Dataset.$Name }               # Return this complete job as hashtable

                Return $Dataset.$Name.Actions | where {$_.Name -like $Action } # Return an action
                # If ($Task -eq "*") { Return ($dataset | Get-Member -MemberType noteproperty).Name }  # List of all task names - PSObject
                # If ($Action -eq "*") { Return ($Dataset.$Task.Actions | Get-Member -MemberType noteproperty).Name }  # List of this task actions - PSObject
            }
        
            Write-Warning "Probably wrong syntax"
            $Dataset
        }
    }
}

Function Edit-Action {
    Param (
        [object]$Action
    )
    $ThisCommand = $Action.Fields.Command
    If (!$ThisCommand) {return $Action}

    $Dialog = Get-Variable "Dialog_$ThisCommand"
    If (!$Dialog) { Return $Action}

    $Updated = Ask-Dialog $Dialog.Value -Values $Action.Fields -EditOnly
    If ($Updated.OK) {
        $Action.Fields =  $Updated.Fields | Get-ActionFieldValues
        $Action.Arguments = @(GetDialogParameters -InputObject @{ Fields = $Updated.Fields })
        $x = 1
        # $Updated

    }
    Return $Action
}














































<#
    Parameter = 'e'              # Parameter name. Will be prepended with (by default) a hyphen, e.g. "e" ->  "-e"
    ParameterOrder = 20
    Parameterbuild = "Hide"    # Don't use this field to build parameters. (can be used for other things)
    Parameterbuild = "Value"   # Value only
    Parameterbuild = ""        # Default if type not boolean: Parameter and Value
    Parameterbuild = "Param"     # Default if type boolean: Parameter only 
    ValueBuild = "State"  # Use string from state (for boolean but shoukd work for others if defined. (replaces 0 and empty string))
    Parameterbuild = "Multi"    # expand a commaseparated list to multiple 
                                # e.s. parameter = "r", build = "Multi", value = 1,3,4-15:
                                # -r 1 -r 3 -r 4-15
#>
# Return an array of parameters and values
Function GetDialogParameters {
    Param (
        [hashtable]$InputObject,
        [String]$P = "-",
        [switch]$verbose
    )
    
    If ($verbose) { $VerbosePreference = "Continue"}

    If ($InputObject -isnot [hashtable]) {
        return
    }
    $ArgumentList = @()
    If (($InputObject.fields.ParameterOrder -ne $null) -or $InputObject.Fields_ParameterOrder) {
        write-verbose "ParameterOrder"
        $All_FieldNames = @($Dialog.fields.getenumerator() | Sort-Object { If ($_.value.ParameterOrder -ne $null) {[int]($_.value.ParameterOrder)} Else {0.5}}) | ForEach-Object {$_.key}
    } ElseIf ($InputObject.fields -is [OrderedDictionary]) {
        write-verbose  "OrderedDictionary"
        $All_FieldNames = $InputObject.Fields.keys
    } Else {
        write-verbose  "field order"
        $All_FieldNames = @($InputObject.fields.getenumerator() | Sort-Object { $_.value.Order } | ForEach-Object {$_.key})
    }

    $All_FieldNames | ForEach-Object {
        $Field = $InputObject.Fields.$_
        If ($Field.Parameter) {
            $ParameterName = $Field.Parameter
        } Else {
            $ParameterName = $_
        }

        $Parameterbuild = $Field.Parameterbuild
        If (!$Parameterbuild) {
            If ($Field.Type -eq "Boolean") {$Parameterbuild = "Param"}
            Else {$Parameterbuild = ""}
        }

        $Value = $Field.Value
        If ($Value -notmatch '^"[^"]*"$') {
            If ($Value -match " ") { $Value = "`"$($Field.Value)`"" }
        }

        If ($Field.Value) {
            Switch ($Parameterbuild) {
                "Param"   { $ArgumentList += "$P$ParameterName" }
                "Value"   { $ArgumentList += $Value             }
                "Multi"   {
                            $Value -split "," | ForEach-Object {
                                $ArgumentList += "$P$ParameterName", $_
                            }
                        }
                "Hide"    { }      # Don't add this field to the argument list
                Default   { $ArgumentList += "$P$ParameterName", $Value }
            }
        }
    }
    $ArgumentList
}





# https://stackoverflow.com/questions/52116596/powershell-clone-ordered-hashtable
Function HashCopy {
    Param (
        [hashtable]$Source
    )
    # create a copy of a hashtable with all elements
    $Stream = New-Object System.IO.MemoryStream
    $BinaryFormatter = New-Object System.Runtime.Serialization.Formatters.Binary.BinaryFormatter

    Try {
        $BinaryFormatter.Serialize($Stream, $Source)
        $Stream.Position = 0
        $Clone = $BinaryFormatter.Deserialize($Stream)
    }
    Catch {
        Write-Host "Failed to copy hash data. (serialize or deserialize). Reason:  $_"
        write-host $_
    }
    $Stream.Close()
    Return $Clone

    Finally {
        $Stream.Close()
    }
}


# Change colors of a region
# Returns hashtable with original rectangle and contents of region
# to reset: -reset $orgrec
Function ChangeBufferColor {
    Param (
        [int32]$X = 0,
        [int32]$Y = 0,
        [int32]$W = $host.ui.rawui.BufferSize.Width,
        # [int32]$H = $host.ui.rawui.BufferSize.Height - 1,
        #[int32]$H = $host.ui.rawui.CursorPosition.Y + 80,
        [int32]$H = $Y + 1, #$host.ui.rawui.CursorPosition.Y + 80,
        [System.consolecolor]$ForegroundColor = [System.consolecolor]"White",
        [System.consolecolor]$BackgroundColor= [System.consolecolor]"Black",
        #[switch]$Read
        [hashtable]$Reset
    )

    If ($ForegroundColor -or $BackgroundColor) {
        $Setcolor = $true
        If (!$ForegroundColor) {$ForegroundColor = $host.ui.rawui.ForegroundColor}
        If (!$BackgroundColor) {$BackgroundColor = $host.ui.rawui.BackgroundColor}
    }

    If ($Host.name -notlike "consolehost") {
        write-host "(Change colors at $x, $y)"
        Return
    }

    If ($Reset) {
        $pos = new-object System.Management.Automation.Host.Coordinates $Reset.Rect.Left, $Reset.Rect.Top
        $Host.UI.RawUI.SetBufferContents($pos, $Reset.Buffer)
        return
    }

    # Grab the console screen buffer contents using the Host console API.
    # $bufferWidth = $host.ui.rawui.BufferSize.Width
    # $bufferHeight = $host.ui.rawui.CursorPosition.Y
    $rec = new-object System.Management.Automation.Host.Rectangle $X,$Y,$W,$H
    $buffer = $host.ui.rawui.GetBufferContents($rec)
    $OrgBuff = $host.ui.rawui.GetBufferContents($rec)

    # Initialize string builder.
    $textBuilder = new-object system.text.stringbuilder

#    write-host "x=$x y=$y W=$w H=$h Item=$Item Old=$OldItem "

    # Set-PSDebug -Step

    $Lines = $H - $Y
    # Iterate through the lines in the console buffer.
    for($i = 0; $i -lt $Lines; $i++) {
      for($j = 0; $j -lt $W; $j++) {
        $cell = $buffer[$i,$j]
        #If ($cell.foregroundcolor -eq $null) {
        #    Set-PSDebug -Step
        #}
        #If ($Read) { $null = $textBuilder.Append($cell.Character) }
        #If ($Setcolor) {
            $cell.foregroundcolor = $ForegroundColor
            $cell.backgroundcolor = $BackgroundColor
            #$cell.Character = 
            $buffer[$i,$j] = $cell
        #}
      }
      #$null = $textBuilder.Append("`r`n")
      #If ($Read) { $null = $textBuilder.Append("`r`n") }
    }

    If ($Setcolor) {
        $pos = new-object System.Management.Automation.Host.Coordinates $X,$Y
        $Host.UI.RawUI.SetBufferContents($pos, $buffer)
    }
    # write-host "Done setbuffer"
    #return $textBuilder.ToString()
    # Return previous buffer, to allow resetting:
    return @{
        Rect = $rec
        Buffer = $OrgBuff
    }
}



<#
 Ask-Dialog
 
 Input is a structure.
 If OK, structure is returned with data.result = OK
 else originial data but data.result=cancel
 
 $Data:
 @{
   Fields @{
       Name             Field name
       Text             Option text, e.g. "E&xchange". Use & to specify shortcut. Will be displayed as '[E] Exchange'
       Help             Text displayed when user asks for help [?]
       Value            Original or updated data
       Changed (bool)   Has user modified???
       Config           A hashtable with more config details for Edit-ConsoleField

   }
   Result     (OK/Cancel)
   Changed    (user modified anything?)
#>
<#
Sample: 

   $TDialog = @{
    Menu = "&Yes|Approve, &No|Deny"  # String that shows options that are not fields
    Title = "This is a wee settings test:"
    Fields = [Ordered]@{
        Path = @{
            Text = '&Path to exe TEST'
            Help = 'Specify path to your duplicacy.exe'
            Value = "C:\Test\Default"
        }
        Settings = @{
            Text = 'Path to &settings folder'
            Help = 'Specify path where you want all backup configuration files and cache' 
            Value = "C:\Backupfolder\A default Settings test"
        }
        Debug = @{
            Text = "Debug"
            Type = 'Boolean'
            Help = 'Toggle Debug status'
        }
        
    }
   }
#>


$BlinkColorSequence = 'Yellow','white','Yellow','Red','Yellow','white'
$BlinkColorBackground = 'Red'



<#
.PARAMETER Data
    A structure defining a simple form
    The structure contans form fields and the default field data
    And validation scripts for fields and forms.
    Validation script for a field must check $FieldValue.
    Validation script for the form can check $Data.Fields.<Name>.Value
    A Validation script returns an error text, or nothing if all OK
#>
Function Ask-Dialog {
    Param (
        [hashtable]$Dialog,
        [String]$Input,
        [Int]$CaptionWidth = 30,
        [Int]$FieldWidth = 60,
        [String]$Menu,
        [String]$Title,
        [String]$DefaultKey,
        [Switch]$Wizzard,
        [object]$Parameters,
        [String]$CursorText = ">",
        [int32]$CursorX = 0,
        [hashtable]$DialogColor = $Color,
        [Switch]$ReturnData,    # Return the whole $Data structure
        [Switch]$ReturnFields,  # Return fields as a hashtable object or PSObject (depending on input ($Values))
        
        # Edit form (OK does not perform execute script, and returns data structure)
        [Switch]$EditOnly,
        # A list of values to edit, to set default or edit previous data
        [object]$Values
    )

    #region functions
    Function Blink {
        Param ( 
            [String]$BlinkString,
            [String]$String

        )
        $BlinkPos = $host.UI.RawUI.CursorPosition
        foreach ($Color in $BlinkColorSequence) {
            $host.UI.RawUI.CursorPosition = $BlinkPos
            Write-Host " $BlinkString " -ForegroundColor $Color -BackgroundColor $BlinkColorBackground -NoNewline
            sleep -Milliseconds 300
        }
        $host.UI.RawUI.CursorPosition = $BlinkPos
        If ($String) {
            Write-Host $String -NoNewline
        } Else {
            Write-Host $BlinkString -NoNewline -ForegroundColor Black -BackgroundColor Black
        }
    }

    Function ListSelect {
        Param (
            [Int32]$Item,        # New selection
            [Int32]$OldItem =-1,     # Previous selection
            [int32]$Step = 1,    # Distance between items
            [int32]$X = 0,       # x,y,w of list
            [int32]$Y = 0,
            #[int32]$W = $host.ui.rawui.BufferSize.Width - 1,
            [int32]$W = $host.ui.rawui.WindowSize.Width - 1,

            [String]$CursorText = "",
            [int32]$CursorX = 0,
            [System.Management.Automation.Host.Coordinates]$Pos,
            [Hashtable]$ListColor = $DialogColor,
            [Switch]$NoClobber,  # Don't overwrite buffer.
            [switch]$OK          # Use the colors designated confirm choice (OK)
        )

        If ($Pos) {
            $X = $Pos.X; $Y = $Pos.Y
            #Write-aDebug "Pos... $($Pos.X),$($Pos.Y)" 2
        }
        Write-aDebug "x=$x y=$y Item=$Item Old=$OldItem W=$w H=$h" 1
        If ($OldItem -ge 0) {
            # ChangeBufferColor -X $X -Y ($Y + ($OldItem * $Step)) -W $W -ForegroundColor $ColorUn  -BackgroundColor $ColorUnBG
            ChangeBufferColor -reset $data._PrevBuffer
        }

        If ($OK) {
            $ThisColor = $ListColor.ListSelOK
        } Else {
            $ThisColor = $ListColor.ListSel
        }

        If ($Item -ne $OldItem) {
            $PrevBuffer = ChangeBufferColor -X $X -Y ($Y + ($Item * $Step))   -W $W -ForegroundColor $ThisColor.f -BackgroundColor $ThisColor.b
            If (!$NoClobber) { $data._PrevBuffer = $PrevBuffer }
        }

        If ($CursorText) {
            #$Pos = GetPos; $Pos.Y = $ClearAt.Y
            #SetPos $Pos 

            $PosT = New-Object System.Management.Automation.Host.Coordinates
            $PosT.X = $X + $CursorX
            $PosT.Y = $Y + ($Item * $Step)
            SetPos $PosT
            
            #Cursor -X ($X + $CursorX) -Y ($Y + ($Item * $Step))
            Write-Host $CursorText -NoNewline -ForegroundColor $ListColor.ListCur.f -BackgroundColor $ListColor.ListCur.b
            #Write-aDebug "### x=$X CursorX=$CursorX Y=$Y Item=$Item Step=$Step ThisX=$thisX"
        }
    }
    
    # Validate a particular field
    # Check the field's data type or custom validation script
    # This function when editing a field, and on submitting a form
    Function ValidateField {
        Param (
            $This,             # Hash table which defines a field, including value.
            $FieldValue,       # Fieldvalue and Config is an alternative
            [hashtable]$Config,
            $FieldPos               # Where to display error 
        )

        $ValidateResult = ""
        If (!$Config -and !$This) { Write-Error "Don't use both -This and -Config"; exit}

        If (!$Config) {
            # In this case, 'This' is complete.
            $FieldValue = $This.Value
        } Else {
            $This = @{
                Config = $Config
            }
            If ($This.Config.Min -or $This.Config.Max -or $This.Config.Step) {
                $This.Type = 'int'
            }
            # Fieldvalue should also be set by caller in this case
        }
        
        If ($This.Text) {
            $Name = "'$($This.Text)'" -replace '&'
            If ($This.FriendlyName) {
                $Name = "'$($This.FriendlyName)'" -replace '&'
            }
        } Else {
            $Name = "Value"
        }

        If ($FieldValue -eq $Null -or $FieldValue -eq '') {
            If ($This.Config.Required) {
                $ValidateResult = "Required"
            }
        }

        If ($This.Config.Validate -like 'Exist') {
            If (!$FieldValue) {
                $ValidateResult = "Path required"
            } Else {
                If (!(Test-Path -isvalid -Path $FieldValue)) { 
                    $ValidateResult = "Invalid path format"
                }  ElseIf (!(Test-Path -Path $FieldValue)) {
                    $ValidateResult = "Path does not exist"
                }
            }
        }

        If ($This.Type -match 'int') {
            $FieldValue = [int32]$FieldValue
            If ($This.Config.Min -and $FieldValue -lt $This.Config.Min) {
                $ValidateResult = "Minimum $($This.Config.Min)"
            }
            If ($This.Config.Max -and $FieldValue -gt $This.Config.Max) {
                $ValidateResult = "Maximum: $($This.Config.Min)"
            }
        }


        # If custom validate script finds a match it will have priority
        If ($This.Config.ValidateScript) {
            If ($VR = Invoke-Command $This.Config.ValidateScript -NoNewScope) {
                $ValidateResult = $VR 
            }

        }

        If ($ValidateResult) {
            If ($ValidateResult.GetType().name -eq "Hashtable") {
                $KeyName = $ValidateResult.Key
                $Reason = $ValidateResult.Reason
            } ELse {
                If ($This.Text) {
                    $ValidateResult = "$Name $ValidateResult"
                    write-host ''
                }
                If ($FieldPos) { SetPos $FieldPos }
                Blink $ValidateResult 
            }
            $Wizzard = $false
            
            Return @{
                ValidateResult = $ValidateResult
                FieldValue = $FieldValue
            }
            # Return $ValidateResult

            # Non-null means error was found
        }

    }

    # Validate all fields (for which there is a validate script) in the form
    Function ValidateFields {
        Foreach ($FieldName in $Data.Fields.keys) {
            $ValidateResult = ValidateField -This $Data.Fields.Item($FieldName) -Name $FieldName -Pos $MenuIndex.$FieldName.Pos
            If ($ValidateResult) { Return $false }
        }
        Return $true
    }

    Function ValidateForm {
        If ($Data.ValidateScript) {
            $ValidateResult = Invoke-Command $Data.ValidateScript -NoNewScope
            If ($ValidateResult) {
                If ($ValidateResult.GetType().name -eq "Hashtable") {
                    $KeyName = $ValidateResult.Key
                    $Reason = $ValidateResult.Reason
                } ELse {
                    Blink $ValidateResult # -ForegroundColor Yellow -BackgroundColor Red
                }
                $Wizzard = $false
                Return $false
            }
        }
        Return $true
    }
    #endregion func

    If (!$Dialog -and !$Menu) {
        Write-warning "The data for this dialog is not complete!"
        sleep -Seconds 2
        Return -1
    }


    $Step = 1
    $AskFirstChoice = $Null   # Should reset more pointers...
    $ListheaderLines = 1           # Default is to have a 1-line header. If not, set to 0 or header height
    $ListSelectedItem = 0
    $OldListSelected = -1

    $Data = HashCopy $Dialog  # This produces a working set which is a standalone copy (clone) of the original data (including objects in hashtable)
                              # (Users changes which are cancelled will not be saved to $Dialog)
    $UnmodifiedData = HashCopy $Dialog # Original data, to return in case of cancel

    If (!$Data -and !$Menu) {
        Write-warning "Data for this dialog is not complete! (Problem with hashcopy)"
        sleep -Seconds 2
        Return -1
    }

    # If Values is provided, set the default values for the dialog:
    <#
    If ($Values) {
        If ($Values.Fields) {
            $Values.Fields.keys | ForEach-Object {
                $Data.Fields.$_.Value = $Values.Fields.$_
            }
        }
    }
    #>
    
    If ($Values) {
        If ($Values -is [hashtable]) {
            $Values.keys | ForEach-Object {
                $Data.Fields.$_.Value = $Values.$_
            }
        } Elseif ($Values -is [psobject]) {
            foreach ($property in $Values.PSObject.Properties) {
                # $hash[$property.Name] = $property.Value
                $Data.Fields.($property.Name).Value = $property.Value
            }
        } Else {
            Write-error "-Values needs to be hash or PSObject!"
            exit
        }
    }

    $Data.Result = ""
    $Data.OK = $false
    $Data.SelectedItem = 0

    $AutoListUpdate = $DefaultAutoListUpdate # Set default. If $false, for exception actions set $UpdateList=$true or $NoUpdateList=$true, for exception dialogs set .NoAutoListUpdate=$true
    If ($Data.AutoListUpdate) {$AutoListUpdate = $true}
    If ($Data.NoAutoListUpdate) {$AutoListUpdate = $false}
    # .NoAutoListUpdate = $True # Update list after every action. For exception actions set $NoUpdateList=$true in the action.

    If (!$Menu -and $Data.Menu)       {$Menu = $Data.Menu}
    $BaseMenu = $Menu

    # Store parameters in $Data.Parameters
    # Remember previous levels parameters
    $Data.Parameters = $Script:Parameters # $Null
    #$Data.Parameters =  @{}
    $Data.Parameters.Mode = ""
    If ($Parameters) {
        $NewParam = @{}
        foreach ($key in $Parameters.keys) {$NewParam.$key = $Parameters.$key}
        foreach ($key in $NewParam.keys)   {$Data.Parameters.$key = $NewParam.$key}
        #$Script:Parameters
        #$Data.Parameters = $NewParam
    }  #-Parameters @{Mode = "NewBackupSet"}

    # If ($Input) { }
    

    $AskDialogStart = GetPos 

    # Skip this if -Values is given
    # This prevents initscript from overriding the values you want to edit
    If (!$Values -and $Data.InitScript) {
        $InitScriptResult = Invoke-Command $Data.InitScript -NoNewScope
        IF ($InitScriptResult -like 'Cancel'){
            Return
        }
    }

    If (!$Wizzard -and $Data.Wizzard) {$Wizzard = $Data.Wizzard}
    If (!$Title -and $Data.Title)     {$Title = $Data.Title}
    If ($EditOnly) { $Title = "Edit: $Title" }

    If ($Parameters.Debug) { Set-PSDebug -Step}

    $Choices = @()
    $ChoicesHash = @{}
    $MenuIndex   = @{}
    $FieldNames = @()

    # Configure data Fields:
    If ($Data.Fields){
        # $FieldNames needs to be forced to an array: or list collection
        # Not working in PS2 (default for Windows 7)
        #$FieldNames = [System.Collections.Generic.List[System.Object]]($Data.fields.getenumerator() | Sort-Object { $_.value.Order } | ForEach-Object {$_.key})

        If ($Data.fields -is [OrderedDictionary]) {
            $All_FieldNames = $Data.Fields.keys
        } Else {
            $All_FieldNames = @($Data.fields.getenumerator() | Sort-Object { $_.value.Order } | ForEach-Object {$_.key})
        }
        
        Foreach ($FieldName in $All_FieldNames) {
            $Field = $Data.Fields.Item($FieldName)
            If (!$Field) {
                Write-Warning "No field config for $FieldName"
                Set-PSDebug
            }

            If ($Field.InitScript) {
                $Data.Fields.Item($FieldName).Value = Invoke-Command $Field.InitScript
            }

            $Enable = $true
            If ($Field.EnableScript) {
                $Enable = Invoke-Command $Field.EnableScript
                # $Data.Fields.Item($FieldName).Enable = $Enable
                $Field.Enable = $Enable
            } ElseIf ($Field.Enable -eq $false) {
                $Enable = $Field.Enable
            } Else  {
                $Field.Enable = $true
            }
                        
            #If (!$Field.Hidden) { $Field.Hidden = $false }

            $ChoiceDetails = @{}
            $ChoiceDetails.Name = $FieldName
            $ChoiceDetails.Enable = $Field.Enable

            $ChoiceDetails.Hidden = $Field.Hidden
            $ChoiceDetails.Type = $Field.Type

            # Get initial value. Also put it back to the variable if user accepts changes
            If ($Field.ValueName) {
                $Data.Fields.$FieldName.Value = Get-Variable -Name $Field.ValueName -ValueOnly
            }

            If (($This.StoreInRegistry -or $Data.StoreInRegistry) -and !($This.DontStoreInRegistry)) {
                $RegValueName = $FieldName
                If ($Field.RegName)   { $RegValueName = $Field.RegName }
                $Field.Value = Get-RegistryValue $Data.Registry $RegValueName
                If ($Field.Type -eq 'Boolean') {
                    $Field.Value = $Field.Value -eq "True"
                }
            }

            $ChoiceText = $Field.Text
            If (!$ChoiceText ){ $ChoiceText = $FieldName }

            $ChoiceDetails.Text = $ChoiceText -Replace '&',''
            $ChoiceDetails.Info = $Field.Help
            If (!$ChoiceDetails.Info) {
                $ChoiceDetails.Info = $ChoiceDetails.Text
            }

            If ($Field.Type -ne "Caption" -and !$Field.Hidden ) {
                $Index = $ChoiceText.IndexOf("&")
                Do {
                    $Shortcut = ($ChoiceText.ToUpper())[$Index + 1]
                    $Index ++
                } Until ($MenuIndex.keys -notcontains $Shortcut -or $Index -ge $ChoiceText.length -1)
                If ($MenuIndex.keys -contains $Shortcut ) {
                    write-Warning "Script bug: A field already has this shortcut: $shortcut" 
                    write-Warning "Choice: $ChoiceText" 
                    Write-Warning "FieldName: $FieldName"
                    $MenuIndex|select Text, key
                    Set-PSDebug -Step
                    # exit 1
                } Else {
                    $ChoiceDetails.Key = $Shortcut
                    $Field.Key = $ChoiceDetails.Key
                    $MenuIndex.Add([String]$Shortcut,  $ChoiceDetails)                     
                }
                $MenuIndex.Add($FieldName, $ChoiceDetails)
            }     

            If ($Enable -and $field.Type -ne "Caption" -and !$Field.Hidden) {
                $FieldNames += $FieldName
            } Else {
                #continue
            }

            $Choices += $ChoiceDetails
            $ChoicesHash.$FieldName = $ChoiceDetails
            #$ChoicesHash.$FieldName.EnableX = $Data.Fields.Item($FieldName).Enable

            $BrowseTag = ""
            If ($Field.Type -match "Folder|File") {
                $BrowseTag = "?"
            }
            # $Menu = "$Menu; !$BrowseTag$($Field.Text)|$($Field.Help)"
        }
    }

    # Configure action menus:
    If ($Data.Actions){
        If ($Data.Actions -is [OrderedDictionary]) {
            $All_ActionNames = $Data.Actions.keys
        } Else {
            $All_ActionNames = @($Data.Actions.getenumerator() | Sort-Object { $_.value.Order } | ForEach-Object {$_.key})
        }
        foreach ($ActionName in $All_ActionNames) {
            $Action = $Data.Actions.Item($ActionName)
            $Enable = $true
            If ($Action.EnableScript) {
                $Enable = Invoke-Command $Action.EnableScript
                $Data.Actions.Item($ActionName).Enable = $Enable
            } ElseIf ($Action.Enable -eq $false) {
                $Enable = $Action.Enable
            } Else  {
                $Action.Enable = $Enable = $true
            }

            $ChoiceDetails = @{}
            $ChoiceDetails.Name = $ActionName
            $ChoiceDetails.ChoiceType = "Action"
            $ChoiceDetails.Enable = $Action.Enable
            $ChoiceDetails.EnableScript = $Action.EnableScript

            $ChoiceText = $Action.Text
            $ChoiceDetails.Text = $ChoiceText -Replace '&',''
            $ChoiceDetails.Info = $Action.Help
            $Index = $ChoiceText.IndexOf("&")

            Do {
                $Shortcut = ($ChoiceText.ToUpper())[$Index + 1]
                $Index ++
            } Until ($MenuIndex.keys -notcontains $Shortcut -or $Index -ge $ChoiceText.length -1)

            If ($MenuIndex.keys -contains $Shortcut ) {
                write-Warning "Script bug: An action already has this shortcut: $shortcut" 
                write-Warning "Choice: $ChoiceText" 
                Write-Warning "ActionName: $ActionName"
                # exit 1
            } Else {
                $ChoiceDetails.Key = $Shortcut
                $MenuIndex.Add([String]$Shortcut,  $ChoiceDetails)
            }

            $Action.Key = $ChoiceDetails.Key
            $MenuIndex.Add($ActionName, $ChoiceDetails)

            If ($Enable) {$ActionNames += $ActionName}
            
            $Choices += $ChoiceDetails
            $ChoicesHash.$ActionName = $ChoiceDetails
            #$ChoicesHash.$ActionName.EnableX = $Data.Actions.Item($ActionName).Enable
            #$Menu = "$Menu;$($Action.Text)|$($Action.Help)"
        }
    }
        
    $SelectedField = -1
    If ($Wizzard) { $SelectedField = 0 }
    $UpdateList = $true   # Update list data
    $RefreshList = $true  # Redraw
    $RefreshMenu = $true

    $AskDialogTop = GetPos 
    If (!$Data.Numbers) {$Data.Numbers = @{}}
    $Data.Numbers.ListStart = 0  # Start with page 0 - in this version
    
    $WindowSize = $host.ui.RawUI.WindowSize

    :ChoiceLoop Do {

        If ($RefreshOnResize) {
            If ($WindowSize.Height -ne $host.ui.RawUI.WindowSize.Height -or 
                    $WindowSize.Width -ne $host.ui.RawUI.WindowSize.Width) {
                # Console was resized
                #write-host "###" -ForegroundColor White; sleep 0.3
                $RefreshList = $true
                $WindowSize = $host.ui.RawUI.WindowSize
            }
        }

        If ($RefreshList -or $UpdateList) {
            # Load data into $Data.list
            If ($UpdateList -and $Data.ListUpdateScript -and !$Data.DialogListScript) {
                SetPos $AskDialogTop
                Write-Host "$Title - Loading...".Padright($host.ui.rawui.BufferSize.Width, ' ') -ForegroundColor White
                If ((Invoke-Command $Data.ListUpdateScript -NoNewScope) -like 'Cancel') {
                    Return
                }
                # If ($Data.ExitDialog) { Return }

            }

            # Refresh title
            SetPos $AskDialogTop
            If ($Title)      {
                Write-Host $Title.Padright($host.ui.rawui.BufferSize.Width, ' ') -ForegroundColor White
            } 
            If ($Data.Info)  {
                Write-Host ($Data.Info).Padright($host.ui.rawui.BufferSize.Width, ' ') -ForegroundColor White
            }
            $AskDialogListPos = GetPos  

            # Redraw the list
            If ($Data.DialogListScript) {
                # $Listcount =  $Data.List.Count
                #Write-Host "New item $ListSelectedItem, old item: $OldListSelected"
                If ($RefreshList) {
                    $RefreshMenu = $true
                    SetPos $AskDialogListPos

                    If ($ClearListBackground -and $AskFirstChoice) {
                        Clear-Rect -Top ($AskDialogListPos.Y)  -Bottom ($AskFirstChoice.Y - 1) # -char '=' # Clear to bottom of console.
                        $ClearListBackground = $false
                    }

                    # Update $Data.List and display the list:
                    $ShowListCount = Invoke-Command $Data.DialogListScript -NoNewScope
                    If (!$ShowListCount) {
                        If ($Data.List) {
                            $ShowListCount = $Data.List.Count
                        }
                    }

                    Write-Host "".Padright($host.ui.rawui.BufferSize.Width, ' ') # Clear the line under list -ForegroundColor White   
                    # If (!$AskFirstChoice) {$AskFirstChoice = GetPos  }
                    $AskFirstChoice = GetPos  
                    If ($ListSelectedItem -ge $ShowListCount) {
                        $ListSelectedItem = $ShowListCount
                    }
                }
            } ElseIf ($Data.ListRedrawScript) {
                $ShowListCount = Invoke-Command $Data.ListRedrawScript -NoNewScope
            } ElseIf ($Data.List) {
                #$ListheaderLines = 1
                $ShowListCount = Show_List
            }

            $AskFirstChoice = GetPos  

            If (!$ShowListCount) {
                If ($Data.List) {
                    $ShowListCount = $Data.List.Count
                }
            }

            If ($ShowListCount -lt -1) {
                $ShowListCount = 0
            }

            #Set-PSDebug -Step
            #write-host "ShowListCount='$ShowListCount'"

            # Set new max item
            # set a new $AskFirstChoice pos
            # Clear to bottom: Clear-Rect -Fr{omThisLine
            If ($Data.Numbers) {
                $Data.Numbers.MinNumber = 0
                $Data.Numbers.MaxNumber = $ShowListCount - 1
                $Data.Numbers.ListCount = $Data.List.Count
                #$Data.Numbers.MaxNumber = $Data.List.Count - 1
                # $Data.Numbers.ListStart = 0  # Which page
                If ($ListSelectedItem -ge $Data.Numbers.MaxNumber) {
                    $ListSelectedItem = $Data.Numbers.MaxNumber
                }
            }
            #$Data.Selected = $ListSelectedItem
            #$Data.SelectedValue = $Data.List[$ListSelectedItem]

        } # Refresh



        # Highlight selected
        if ($debug) {Set-PSDebug -Step}

        If ($data.list -and $data.list[0] -ne $null) { #  -or $RefreshList) {
            # Select new item
            If ($RefreshList) {$OldListSelected = -1}
            If ($OldListSelected -eq -1) {
                ListSelect -item $ListSelectedItem -Y ($AskDialogListPos.Y + $ListheaderLines) -Step $Step -CursorText $CursorText -CursorX $CursorX
                $OldListSelected = $ListSelectedItem
            } ElseIf ($OldListSelected -ne $ListSelectedItem -or $RefreshList ) { # -or $RefreshList
                If (!$RefreshList) {
                    ListSelect -item $ListSelectedItem -OldItem $OldListSelected -Y ($AskDialogListPos.Y + $ListheaderLines) -Step $Step -CursorText $CursorText -CursorX $CursorX
                    $OldListSelected = $ListSelectedItem
                } Else {
                    ListSelect -NoClobber -item $ListSelectedItem -Y ($AskDialogListPos.Y + $ListheaderLines) # -ColorSel $DialogColor.ListSelOK.f -ColorSelBG $DialogColor.ListSelOK.b
                }
            }
        }

        If ($Data.Numbers) {$Data.Numbers.Number = $ListSelectedItem}

        If (!$AskFirstChoice) {$AskFirstChoice = GetPos  }
        SetPos $AskFirstChoice

        $RefreshList = $false
        $UpdateList  = $false

        # Display enabled fields and build menu
        If ($RefreshMenu -or (($OldListSelected -eq $ListSelectedItem) -or (!$Data.DialogListScript))) {
            If ($RefreshMenu) {
                $Menu = $BaseMenu
                If ($Data.Fields) {
                    $FieldNames = @()
                    Foreach ($FieldName in $All_FieldNames) {
                        $Field = $Data.Fields.Item($FieldName)
                        $ChoicesHash[$FieldName].Enable = $Field.Enable
                        IF ($Field.Hidden) {continue}

                        If ($Field.EnableScript) {
                            $Field.Enable = Invoke-Command $Field.EnableScript
                        }

                        If ($Field.Enable) {
                            If ($field.Type -eq "Caption") {
                                Write-Host $Field.Text.Padright($host.ui.rawui.BufferSize.Width, " ") -ForegroundColor White
                                continue
                            }
                            $FieldNames += $FieldName
                        } Else {
                            continue
                        }

                        $shortcut = $Field.Key
                        $Plaintext = $Field.Text -Replace '&',''
                        $MenuText = "[$shortcut] $Plaintext"
                        write-host $MenuText.Padright($CaptionWidth) -NoNewline
                            
                        If ($FieldName) {
                            $Pos = GetPos  
                            $MenuIndex.$FieldName.Pos = $Pos
                        }
                    
                        # Write-Host $Field.Value -ForegroundColor Cyan -NoNewline
                        Edit-ConsoleField -Print -Default $Field.Value -foregroundcolor $Color.Field.f -backgroundcolor $Color.Field.b  -type $Field.Type -Config $Field.Config -Length $FieldWidth
                        Write-host ""    #Clear-Right #-nl
                        $Menu = "$Menu;!$BrowseTag$($Field.Text)|$($Field.Help)"
                    }

                    If ($selectedfield -gt -1) {
                        If ($selectedfield -gt $FieldNames.count - 1) {
                            $selectedfield = $FieldNames.count - 1
                        }
                    }

                    # Clear bottom if changing number of fields
                    If ($FieldNames.count -lt $LastFieldCount) {
                        Clear-Rect -FromThisLine
                    }
                    $LastFieldCount = $FieldNames.count
                }

                $Choices | ForEach-Object {
                    If ($_.EnableScript) {
                        $_.Enable = Invoke-Command $_.EnableScript
                    }
                }

                <#
                If ($Data.Actions) {
                    foreach ($ActionName in $All_ActionNames) {
                        $Action = $Data.Actions.Item($ActionName)

                        If ($Action.EnableScript) {
                            $Action.Enable = Invoke-Command $Action.EnableScript
                        }

                        #If ($Action.Enable -or 
                        #    ($Action.EnableScript -and (Invoke-Command $Action.EnableScript))
                        #) {
                        #    $Menu = "$Menu;$($Action.Text)|$($Action.Help)"
                        #}
                    }
                }#>

                # $Menu = $Menu -replace "^ *, *", ""
                $RefreshMenu = $false
                $AskDialogPromptLine = GetPos  
            }
        }

        $ShortcutToName = $Null
        $PreviousField = $Null

        If (!$AskDialogPromptLine) {$AskDialogPromptLine = GetPos  }
        If ($AskDialogPromptLine) {SetPos $AskDialogPromptLine}

        #Write-Host ""
        #$AskDialogInput = GetPos  
        #If Wizzard mode, set selectedfield. If not use Get-choice to select a field/action
        If ($SelectedField -eq -1) {
            #$KeyName = Get-Choice $Menu -ReturnkeyName  -NoEnter:($Data.NoEnter) -Help $Data.Help # -DefaultKey "Q"
            Get-Choice -OnlyPrompt -ChoiceList $Choices -NumberDef $Data.Numbers
            $AskDialogInput = GetPos  
            $KeyName = Get-Choice -NoPrompt -ChoiceList $Choices -ReturnkeyName -NoEscape:($Data.NoEscape) -NoEnter:($Data.NoEnter) -Help $Data.Help -Numberdef $Data.Numbers # -DefaultKey "Q"
            #$KeyName = [string]$KeyName
        } ElseIf ($SelectedField -eq -2) {
            # $KeyName = 'OK' or 'Cancel'
        } Else {
            Get-Choice -OnlyPrompt -ChoiceList $Choices -NumberDef $Data.Numbers
            $AskDialogInput = GetPos  
            If ($SelectedField -ne -1) {
                $KeyName = $FieldNames[$SelectedField]
                If (!$KeyName) {
                    Write-Warning "Key not defined"
                    Write-Host "Fieldnames: $FieldNames"
                    Write-Host "SelectedField: $SelectedField"
                    #Set-PSDebug -Step
                }
            } Else {
                # When $SelectedField -eq -1, Keyname is defined elsewhere
            }
        }
        
        If ($KeyName -match "^[0-9]+$") {
            #Write-aDebug "Key: $Keyname ListSelectedItem=$ListSelectedItem Old=$OldListSelected"
            If (([int]$KeyName -le $Data.Numbers.MaxNumber) -and ([int]$KeyName -ge $Data.Numbers.MinNumber)) {
                #Write-aDebug "##Key: $Keyname ListSelectedItem=$ListSelectedItem Old=$OldListSelected $(get-date)" 2 
                #Set-PSDebug -Step
                $ListSelectedItem = [int]$KeyName 
                $Data.SelectedItem = $ListSelectedItem + $Data.Numbers.ListStart
            }
            continue ChoiceLoop
        }

        Switch ($KeyName) { 
            # TAB/Shift TAB

            'Page' {
                # $ListSelectedItem = [int]$KeyName 
                $ListSelectedItem = $Data.Numbers.Number

                Write-aDebug "Number: $ListSelectedItem"


                $Data.SelectedItem = $ListSelectedItem + $Data.Numbers.ListStart
                $RefreshList = $true
                continue ChoiceLoop
            }

            "_First" {
                $SelectedField = 0
                continue ChoiceLoop
            }
            "_Last"  {
                $SelectedField = $FieldNames.Count - 1
                continue ChoiceLoop
            }
            "F4" {
                Write-host ""
                Write-Host "Number of Variables: $((Get-Variable).count)"
                Get-Process powershell
                Write-host "Parameters:"; $Data.parameters
                # $MaxMem = Get-Process powershell | sort WorkingSet -Descending | select -first 1
                $Script:Debug = !$Script:Debug 
                Set-PSDebug -Step
                continue ChoiceLoop
            }

            "F5" {
                $RefreshList = $true
                continue ChoiceLoop
            }


            'OK' {
                # Validate fields.
                $SelectedField = -1
                If (!(ValidateFields)) {continue ChoiceLoop}
                If (!(ValidateForm))   {continue ChoiceLoop}
                
                # Store all changed variable/registry-linked fields in variables/registry
                Foreach ($FieldName in $Data.Fields.keys) {
                    $This = $Data.Fields.Item($FieldName)
                    If ($This.Changed) {
                        If ($This.ValueName) {
                            # Set-Variable -Name ($This.ValueName) -Value ($This.Value) -Scope Global
                            $Var = Get-Variable -Name ($This.ValueName)
                            $Var.Value  = $This.Value
                        }
                        If (($This.StoreInRegistry -or $Data.StoreInRegistry) -and !($This.DontStoreInRegistry)) {
                            $RegValueName = $FieldName
                            If ($This.RegName)   { $RegValueName = $This.RegName  }
                            Set-RegistryValue $Data.Registry $RegValueName $This.Value
                        }
                    }
                }

                If ($Data.Execute_Debug -eq 1) {
                    #Set-PSDebug -Step
                    Show-Anchors
                    write-host "About to clear '$($Data.Execute_Clear)'"
                    $x = Read-Host "s to step"
                    If ($x -like "s") {Set-PSDebug -Step}
                }

                # Clear at OK
                $ClearAt = Switch ($Data.Execute_Clear) {
                    "DialogStart" {$AskDialogStart}
                    "DialogTop"   {$AskDialogTop}
                    "ListPos"     {$AskDialogListPos}
                    "FirstChoice" {$AskFirstChoice}
                    Default       {$AskFirstChoice}
                }
                
                Clear-Rect -Top ($ClearAt.Y) # Clear to bottom of console.

                If ($Data.Execute_Line -like "Line") { Clear-Rect -Top ($ClearAt.Y ) -EOL -Char '_' }
                If ($Data.Execute_Name -and $Data.Execute_Name -ne "-") { write-host $Data.Execute_Name -ForegroundColor Black -BackgroundColor Yellow }

                # Cursor -Y $ClearAt.Y
                $Pos = GetPos; $Pos.Y = $ClearAt.Y
                SetPos $Pos 

                #Clear-Rect -Top $AskFirstChoice.Y # Clear to bottom of console
                # $ClearAt => $AskFirstChoice 
                #Set-PSDebug -Step
                
                # If EditOnly do not execute script
                If ($EditOnly) {
                    $RefreshList = $true
                } Elseif ($Data.ExecuteScript) {
                    Switch -regex ($Data.Execute_Clear) {
                        "DialogTop|ListPos" {
                            $RefreshList = $true; $RefreshMenu = $true
                        }
                        "FirstChoice" {
                            $RefreshMenu = $true
                        }
                        Default {$RefreshMenu = $true}
                    }
                    
                    If ($Data.Execute_Clear -notin "DialogTop","ListPos")  {
                        If ($data.list -and ($data.list[0] -ne $null)) {
                            ListSelect -NoClobber -item $ListSelectedItem -Y ($AskDialogListPos.Y + $ListheaderLines) -ColorSel $DialogColor.ListSelOK.f -ColorSelBG $DialogColor.ListSelOK.b
                        }
                    }

                    Write-aDebug "OK - Eecute Clear: $($Data.Execute_Clear)"
                    Write-aDebug "RefreshList: $RefreshList" 1
                    Write-aDebug "RefreshMenu: $RefreshMenu" 2
                    
                    Write-host "" # "Execute script____"
                    Invoke-Command $Data.ExecuteScript -NoNewScope
                    # Script will optionally set $ExecuteResult

                    If ($LASTEXITCODE -gt 0) { # If action was an external command:
                        Blink "Action failed"
                        Read-Host "Enter to retry dialog!"
                        continue ChoiceLoop
                    }

                    # If ExecuteScript has set this value:
                    If ($ExecuteResult) {
                        If ($ExecuteResult.GetType().name -eq "Hashtable") {                            
                            If ($ExecuteResult.Cancel) {
                                $Reason = $ExecuteResult.Reason
                                If (!$Reason) {$Reason = "Action failed"}
                                Blink $Reason
                                Read-Host "Enter to return to dialog!"
                                continue ChoiceLoop
                            }
                        } ELse {
                            #Blink $ExecuteResult # -ForegroundColor Yellow -BackgroundColor Red
                        }
                    }
                }

                $Data.Result = "OK"
                $Data.OK = $true

                If ($ReturnData -or $EditOnly) {
                    Return $Data
                } ElseIf ($ReturnFields) {
                    # return fields as hashtable or properties (based on input)

                    # First build hashtable
                    # If input was psobject, return fields as psobject
                    $DialogFields = @{}
                    $Data.Fields.keys | ForEach-Object {
                        #$Field = $InputObject.Fields.$_
                        #If ($Field.Parameter) {
                        #    $ParameterName = $Field.Parameter
                        #} Else {
                        #    $ParameterName = $_
                        #}
                        #$Value = $Field.Value
                        #If ($Value -notmatch '^"[^"]*"$') {
                        #    If ($Value -match " ") { $Value = "`"$($Field.Value)`"" }
                        #}

                        $DialogFields.add($_,$data.Fields.$_.Value)
                    }

                    If ($Values -and $Values -is [hashtable]) {
                        Return [PSCustomObject]$DialogFields
                    } Else {
                        Return $DialogFields
                    }
                } Else {
                    Return
                }
            }
            'Cancel' {
                $SelectedField = -1
                #$Bottom = [Math]::Max($Bottom, (CursorY))
                #Clear-Rect -Bottom $Bottom -Top $AskDialogTop.Y # -Char '�'
                Clear-Rect -Top $AskDialogStart.Y  # Clear to bottom of console 
                $UnmodifiedData.Result = "Cancel"
                $UnmodifiedData.OK = $null

                #Return # $UnmodifiedData
                If ($ReturnData) {
                    Return $UnmodifiedData
                } Else {
                    Return
                }

            }
        }

        If ($Keyname -eq $Null) { 
            Write-warning "No input!" 
        }

        #$Name = $menuindex.item([char]$KeyName).name
        # KeyName can be both a char and string, don't limit
        # Pos is stored in [string]name
        $Name = $menuindex.item($KeyName).name

        If (!$Name) {
            #Set-PSDebug -Step
            Write-Warning "Bug: No field/action name found for key $keyname"
            sleep 2
            continue
        }

        If (!$Name -and $KeyName.Length -eq 1) { 
            write-warning "Bug? variable type problem or missing choice $keyname in menuindex"
            $Name = $menuindex.item([char]$KeyName).name
            If ($Name -eq "") {
                $Name = $menuindex.item($KeyName).name
            }
            If ($Name -eq "") {
                write-warning "Could not link $keyname to an option in menuindex"
                sleep 2
            }
        }
#Write-aDebug "                                                      Name: $Name   Pos: "
#sleep 2

#Set-PSDebug -step
        If ($Data.Fields.keys -notcontains $Name -and $Data.Actions.keys -notcontains $Name) {
            Write-aDebug "Could not find Field or Action with name '$Name' in this dialog"
            sleep 2
        }

        If (!($Data.Fields.$Name) -and !($Data.Actions.$Name)) {
            Write-warning "No fields or actions with name '$Name' defined..."
            Write-Warning "Keyname: $Keyname"
            sleep 2
            Return $Keyname
        }

        
        # Edit a field:
        If ($Data.Fields.$Name) {
            $RefreshMenu = $true

            # $SelectedField must be set correctly...
            $SelectedField = [array]::indexof($fieldnames, $Name)
            If ($SelectedField -eq -1) {
                $SelectedField = 0
                Write-Warning "Ask-Dialog bug: Could not find field name/index"
            }
            
            $Pos = $menuindex.item($KeyName).Pos
            If (!$Pos) {
                $FName = $menuindex.item($KeyName).Name
                $Pos = $menuindex.$FName.Pos
            }
            If ($Pos) { 
                SetPos $Pos
            } Else {
Write-aDebug "                                                      No pos...            "
sleep 1
            }

            # From Ask-Dialog, edit field
            $Edit = Edit-ConsoleField -Default $Data.Fields.$Name.Value -foregroundcolor $Color.FieldEdit.f -backgroundcolor $Color.FieldEdit.b  -type $Data.Fields.$Name.Type -Config $Data.Fields.$Name.Config  -Length $FieldWidth -ChoiceList $choices # -MenuIndex $MenuIndex

            #$KeyName
            If ($Edit -and $Edit.Result -like "Shortcut") {
                #write-host "_____Shortcut received: $($Edit.Key)"; sleep -Seconds 2
                $Data.Fields.$Name.Value = $Edit.Data  # Update the value in the dialog struct
                $Data.Fields.$Name.Changed = $true     # This field was changed
                $Data.Changed = $true                  # At least one field in the dialog was changed

                $ShortcutToName = $MenuIndex.($Edit.Key).Name 
                $PreviousField = $SelectedField
                $SelectedField = [array]::indexof($fieldnames, $ShortcutToName)

                $Name = $ShortcutToName
            }

            If ($Edit -and (@('OK', 'Next', 'Prev') -contains $Edit.Result)) {
                $Data.Fields.$Name.Value = $Edit.Data  # Update the value in the dialog struct
                $Data.Fields.$Name.Changed = $true     # This field was changed
                $Data.Changed = $true                  # At least one field in the dialog was changed
                
                If ($Edit.Result -eq 'Next' -and $SelectedField -lt $FieldNames.Count - 1) { $SelectedField ++ }
                If ($Edit.Result -eq 'Prev' -and $SelectedField -gt 0)  { $SelectedField -- }

                If ($Edit.Result -eq 'OK') {
                    If ($Wizzard) {
                        If ($SelectedField -ge $FieldNames.Count -1 ) {
                            # Last field confirmed.
                            $SelectedField = -2
                            $KeyName = 'OK' #$Edit.Result
                            #$Wizzard = $False
                        } ElseIf ($SelectedField -lt $FieldNames.Count - 1) {
                            $SelectedField ++
                        }
                    } Else {
                        $SelectedField = -1
                    }
                }

                <# If ($Edit.Result -eq 'OK' -and $Wizzard -and $SelectedField -ge $FieldNames.Count -1 ) {
                    # Last field confirmed.
                    $SelectedField = -1
                    $KeyName = 'OK' #$Edit.Result
                } #>
                
            }

<#            If ($Wizzard -and $Edit.Result -like 'Cancel') {
                $SelectedField = -1
                $KeyName = 'Cancel' #$Edit.Result
                $Wizzard = $false
            }#>

            If ($Edit.Result -like 'Cancel') {
                If ($Wizzard) {
                    $SelectedField = -2
                } Else {$SelectedField = -1}
                $KeyName = 'Cancel' #$Edit.Result
                $Wizzard = $false
            }
            #Write-aDebug "__Keyname: $KeyName SF: $SelectedField"
        }

        If ($Data.Actions.$Name) {
            $RefreshMenu = $true
            If ($ShortcutToName) {
                $SelectedField = $PreviousField
            }
            $host.UI.RawUI.CursorPosition = $AskFirstChoice
            $Data.Result = $Name
            If ($Data.Actions.$Name.Action) {
                
                #write-host "Action..." -NoNewline ; sleep 0.2
                #Set-PSDebug -Step
                If (!$Data.Actions.$Name.NoValidate) {
                    If (!(ValidateFields)) {continue ChoiceLoop}
                    If (!(ValidateForm))   {continue ChoiceLoop}
                }


                If ($Data.Actions.$Name.Debug) {
                    Show-Anchors
                    write-host "About to clear '$($Data.Actions.$Name.Clear)'"
                    $x = Read-Host "s to step"
                    If ($x -like "s") {Set-PSDebug -Step}
                }

                Switch -regex ($Data.Actions.$Name.Clear) { # $Data.Execute_Clear
                    "DialogTop|ListPos" {$RefreshList = $true; $RefreshMenu = $true}
                    "FirstChoice" {$RefreshMenu = $true}
                    Default {$RefreshMenu = $true}
                }

                If ($Data.Actions.$Name.Clear -notin "DialogTop","ListPos")  {
                    If ($data.list -and ($data.list[0] -ne $null)) {
                        ListSelect -NoClobber -item $ListSelectedItem -Y ($AskDialogListPos.Y + $ListheaderLines) -OK # -ColorSel $Color.ListSelOK.f -ColorSelBG $Color.ListSelOK.b
                    }
                }

                Write-aDebug "Action - Execute Clear: $($Data.Actions.$Name.Clear)"
                Write-aDebug "RefreshLIst: $RefreshList" 1
                Write-aDebug "RefreshMenu: $RefreshMenu" 2

                # Clear at action
                $ClearAt = Switch ($Data.Actions.$Name.Clear) {
                    "DialogStart" {$AskDialogStart}
                    "DialogTop"   {$AskDialogTop}
                    "ListPos"     {$AskDialogListPos}
                    "FirstChoice" {$AskFirstChoice}
                    Default       {$AskFirstChoice}
                }
                Write-aDebug $Clearat 3
                Clear-Rect -Top ($ClearAt.Y) # Clear to bottom of console.

                #If ($Data.Execute_Line -like "Line") {
                #    Clear-Rect -Top ($ClearAt.Y) -EOL -Char '_'
                #}
###
                #Clear-Rect -Top ($AskFirstChoice.Y )
                If ($Data.Actions.$Name.Line) {
                    Clear-Rect -Top ($ClearAt.Y) -EOL -Char '_'
                }

                If ($Data.Actions.$Name.Name) {
                    If ($Data.Actions.$Name.Name -ne "-") {
                        Write-Host $Data.Actions.$Name.Name -ForegroundColor Cyan -BackgroundColor DarkRed
                    }
                } Else {
                    # Write-Host $Name -ForegroundColor Cyan -BackgroundColor DarkRed
                }

                #Debug = 1
                #Clear = "DialogTop"  # "DialogTop", "ListPos", "FirstChoice" (Default)
                #Line 	"Line"       # (write a line at the top)
                #Name	"Title or info at top. Default is"


                # $Data.Actions.$Name.Result = Invoke-Command $Data.Actions.$Name.Action -NoNewScope
                #write-host "Invoke command $Name" -ForegroundColor Cyan -NoNewline; sleep -Seconds 1
                
                Invoke-Command $Data.Actions.$Name.Action -NoNewScope
                $Data.Actions.$Name.Result = $LASTEXITCODE

                #write-host "Invoke command $Name Done" -ForegroundColor Cyan -NoNewline; sleep -Seconds 1

                #Write-Host "!!Action result: $LASTEXITCODE"
            } Else {
                If ($Data.Actions.$Name.Return -or $Data.Actions.$Name.ClearRect) {
                    Clear-Rect -Top ($AskFirstChoice.Y ) 
                }
            }
            
            If ($Data.Actions.$Name.Return) {
                #$Data.Result = $Name
                Return $Data
                # optional return (result = key... wat about saving data?
                #       If $Data.fields not null and $Data.Changed = $true  then ask! ( save Y/N/cancel)
            }

            $RefreshList = $true
            $RefreshMenu = $true

            # Auto listupdate feature
            #If ($AutoListUpdate -or ($Data.Actions.$Name.UpdateList -and !$Data.Actions.$Name.NoUpdateList)) {
                # $UpdateList = $true
            #}
            $UpdateList = ($AutoListUpdate -or ($Data.Actions.$Name.UpdateList -and !$Data.Actions.$Name.NoUpdateList))


        }
    } Until ($KeyName -eq $Null)
}


Function Show-Help {
    Param ( 
        [Hashtable[]]$Choices,
        [String]$Help,
        [int32]$HelpY
    )
    # [Switch]$UseAlt
    #[object]$Choices,
    #[hashtable]$ChoiceHashList,

    $OrgPos = $host.UI.RawUI.CursorPosition
    $ActionShown = $false

    $Alt = " [Alt]+"
        
    If (!$HelpY) {
        $HelpY = $OrgPos.Y + 1
        #write-host "MISSING Y..." ; sleep 1
    }

    # Clear-Rect -Top ($HelpY + 1) -Bottom ($HelpY + 2) -Char '_'
    Clear-Rect -Top ($HelpY + 1) -EOL -Char '_'
    Clear-Rect -Top ($HelpY + 2)  # Clear to bottom of console. -Bottom $Bottom

    #Write-Host ""
    $Pos = New-Object System.Management.Automation.Host.Coordinates
    $Pos.Y = $HelpY + 2; $Pos.X = 0
    $host.UI.RawUI.CursorPosition = $Pos


    If ($Choices) {
        If ($Script:Debug) {Set-PSDebug -step}
        Foreach ($C in $Choices) {
            If ($C.Enable -and !$C.Hidden) { #  
                $HelpLines = $C.Info -split "`n`r?" -join "`n           "  # align secondary lines like " X - xx"
                If ($C.Type -match "File|Folder") { $HelpLines = "$HelpLines. (Alt+\ to browse)" }
                If ($C.ChoiceType -match "Action" -and !$ActionShown) {
                    Write-host " Actions:" -ForegroundColor White
                    $ActionShown = $true
                }
                If ($C.Type -match "Caption") {
                    Write-host " $HelpLines" -ForegroundColor White
                } Else {
                    Write-host "$Alt$($C.Key): $HelpLines"
                }
            }
        }
    }

    If (!$NoEnter)  { Write-Host " [Enter]: Confirm/save" }
    If (!$NoEscape) { Write-Host "   [Esc]: Cancel"  }           
    If ($Help) {
        Write-Host ""
        $HelpLines = $Help -replace "^ *","   " -split "`n`r?" -join "`n   " # Indent multiline extra help text with 3 spaces
        Write-Host $HelpLines
    }
    $host.UI.RawUI.CursorPosition = $OrgPos
}



# Works for Windows 7
# Return Excape, Enter, or name of choice? (and modifier), or only choice text, or only index... needed?
# This works for Windows 7 too...
# Return 'Enter', 'Escape' or the name of the choice.
# Arrows or number: Return number
# If default key is specified, return that on Enter
# Defaultindex -- remove...
Function Get-Choice {
    Param (
        [String]$Menu = "&Yes|Approve; &No|Deny", 
                    # I don't use $Menu in dialogs, $ChoiceList is better
                    # Use ; to separate menu items, and | to separate item from help info
        [String]$Title,
        [String]$Message,
        [Int]$DefaultIndex = -1,  # 0-based default choice index (0 - n-1). -1 means no default (ENTER does not choose anything.)
        [String]$DefaultKey = "",  # Default character to use instead of DefaultChoice. If not matching any key in Menu, this is ignored
        [String]$ExistingValue,    # Display existing value before prompting
        [Switch]$ActionsListformat,         # Default choices on one line, List to show a list of choices
        [Switch]$NoEscape,
        [Switch]$Numbers,
        [hashtable]$Numberdef,      # From dialog hash, define numbers to use (instead of -numbers/-max-min)
        [Int]$Number = 0,
        [ValidateRange(0,999)][Int]$MinNumber = 0,
        [ValidateRange(-1,999)][Int]$MaxNumber = 999,
        #[Switch]$ReturnIndex,      # Return choice index instead of character...
        [Switch]$ReturnKeyName,     # Return choice by key name (esc,enter,A,B,C etc (all keys uppercase))
        [String]$Help,              # Help message displayed in addition to the menu options help.
        [Switch]$NoEnter,           # In some forms, Enter is not useful
        [Switch]$ShowResult,        # Show choice name when a valid choice is pressed
        [Switch]$OnlyPrompt,        # Only show the menu and return
        [Switch]$NoPrompt,          # Don't show the menu, but get a keypress
        [hashtable[]]$ChoiceList    # Menudefs
        # Default is to return 'OK' on Enter and 'Escape' on escape
    )
    
    If ($Numberdef) {
        $Numbers   = $True
        $Number    = $Numberdef.Number
        If ($Numberdef.MaxNumber -ge -1 -and $Numberdef.MaxNumber -le 999) {$MaxNumber = $Numberdef.MaxNumber}
        If ($Numberdef.MinNumber -ge  0 -and $Numberdef.MinNumber -le 999) {$MinNumber = $Numberdef.MinNumber}
    }
    
    If ($MaxNumber -lt $MinNumber) { $MaxNumber = $MinNumber }
    $MaxCNum = $MaxNumber; If ($MaxCNum -gt 9) { $MaxCNum = 9}
    $MinCNum = $MinNumber;# If ($MinCNum -gt 9) { $MinCNum = 9}
    
    $DefaultKey = $DefaultKey.ToUpper()
    $Choices = @()
    $ChoiceIndex = @{}
    $n = 0

    If ($ChoiceList) {
        $ChoiceList | ForEach-Object {
            $ChoiceProps = $_
            If ($ChoiceProps.Enable) {
                If (!$ChoiceProps.Text) {$ChoiceProps.Text = $ChoiceProps.Name}
                $ChoiceProps.NoPrompt = $_.ChoiceType -ne "Action"
                $ChoiceProps.Index = $n
                If ($_.Key -and $_.Key -ne "0") { $ChoiceIndex.Add([String]$_.Key, $ChoiceProps)}
                $Choices += $ChoiceProps
                $n ++
            }
        }
    } Else {
        $MenuItems = $Menu -Split " *; *"  # Menu items are separated with ;
        If ($MenuItems.count -lt 1) {
            Write-Warning "No menu items specified"
            Return ""
        }
        foreach ($This in $MenuItems) {
            If ($This -eq "") {continue}
            $ChoiceParts = $This.Split("|")
            $ChoiceProps = @{}

            If ($ChoiceParts[0][0] -eq "!") {
                $ChoiceProps.NoPrompt = $True
                $ChoiceParts[0] = $ChoiceParts[0] -Replace '^!',''
            }
            If ($ChoiceParts[0][0] -eq "?") {
                $ChoiceProps.Browse = $True
                $ChoiceParts[0] = $ChoiceParts[0] -Replace '^[?]',''
            }
        
            $ChoiceProps.Name = $ChoiceParts[0] -Replace '&',''
            $ChoiceProps.Info = $ChoiceParts[1]
            If (!$ChoiceProps.Text) {$ChoiceProps.Text = $ChoiceProps.Name}
        
            $ChoiceText = $ChoiceParts[0]        
            $Index = $ChoiceText.IndexOf("&")
            Do {
                $Shortcut = ($ChoiceText.ToUpper())[$Index + 1]
                $Index ++
            } Until ($ChoiceIndex.keys -notcontains $Shortcut -or $Index -ge $ChoiceText.length -1)

            If ($ChoiceIndex.keys -contains $Shortcut ) {
                write-Warning "Get-Choice script bug: A menu option already has this shortcut: $shortcut" 
                write-Warning "Choice: $ChoiceText"
                exit 1
            }
                
            If ($Shortcut) { $ChoiceProps.Key = $Shortcut}  # [Char]

            If ($DefaultKey -and $DefaultIndex -eq -1) {
                If ($ChoiceProps.Key -like $DefaultKey) {
                    $ChoiceProps.Default = $True
                    $DefaultIndex = $n
                }
            }
        
            If ($Numbers -and $Shortcut -eq "0") {
                $ChoiceProps.Key = "$MinNumber-$MaxNumber"
                If ($MaxNumber -eq 0) {$ChoiceProps.Key = "0"}
                $ChoiceProps.Name = $ChoiceProps.Name -replace '0 *', ''
            } 
        
            $ChoiceProps.Index = $n
        
            If ($shortcut -ne "0") {
                #$ChoiceIndex.Add([String]$Shortcut, $n)
                $ChoiceIndex.Add([String]$Shortcut, $ChoiceProps)
            }
        
            $Choices += $ChoiceProps
            $n ++
        }
    }

    If ($Choices.count -lt 1) {
        write-error "Get-Choice missing choices"
        Return -1
    }

    If (!$NoPrompt) { 
        If ($Title)         { Write-Host $Title -ForegroundColor White -BackgroundColor Black }
        If ($ExistingValue) { Write-host "Current value: $ExistingValue" }
        If ($Message)       { Write-Host $Message } 
    
        $Indent = ""; If ($ActionsListformat) {$Indent = "  "}
        Foreach ($C in $Choices) {
            If ($C.NoPrompt) { continue }
            If ($C.Default) {$FG = "yellow"} Else {$FG = "White"}

            $Item = "$Indent[$($C.Key)] $($C.Text)   "

            # Will this push us over the edge?
            If ($host.UI.RawUI.CursorPosition.X  + $Item.length -ge $host.UI.RawUI.WindowSize.Width) {
                # Erase rest of line and new line
                write-host "".PadRight($host.UI.RawUI.WindowSize.Width - $host.UI.RawUI.CursorPosition.X)

                

            }
            Write-host $Item -ForegroundColor $FG -BackgroundColor Black -NoNewLine:(!$ActionsListformat)
        }
        Write-host "$Indent[?] Help " -NoNewLine:(!$ActionsListformat)
        If ($DefaultIndex -ne -1) {
            Write-host "(default: `"$($DefaultKey)`") " -NoNewLine:(!$ActionsListformat)
        }
        Write-host ": " -ForegroundColor Gray -BackgroundColor Black -NoNewLine

        If ($Host.name -like "consolehost") {  # Don't do this in ISE (Debug)
            Clear-Right
        }
    }

    If ($OnlyPrompt) { Return }

    $InputCursor = $host.UI.RawUI.CursorPosition
    $HelpShown = $false

    $WindowSize = $host.ui.RawUI.WindowSize

    :GetChoiceLoop Do {
        Write-aDebug $InputCursor
        #$host.UI.RawUI.CursorPosition = $InputCursor
        SetPos $InputCursor

        $Result = ReadKey # [System.Console]::ReadKey(1) # ReadKey has built-in sleep

        If ($Result -eq $Null) {
            # Check window for resize
            If ($RefreshOnResize) {
                If ($WindowSize.Height -ne $host.ui.RawUI.WindowSize.Height -or 
                        $WindowSize.Width -ne $host.ui.RawUI.WindowSize.Width) {
                    # Console was resized
                    Return "F5"
                }
            }
            continue GetChoiceLoop
        }


        $Choice  = $result.keyChar.ToString().ToUpper()
        $KeyName = $result.key.ToString()
        $KeyChar = $result.keyChar  # [Char]

        $KeyData = @{
            Result = 'OK'
            Number = $Number
            KeyName = $result.key.ToString()
            KeyChar = $result.keyChar
            Modifiers = [String]$result.modifiers
        }

        If ($Debug) {
            Write-aDebug "KeyData: $($KeyData.KeyName), $($KeyData.Modifiers)"
            sleep 0.5
        }

        If ($ChoiceIndex.$Choice) {
            If ($ShowResult) { Write-Host $ChoiceIndex.$Choice.Name -ForegroundColor Cyan -BackgroundColor Yellow }
            If ($ReturnKeyName) {
                Return $KeyData.KeyName
            } ElseIf ($ReturnName) {
                Return $ChoiceIndex.$Choice.Name
            } Else {
                Return $KeyData
            }
        }

        IF ($KeyName -eq 'Tab') {
            If ($KeyData.Modifiers -eq 'Shift') {
                Return "_Last"
            } Else {
                Return "_First"
            }
        }


        If ($KeyName -like 'Enter' -and !$NoEnter) { #  -and $DefaultIndex -ne -1
            Return $KeyData.Result
        }
       
        If ($Numbers -and $MaxNumber -gt 0) { 
            If ($KeyChar -match "[$MinCNum-$MaxCNum]") {
                If ($ShowResult) { Write-Host $KeyChar -ForegroundColor Cyan }
                $KeyData.Number = [int][string]$KeyChar
                Return $KeyData.Number
            }
        }

        If ($Numbers -and ($KeyName -match 'UpArrow|DownArrow|Home|End|PageDown|PageUp')) {
            #Set-PSDebug -Step
            If ($KeyName -eq 'UpArrow') {
                If ($Number -gt $MinNumber) {
                    $Number -- 
                } ElseIf ($Numberdef.ListStart -gt 0) {
                    $KeyData.Result = 'Page'
                    $Numberdef.ListStart--
                    Return $KeyData.Result
                }
            }

            If ($KeyName -eq 'DownArrow') {
                If ($Number -lt $MaxNumber) { 
                    $Number ++ 
                } ElseIf (($Numberdef.ListStart + $MaxNumber + 1) -lt $Numberdef.ListCount) {
                    $KeyData.Result = 'Page'
                    $Numberdef.ListStart++
                    Return $KeyData.Result
                }
            }

            If ($KeyName -eq 'PageDown') {
                If ($Number -lt $MaxNumber) {
                    $Number = $MaxNumber
                } Else {
                    If (($Numberdef.ListStart + $MaxNumber + 1) -lt $Numberdef.ListCount) {
                        $Numberdef.ListStart += $MaxNumber
                        If ($Numberdef.ListStart + $MaxNumber -gt $Numberdef.ListCount) {
                            $Numberdef.ListStart = $Numberdef.ListCount - $MaxNumber - 1
                        }
                        #$Number = 0
                        $KeyData.Result = 'Page'
                        Return $KeyData.Result
                    }
                }
            }            

            If ($KeyName -eq 'PageUp') {
                If ($Number -gt $MinNumber) {
                    $Number = $MinNumber
                } Else {
                    If ($Numberdef.ListStart -gt 0) {
                        $Numberdef.ListStart -= $MaxNumber
                        If ($Numberdef.ListStart -lt 0) {$Numberdef.ListStart = 0}
                        #$Number = 0
                        $KeyData.Result = 'Page'
                        Return $KeyData.Result
                    }
                }
            }            

            If ($KeyName -eq 'Home') {
                #If ($Number -gt $MinNumber) {
                #    $Number = $MinNumber
                #} Else {
                    $Numberdef.Number = $MinNumber
                    $Numberdef.ListStart = 0
                    $KeyData.Result = 'Page'
                    Return $KeyData.Result
                #}
            }
            If ($KeyName -eq 'End')  {
                #If ($Number -lt $MaxNumber) {
                #    $Number = $MaxNumber
                #} Else {
                    $Numberdef.Number = $MaxNumber
                    $Numberdef.ListStart = $Numberdef.ListCount - $MaxNumber - 1
                    $KeyData.Result = 'Page'
                    Return $KeyData.Result
                #}
            }
            $KeyData.Number = [Int]$Number
            Return $KeyData.Number
        }       
        
        If ($KeyName -eq 'Escape' -and !$NoEscape) {
            $KeyData.Result = 'Cancel'
            Return $KeyData.Result
        }
        
        If (($KeyChar -eq "?" -or $KeyName -eq "F1" ) -and !$HelpShown) {
            Show-Help -Choices $Choices -HelpY $AskDialogInput.Y -Help $Help
            $HelpShown = $True
        }

        If ($KeyName -eq "F3") {
            Write-host "F3 at Get-Choice"
            Show-Anchors
            $Global:Debug = !$Global:Debug
        }

        If ($KeyName -eq "F4") {
            Return "F4"
        }

        If ($KeyName -eq "F5") {
            Return "F5"
        }


        If ($KeyName -eq "F6") {
            Set-DebugType 1
        }

        


    } Until ($false)
}



Function Write-aDebug  {
    Param (
        [String]$Text,
        [Int32]$Line = 0
    )
    If ($Global:Debug) {
        $oPos = $host.UI.RawUI.CursorPosition
        $DPos = $oPos
        $DPos.X = 40; $DPos.Y = 30 + $Line
        $host.UI.RawUI.CursorPosition = $DPos
        Write-Host "$Text                                           "
        $host.UI.RawUI.CursorPosition = $OPos
    }
}


Function Cursor {
    <#
        Cursor without parameters returns position.
        Cursor -x 99 -y 99 sets position
        SetPos [coord] sets position
    #>
    Param (
        [int]$x ,#=-1,
        [int]$y ,#=-1,
        [System.Management.Automation.Host.Coordinates]$SetPos
    )
    # [console]::setcursorposition($([console]::Cursorleft ),$([console]::CursorTop - 4))  
    
    If ($SetPos) {
        $host.UI.RawUI.CursorPosition = $SetPos
        Return $null
    }
    # If (($y -ge 0) -or ($x -ge 0)) {
    If ( ($y -ne $null) -or ($x -ne $null)) {
        $Pos = New-Object System.Management.Automation.Host.Coordinates
        $Pos.Y = $host.UI.RawUI.CursorPosition.Y
        $Pos.X = $host.UI.RawUI.CursorPosition.X
        If ($y -ge 0) { $Pos.Y = $y }
        If ($x -ge 0) { $Pos.X = $x }
        $host.UI.RawUI.CursorPosition = $Pos
        return $null
    } Else {
        $host.UI.RawUI.CursorPosition
    }
}

Function SetPos {
    Param (
        [System.Management.Automation.Host.Coordinates]$SetPos
    )
    If ($SetPos) {
        # Make sure we don't set position outside of buffer:
        If ($SetPos.X -ge $host.UI.RawUI.BufferSize.Width) {
            $SetPos.X = $host.UI.RawUI.BufferSize.Width - 1
        }
        $host.UI.RawUI.CursorPosition = $SetPos
    }
}

Function GetPos {
    $host.UI.RawUI.CursorPosition
}

<#
Function CursorY {
    #$P = $host.UI.RawUI.CursorPosition.Y
    #Return $P.Y
    $host.UI.RawUI.CursorPosition.Y
}
#>



<# 
 .DESCRIPTION 
 Clear-Rect
Copy of Clear-host in PS2.
Clear all or a part of the screen, with optional char and colors
Modified to do part of a window (rect)
New cursor pos is top left of the rect.

$space = New-Object System.Management.Automation.Host.BufferCell
$space.Character = ' '
$space.ForegroundColor = $host.ui.rawui.ForegroundColor
$space.BackgroundColor = $host.ui.rawui.BackgroundColor
$rect = New-Object System.Management.Automation.Host.Rectangle
$rect.Top = $rect.Bottom = $rect.Right = $rect.Left = -1
$origin = New-Object System.Management.Automation.Host.Coordinates
$Host.UI.RawUI.CursorPosition = $origin
$Host.UI.RawUI.SetBufferContents($rect, $space)

.PARAMETER Bottom
    -1 (Default) Clear to bottom of console
    -2 Clear end of line
#> 


# Default; whole buffer
# -EOL: clear to end of line in specified -top 
# -FromHere (from cursor position, combine with -EOL)
# -FromThisLine (From currors line pos)
# -char : Fill with specified char
Function Clear-Rect {
    Param (
        [int32]$Top = -1,
        [int32]$Bottom= -1,
        [int32]$Left= -1,
        [int32]$Right= -1,
        [Switch]$EOL,
        [Switch]$FromHere, # Clear from the current line. Combine with -EOL to only clear current line
        [Switch]$FromThisLine,
        [string]$Char = ' ',
        [System.consolecolor]$ForegroundColor = $host.ui.rawui.ForegroundColor,
        [System.consolecolor]$BackgroundColor = $host.ui.rawui.BackgroundColor
    )

    If ($ISEHost) {Return}

    # $height = (Get-Host).UI.RawUI.MaxWindowSize.Height
    # $width = (Get-Host).UI.RawUI.MaxWindowSize.Width

    If ($Top -eq -1 -and $FromThisLine) {
        $Top = $host.UI.RawUI.CursorPosition.Y
    }
    If ($Top -eq -1 -and $FromHere) {
        $Top  = $host.UI.RawUI.CursorPosition.Y
        $Left = $host.UI.RawUI.CursorPosition.X
    }

    If ($Top -ne -1) {
        If ($Bottom -eq -1) {
            #$Bottom = (Get-Host).UI.RawUI.MaxWindowSize.Height + 100
            $Bottom = $host.UI.RawUI.CursorPosition.Y + $host.UI.RawUI.MaxWindowSize.Height + 5
            If ($EOL) {$Bottom = $Top}
        }
        If ($Bottom -eq -2) {$Bottom = $Top}
        If ($Left   -eq -1) {$Left   = 0}
        If ($Right  -eq -1) {$Right  = $host.ui.rawui.windowsize.width}
    }
    If ($Left -gt $Right)  {$Left = $Right}
    If ($Top  -gt $Bottom) {$Top  = $Bottom}

    $space = New-Object System.Management.Automation.Host.BufferCell
    $space.Character = $Char
    $space.ForegroundColor = $ForegroundColor
    $space.BackgroundColor = $BackgroundColor
    $rect = New-Object System.Management.Automation.Host.Rectangle
    $rect.Top = $Top
    $rect.Bottom = $Bottom
    $rect.Left = $Left
    $rect.Right = $Right

    #$origin = New-Object System.Management.Automation.Host.Coordinates
    #If ($Top -ne -1) {$origin.Y = $Top; $origin.X = $Left} Else {$origin.Y = 0; $origin.X = 0}
    #$Host.UI.RawUI.CursorPosition = $origin
    try {
        $Host.UI.RawUI.SetBufferContents($rect, $space) }
    catch {
        write-host "Check left/right" -ForegroundColor White
        write-host "Rect: $rect"
        Set-PSDebug -Step
    }
    $host.ui.rawui.ForegroundColor = $ForegroundColor
    $host.ui.rawui.BackgroundColor = $BackgroundColor
}

Function Clear-Right {
    Param (
        [Switch]$NL,
        [string]$Char = ' '
    )
    If ($ISEHost) {Return}
    Clear-Rect -top $host.UI.RawUI.CursorPosition.Y -Left $host.UI.RawUI.CursorPosition.X -Bottom $host.UI.RawUI.CursorPosition.Y -Char $Char
    If ($NL) {
        $Pos = New-Object System.Management.Automation.Host.Coordinates
        $Pos.Y = $host.UI.RawUI.CursorPosition.Y + 1
        $Pos.X = 0
        $host.UI.RawUI.CursorPosition = $Pos
    }
}


# Global variable. Shorcut keys to debug on specific debug types.
$Script:Debug_Type = 0

Function Set-DebugType {
    Param (
        [Parameter(Mandatory=$true)]
        [Int]$Type
    )

    If ($Type -and $Script:Debug_Type -ne $Type) {
        $Script:Debug_Type = $Type
        Write-host "Debug type: $Type"; Start-Sleep -Milliseconds 200
    } Else {
        $Script:Debug_Type = $null
        Write-host "Debug off      "; Start-Sleep -Milliseconds 200
    }
}

# Put this where I want to stop
Function DebugType {
    Param (
        [Parameter(Mandatory=$true)]
        [Int]$Type,
        [String]$Text
    )
    If ($Debug_Type -eq $Type) {
        If ($Text) {Write-host $Text}
        Set-PSDebug -Step
    }
}


Function Edit-ConsoleField {
    Param (
        [Object]$Default,       # Default value. It's data type will decide how to display it
        [String]$Type,          # Field type, (blank=string)|int32|Boolean|File|Folder (goes beyond data type)
        [Int32]$Length = 60,    # Length of input field
        [Int32]$X = -1,         # X coordinate of the input field. Default is current (pos)
        [Int32]$Y = -1,         # Y coordinate of the input field. Default is current
        [Char]$PadChar = ' ',   # Character filling empty part of field
        [Int32]$ScrollX = 0,    # ScrollX is how much the string is shifted to the left, to see the end of the string
        [System.consolecolor]$ForegroundColor = $host.ui.rawui.ForegroundColor,
        [System.consolecolor]$BackgroundColor = $host.ui.rawui.BackgroundColor,
        [hashtable]$Config,     # Parameters for file and folder browse dialogs, boolean states, validatescripts. Perhaps more later.
        [Switch]$Print,         # Print data and then return. (Used by dialog to Display field data before input)
        [hashtable[]]$ChoiceList  # A list of choices with key, text, info etc. (alt+)shortcuts to other fields/actions
 
 #      [hashtable]$MenuIndex   # An index of menu choices/types
 #      [Switch]$Debug,
 #      [Int32]$ViewStart = 0, # Initial cursor position. Relative to input string
    )

    $Shortcutskeys = ($ChoiceList|Where-Object {$_.enable}).key # $Shortcuts.key
    If ($Shortcutskeys) {
        If (!$MenuIndex) {
            $MenuIndex = @{}
            $ChoiceList|Where-Object {$_.enable}|ForEach-Object {
                $MenuIndex.Add([String]$_.Key, $_)
            }
        }
    }

    $FieldValue = ""
    
    If (!$Type) { 
        If ($Default) { $Type = $Default.GetType().Name }
    }  
    If (!$Config) {
        $Config = Switch ($Type) {
            "File"  {@{
                Title = "Select File"
                #Filter = "Exe files (*.exe)|*.exe|All files (*.*)|*.*"
            }}
            
            "Folder" {@{
                # ShowNewFolderButton = $true
                Title = "Select a folder"
            }}
            Default {@{}}
        }
    }
    $Config.ShowedHint = $False

    If (!$Config.Hint) {
        $Config.Hint = Switch -regex ($Type) {
            "boolean" {"[Space] to toggle"}
            "int[0-9]*" {"Arrow up/down"}
            "File|Folder" {"Alt+\ to browse"}
        }
    }

    If ($Type -match "int") {
        If ($Config.Keys -notcontains 'Max')  {$Config.Max = $Default::MaxValue}
        If ($Config.Keys -notcontains 'Min')  {$Config.Min = $Default::MinValue}
        If ($Config.Keys -notcontains 'Step') {$Config.Step = 1}
        #Write-Host "Max: $($Config.Max) " -NoNewline
        #Write-Host "Min: $($Config.Min) " -NoNewline
        #Write-Host "Step: $($Config.Step) " -NoNewline
        #read-host

    }
    
    If (!$Config.States) {
        $Config.States = @{
             $True = "On"
             $False = "Off"
             #$True = "[X]"
             #$False = "[ ]"
        }
    }
  
    Function Write-Buffer {
        Param (
            [Object]$Buffer,
            [System.consolecolor]$FGC = $ForegroundColor,
            [System.consolecolor]$BGC = $BackgroundColor
        )
        
        Switch -regex ($Type) {
            'Boolean' { 
                $Display = $Config.States.[Boolean]$Buffer
            }
            # 'Int[0-9]*'   { $Display = $Buffer }
                #If ([int32]$Buffer -ge -0) {
                #    #$Display = " $Buffer"
                #} Else {$Display = $Buffer}
            
            Default { $Display = $Buffer }
        }
        
        $host.UI.RawUI.CursorPosition = $Org
        Write-host ("$Display ".Substring($ScrollX,[Math]::Min($Length, $Display.Length))).padright($Length, $PadChar) -NoNewLine -ForegroundColor $FGC -BackgroundColor $BGC

        #Write-host " SH: $($Config.ShowedHint) " -NoNewline -ForegroundColor Cyan
        
        If ($Print) {Clear-Right}
        If (!$Print -and !($Config.ShowedHint)) {
            Write-host " $($Config.Hint)" -NoNewline -ForegroundColor Yellow
            Clear-Right
            $Config.ShowedHint = $true
        } 

        If (!$Print) { $host.UI.RawUI.CursorPosition = $Pos }
    }

    Function Blink {
        Param (
            [Object]$String
        )
        foreach ($F in $BlinkColorSequence) {
            Write-Buffer $String -FGC $F -BGC $BlinkColorBackground 
            sleep -Milliseconds 300
        }

        If ($FieldValue) {
            Write-Buffer "$FieldValue"
        } Else {
            Write-Buffer ""
        }
    }

    $FieldValue = Switch ($type) {
        "boolean" {[Boolean]$Default}
        Default   {[String]$Default}
    }
    #   "int32"   {[int32]$Default}
    
    $Pos = New-Object System.Management.Automation.Host.Coordinates    
    If ($X -ge 0) {$Pos.X = $X} Else {$Pos.X = $host.UI.RawUI.CursorPosition.X}
    If ($Y -ge 0) {$Pos.Y = $Y} Else {$Pos.Y = $host.UI.RawUI.CursorPosition.Y}

    $Org = $Pos
    $PosDebug = $Pos; $PosDebug.X = 0; $PosDebug.Y = $PosDebug.Y + 10
 
    Write-Buffer $FieldValue
    If ($Print) {Return}  #########################
    
    If ($Host.name -notlike "consolehost") {
        $Ask = Read-Host -Prompt "Enter string. '-' to simulate Escape"
        If ($Ask -eq '-') {
            Return @{Data=$Ask; Result='Cancel'}
        } Else {
            Return @{Data=$Ask; Result='OK'}
            # Return @{Data=$Ask; Result='Cancel'}
        }
    }

    #$host.UI.RawUI.CursorPosition = $Pos
    #$Result = [System.Console]::ReadKey(1)

    While ($true) {
        $Result = [System.Console]::ReadKey(1)
    
        $KeyName = [String]$result.key
        $KeyChar = [String]$result.keyChar
        $Modifier =[String]$result.Modifiers
        If ($Debug) {
            $host.UI.RawUI.CursorPosition = $Posdebug
            Write-host "Pos (Before move):$pos  " -NoNewline
            Write-host "Keyname:$Keyname, char:$Keychar, Mod:$Modifier. " -NoNewline
            Write-host "ScrollX $ScrollX                        "
            $host.UI.RawUI.CursorPosition = $Pos
        }        

        If ($KeyName -like "Escape") {
            Return @{Data=$FieldValue; Result='Cancel'} 
        }

        If (($KeyName -match "Tab|Enter") -or ($Shortcutskeys -contains $KeyName -and $Modifier -eq "Alt")) {

            # DebugType 1 "Validate?"
            

            # Executing an action does not need validation
            If ($KeyName -match "Tab|Enter" -or $MenuIndex.$KeyName.ChoiceType -notlike "Action") {
                # (Tab/enter)
                #Write-Host "Edit-console Validate " -NoNewline ; sleep 0.2 ; Set-PSDebug -Step

                DebugType 1 "Validate?"
                $ValidateResult = ValidateField -Config $Config -FieldValue $FieldValue
                If ($ValidateResult.FieldValue) {
                    $FieldValue = $ValidateResult.FieldValue
                    $ValidateResult = $ValidateResult.ValidateResult
                }

                If ($ValidateResult) {
                    # Write-Host $ValidateResult.ValidateResult -ForegroundColor Green

                    continue
                }

                #If ($ValidateResult) { continue }

                <#If ($Config.Validate -like 'Exist') {
                    If (!$FieldValue) {
                        Blink "Path required!"
                        continue
                    } Else {
                        If ($FieldValue -and !(Test-Path -isvalid -Path $FieldValue)) { 
                            Blink "Invalid format!"
                            continue
                        }
                        If ($FieldValue -and !(Test-Path -Path $FieldValue)) {
                            Blink "Does not exist!"
                            continue
                        }
                    }
                }#>
                # If Validatescript returns an error text, display it and continue (i.e. return)
                <#If ($Config.ValidateScript) {
                    If ($ValidateResult = Invoke-Command $Config.ValidateScript -NoNewScope) {
                        Blink $ValidateResult
                        continue
                    }
                }#>

            }
                
            $Action = 'OK'
                
            If ($KeyName -eq "Tab" -and $Modifier -ne "Shift") { $Action  = 'Next'}
            If ($KeyName -eq "Tab" -and $Modifier -eq "Shift") { $Action  = 'Prev'}

            If ($Modifier -eq "Alt" -and $Shortcutskeys -contains $KeyName) {
                Return @{Data=$FieldValue; Result='Shortcut'; Key=$KeyName }
            }
            Return @{Data=$FieldValue; Result=$Action }
        }

        If ($Modifier -eq "Alt" -and $KeyChar -eq "\") {
            # Shortcut depending on type
            Switch ($Type) {
                "File" {
                    # Separate path and filename from $FieldValue if possible
                    Try {
                        $Path     = Split-Path $FieldValue -Parent
                        $Filename = Split-Path $FieldValue -Leaf
                    }
                    Catch {
                        $Path     = ""
                        $Filename = ""
                    }
                    $NewTarget = OpenFileDialog -Title $Config.Title -Description $Config.Description -InitialDirectory $Path -FileName $FileName -Filter $Config.Filter
                    If ($NewTarget) { 
                        $FieldValue = $NewTarget
                        Write-Buffer $FieldValue
                        Continue
                    }
                }
                
                "Folder" {
                    $NewTarget = Browse-FolderName -Description $Config.Title -SelectedPath $FieldValue -ShowNewFolderButton:($Config.ShowNewFolderButton)
                    If ($NewTarget) { 
                        $FieldValue = $NewTarget
                        Write-Buffer $FieldValue
                        Continue
                    }
                }
            }
            # Continue # Dont add the "b" to the data!
#$Result = [System.Console]::ReadKey(1)
            Continue
        }

        # Help from read-console with AskDialogInput from get-choice
        If (($KeyChar -eq "?" -or $KeyName -eq "F1" ) -and !$HelpShown) {
            
            #write-host "AskDialogInput: $($AskDialogInput.Y)"
            #Set-PSDebug -Step

            Show-Help -Choices $Choices -HelpY $AskDialogInput.Y 
            $HelpShown = $True
            Continue
        }
        
        If ($type -like "*int*" -and ($KeyName -match "UpArrow|DownArrow|Minus|Plus")) {
            Switch -regex ($KeyName) {
                "UpArrow"   { # increase number
                    If ([int32]$FieldValue -lt $Config.Max -or !$Config.Max) {
                        $FieldValue = [string](([int32]$FieldValue) + $Config.Step)
                    }
                }
                "DownArrow" { # decrease number
                    If (([int32]$FieldValue -gt $Config.Min)) { #  -or !$Config.Min
                        $FieldValue = [string](([int32]$FieldValue) - $Config.Step)
                    }
                }
                "Minus" {  # switch between nega/positive
                    $FieldValue = [string](0 - ([int32]$FieldValue))
                }
                "Plus" {   # force positive
                    If ([int32]$FieldValue -lt 0) {
                        $FieldValue = [string](0 - ([int32]$FieldValue))
                    }
                }
            }
#            $FieldValue 
            Write-Buffer $FieldValue
#$Result = [System.Console]::ReadKey(1)
            continue  # Finnish this Switch (don't process the default)
        }



        Switch ($Type) {
            "Boolean" {
                Switch -regex ($KeyName) {
                    "Spacebar|LeftArrow|RightArrow" {
                        $FieldValue = !$FieldValue
                        Write-Buffer $FieldValue
                    }
                }
                continue  # Finnish this Switch (don't process the default)
            }

            
            Default {
                Switch ($KeyName) {
                    "LeftArrow" {
                        $Pos.X = [Math]::Max($Pos.X - 1, $Org.X)
                        $host.UI.RawUI.CursorPosition = $Pos
                        If (($Pos.X -le $Org.X) -and ($ScrollX -gt 0)) {
                            $ScrollX --
                            Write-Buffer $FieldValue
                        }
                        break;
                    }
                    "RightArrow" {
                        $MaxLength = [Math]::Min($Length - 1, $FieldValue.Length)    # Max is field length or string lenght (if less)
                        $Pos.X = [Math]::Min($Pos.X + 1, $Org.X + $MaxLength)
                        $host.UI.RawUI.CursorPosition = $Pos
                        If ($Pos.X -ge ($Org.X + $Length - 1)) {               # If at end we might have to scroll
                            If ($ScrollX -le ($FieldValue.Length - $Length)) {
                                $ScrollX ++
                                Write-Buffer $FieldValue
                            }
                        }
                        break;
                    }
                    "Home" {
                        $Pos.X = $Org.X; $host.UI.RawUI.CursorPosition = $Pos
                        $ScrollX = 0
                        Write-Buffer $FieldValue
                        break
                    }
                    "End" {
                        $MaxLength = [Math]::Min($Length - 1, $FieldValue.Length)
                        $Pos.X = $Org.X + $MaxLength
                        $host.UI.RawUI.CursorPosition = $Pos
                        IF ($FieldValue.Length -gt $Length) {
                            $ScrollX = $FieldValue.Length - $Length + 1
                        } Else { $ScrollX = 0 }
                        Write-Buffer $FieldValue
                        break;
                    }
                    "Backspace" {
                        If ($host.UI.RawUI.CursorPosition.X -le $Org.X) { Break }
                        $NewPos = [Math]::Max($host.UI.RawUI.CursorPosition.X - 1, $org.X)
                        If ($ScrollX -gt 0) { # If string was scrolled, roll it back instead
                            $ScrollX -- 
                            $NewPos ++
                        }
                        $FieldValue = $FieldValue.Remove($ScrollX + $NewPos - $Org.X, 1)
                        $Pos.X = $NewPos
                        Write-Buffer $FieldValue
                    }
                    "Delete" {
                        If ($host.UI.RawUI.CursorPosition.X -ge $Org.X + [Math]::Min($Length,$FieldValue.Length)) { Break }               
                        $FieldValue = $FieldValue.Remove( $ScrollX + $Pos.X - $Org.X, 1)
                        If ($ScrollX -gt 0) {$ScrollX --}
                        Write-Buffer $FieldValue
                    }

                    Default {
                        If ($Modifier -eq "control") {break} # Ignore unknown shortcuts
                        # Alt|
                        If ([int][char]$KeyChar -lt 32) {break}     # Don't insert unprintable characters
                        If ($Type -match "Int") {
                            If ($KeyChar -notmatch "[0-9]") {break}     # if data is int, only accept digits 
                        }
                        
                        $FieldValue = $FieldValue.Insert($Pos.X - $Org.X + $ScrollX, $KeyChar)
                        # Either move cursor or scroll text (so we see the part we edit)
                        If ($Pos.X -ge ($Org.X + $Length - 1)) {
                            $ScrollX ++
                        } Else {
                            $Pos.X ++
                        }
                        Write-Buffer $FieldValue
                    }
                }
            }
        }

        If ($KeyName -eq "F3") {
            Write-host "F3 in Edit-ConsoleField"
            Show-Anchors
        }



#$Result = [System.Console]::ReadKey(1)
    }    
}


# Run duplicacy commands
# Run process. Show ouput in console
# If Log is specified, a start-transcript is produced
# If -AsProcess, the process is started with stdout and stderr redirected. 
# (Produces late output with Duplicacy due to a GoLang issue)
Function StartCommand {
    Param (
        [String]$FilePath,
        [String]$WorkingDirectory,
        [String[]]$ArgumentList,
        [String]$Log,
        [String]$ListLog,
        [Switch]$AsProcess,
        [Switch]$noclr
    )

    # Set-PSDebug -Step
    # $Log = "$WorkingDirectory\Test.log"
    If (!$noclr) {
        #Clear-Rect -EOL -Char '_' # -Top ($AskDialogInput.Y + 1) 
        Write-host ""
        Clear-Rect -FromThisLine  -ForegroundColor White 
        # Clear-Rect -Top ($AskDialogInput.Y + 2) -EOL
    }

    If (!$Log) {
        # Calculate a standard log file
        $Setfolder = Split-Path -Parent -Path $WorkingDirectory
        $Leaf = Split-Path -Leaf -Path $WorkingDirectory
        $LogFolder = "$Setfolder\.DucyBackup\Logs\$Leaf"
        
        If (!(Test-Path $LogFolder)) { New-Item -Path $LogFolder -Force }

        foreach ($ArgLString in $ArgumentList) {
            If ($ArgLString[0] -ne '-') {
                $LogType = $ArgLString
                break
            }
        }

        $LogFileName =  "$(get-date -Format "yyyy-MM-dd-HHmm")_$LogType.log"
        $Log = "$LogFolder\$LogFileName"
    } ElseIf ($Log -eq '-') {
        $Log = $null
    } 
    
    If ($AsProcess) {
        $Result = Invoke-Executable -sExeFile $FilePath -WorkingDirectory $WorkingDirectory -cArgs $ArgumentList
        $host.ui.rawui.ForegroundColor = [System.consolecolor]"White"
        Return $Result
    } Else {
        If ($Log) { Start-Transcript -Path $Log } #| Out-Null

        Set-Location $WorkingDirectory
        write-host "Executing '$FilePath' $($ArgumentList -join " ")"

        #Set-PSDebug -Step

        # & $FilePath ($ArgumentList -join " ")
        & $FilePath $ArgumentList
        #Invoke-Command $FilePath $ArgumentList

        If ($LASTEXITCODE -ne 0) {
            Write-Host "`nCommand exited with status code $LASTEXITCODE" -ForegroundColor Red
        } Else {
            Write-Host "`n(Done)"
        }

        If ($Log) {Stop-Transcript | Out-Null}

        If ($Log -and $ListLog) {
            $ListLogFolder = Split-Path $LogFolder -Parent
            If (!(Test-Path $ListLogFolder)) { New-Item -Path $ListLogFolder -Force }
            Get-Content $Log | Set-Content $ListLog
        }


        $host.ui.rawui.ForegroundColor = [System.consolecolor]"Gray"
    }
}




# Inspired by 
# https://stackoverflow.com/questions/24370814/how-to-capture-process-output-asynchronously-in-powershell
function Invoke-Executable {
    # Runs the specified executable and captures its exit code, stdout and stderr.
    # Returns: custom object.
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [String]$sExeFile,
        [Parameter(Mandatory=$false)]
        [String[]]$cArgs,
        [Parameter(Mandatory=$false)]
        [String]$sVerb,
        [String]$WorkingDirectory
    )

    # Setting process invocation parameters.
    $oPsi = New-Object -TypeName System.Diagnostics.ProcessStartInfo
    #$oPsi.CreateNoWindow = $true
    $oPsi.UseShellExecute = $false
    $oPsi.RedirectStandardOutput = $true
    $oPsi.RedirectStandardError = $true
    $oPsi.FileName = $sExeFile
    $oPsi.WorkingDirectory = $WorkingDirectory


    if (! [String]::IsNullOrEmpty($cArgs)) {
        $oPsi.Arguments = $cArgs
    }
    if (! [String]::IsNullOrEmpty($sVerb)) {
        $oPsi.Verb = $sVerb
    }

    # Creating process object.
    $oProcess = New-Object -TypeName System.Diagnostics.Process
    $oProcess.StartInfo = $oPsi

    # Creating string builders to store stdout and stderr.
    $oStdOutBuilder = New-Object -TypeName System.Text.StringBuilder
    $oStdErrBuilder = New-Object -TypeName System.Text.StringBuilder

    # Adding event handers for stdout and stderr.
    # Stored in return so you can log to a file after
    # What if large log...
    $sScripBlock = {
        if (! [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
                write-host "> $($EventArgs.Data)" -ForegroundColor Green

        }
    }
    $sScripBlockErr = {
        if (! [String]::IsNullOrEmpty($EventArgs.Data)) {
            $Event.MessageData.AppendLine($EventArgs.Data)
                write-host "(!) $($EventArgs.Data)" -ForegroundColor Red
        }
    }
    $oStdOutEvent = Register-ObjectEvent -InputObject $oProcess `
        -Action $sScripBlock -EventName 'OutputDataReceived' `
        -MessageData $oStdOutBuilder
    $oStdErrEvent = Register-ObjectEvent -InputObject $oProcess `
        -Action $sScripBlockErr -EventName 'ErrorDataReceived' `
        -MessageData $oStdErrBuilder

    # Starting process.
    [Void]$oProcess.Start()
    $oProcess.BeginOutputReadLine()
    $oProcess.BeginErrorReadLine()


    [Void]$oProcess.WaitForExit()

    # Unregistering events to retrieve process output.
    Unregister-Event -SourceIdentifier $oStdOutEvent.Name
    Unregister-Event -SourceIdentifier $oStdErrEvent.Name

    $oResult = New-Object -TypeName PSObject -Property ([Ordered]@{
        "ExeFile"  = $sExeFile;
        "Args"     = $cArgs -join " ";
        "ExitCode" = $oProcess.ExitCode;
        "StdOut"   = $oStdOutBuilder.ToString().Trim();
        "StdErr"   = $oStdErrBuilder.ToString().Trim()
    })

    return $oResult
}



#            "W" {
#                #Show info on backends:
#                Start-Process -FilePath "https://forum.duplicacy.com/t/supported-storage-backends"
#            }



####################################
####################################


Function Show-Title {
    Param (
        [Switch]$splash
    )
    If ($Host.name -like "consolehost") { 
        $host.ui.rawui.ForegroundColor = $color.Text.f
        $host.ui.rawui.BackgroundColor = $color.Text.b
        [System.Console]::Clear()
        cls
    }
    $Host.UI.RawUI.WindowTitle = $Title

    $Top = $host.UI.RawUI.CursorPosition
    $Script:MainTop = $host.UI.RawUI.CursorPosition
    $IconPos = $host.UI.RawUI.CursorPosition

    If ($splash) {
        #$host.UI.RawUI.CursorPosition = $IconPos
        #Write-Host $icon -ForegroundColor DarkGreen
        #cls
    }

    $host.UI.RawUI.CursorPosition = $IconPos
    Write-Host $SmallIcon -ForegroundColor DarkGreen
    
    $host.UI.RawUI.CursorPosition = $Script:MainTop

    # Write-Host "      $Title $TitleMore" -ForegroundColor Yellow
    Write-Centre $TitleLong  # -ForegroundColor Yellow
    Write-Host ""
    # If ($NotAdmin) { Write-Host "Note: Not running elevated. (Creating symlinks will require elevation)" -ForegroundColor Red }
}

Function Write-Centre {
    Param (
        [String]$Text
    )
    $w = $Host.UI.RawUI.WindowSize.Width
    $x = ($w - $Text.Length) / 2
    $y = $Host.UI.RawUI.CursorPosition.Y
    $Host.UI.RawUI.CursorPosition = New-Object System.Management.Automation.Host.Coordinates $x , $y
    Write-Host $Text -ForegroundColor $Color.Title.f  # Yellow
} 



#https://www.jonathanmedd.net/2014/01/testing-for-admin-privileges-in-powershell.html
function Test-IsAdmin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

#https://stackoverflow.com/questions/5648931/test-if-registry-value-exists
# This function just gets $true or $false
function Test-RegistryValue($path, $name) {
    $key = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    $key -and $null -ne $key.GetValue($name, $null)
}

Function Test-RegistryKey($path) {
    Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
}

# Gets the specified registry value or $null if it is missing
function Get-RegistryValue($path, $name) {
    $key = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if ($key) {
        $key.GetValue($name, $null)
    }
}


# Load registry values into a hash table
# Translate "True" and "False"
Function Get-RegistrySettings ($Path) {
    $Values = @{}

    If (!(Test-RegistryKey $Path)) {
        write-debug "No settings found. Normal if first run"
    } Else {
       Get-Item $Path | Select-Object -ExpandProperty Property | ForEach-Object {
            $Value = (Get-ItemProperty -Path $Path -Name $_).$_
            If ($Value -eq "False") { $Value = $False }
            If ($Value -eq "True" ) { $Value = $True  }
            $Values.Add($_, $Value)
       }
    }
    $Values
}

#$value = Get-ItemProperty -Path HKCU:\Environment -Name Path
#$newpath = $value.Path += ";C:\src\bin\"
#Set-ItemProperty -Path HKCU:\Environment -Name Path -Value $newpath

Function Get_ConsoleSettings {
    $RegConsole = "Registry::HKCU\Console"
    @{
        'ForceV2' = Get-RegistryValue $RegConsole 'ForceV2'
        'LineWrap' = Get-RegistryValue $RegConsole 'LineWrap'
    }
}



# Sets the specified registry value to data
function Set-RegistryValue($path, $name, $value) {
    If (!(Test-Path $path)) {
        New-Item -Path $path -Force
    }
    $key = Get-Item -Path $path -ErrorAction SilentlyContinue
    if ($key) {
        New-ItemProperty -Path $Path -Name $name -Value $value -Force | Out-Null
    }
}



function Test-ReparsePoint([string]$path) {
  $file = Get-Item $path -Force -ea SilentlyContinue
  return [bool]($file.Attributes -band [IO.FileAttributes]::ReparsePoint)
}




Function Browse-FolderNamexxx {   
    Param (
        [String]$Description,
        [String]$SelectedPath = "C:\",
        [String]$RootFolder = 'MyComputer',
        [Switch]$ShowNewFolderButton = $false
    )
    Add-type -AssemblyName  System.Windows.Forms
    $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog
    $FolderBrowser.Description = $Description
    If ($RootFolder) { $FolderBrowser.RootFolder = $RootFolder }
    $FolderBrowser.SelectedPath = $SelectedPath
    $FolderBrowser.ShowNewFolderButton = $ShowNewFolderButton
    $out = $null;

    #$Topmost = New-Object System.Windows.Forms.Form
    #$Topmost.TopMost = $True
    #$Topmost.MinimizeBox = $True

    # https://stackoverflow.com/questions/54037292/folderbrowserdialog-bring-to-front
    $caller = [System.Windows.Forms.NativeWindow]::new()
    $caller.AssignHandle([System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle)

    #If ($FolderBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{TopMost = $true })) -like "OK") {
    If ($FolderBrowser.ShowDialog($caller) -like "OK") {
        $out = $FolderBrowser.SelectedPath;
    }

    #Cleanup Disposabe Objects
    Get-Variable -ErrorAction SilentlyContinue -Scope 0  | Where-Object {($_.Value -is [System.IDisposable]) -and ($_.Name -notmatch "PS\s*")} | ForEach-Object {$_.Value.Dispose(); $_ | Clear-Variable -ErrorAction SilentlyContinue -PassThru | Remove-Variable -ErrorAction SilentlyContinue -Force;}

    return $out;
}


function Browse-FolderNameyyy2 {       
    Param (
        [String]$Description,
        [String]$SelectedPath = "C:\",
        [String]$RootFolder = 'MyComputer',
        [Switch]$ShowNewFolderButton = $false,
        [string]$Title = "Browse"
        #[Parameter(Mandatory=0)][string]$DefaultPath = $(Split-Path $psISE.CurrentFile.FullPath),
        #[Parameter(Mandatory=0)][switch]$ShowNewFolderButton
        )
    Add-type -AssemblyName  System.Windows.Forms
    #$DefaultPath = UNCPath2Mapped -path $DefaultPath; 
    $FolderBrowser = new-object System.Windows.Forms.folderbrowserdialog;
    $FolderBrowser.Description = $Title;
    $FolderBrowser.ShowNewFolderButton = $ShowNewFolderButton;
    #$FolderBrowser.SelectedPath = $DefaultPath;
    $out = $null;

    $caller = [System.Windows.Forms.NativeWindow]::new()
    $caller.AssignHandle([System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle)

    if (($FolderBrowser.ShowDialog($caller)) -eq [System.Windows.Forms.DialogResult]::OK.value__) {
        $out = $FolderBrowser.SelectedPath;
    }

    #Cleanup Disposabe Objects
    Get-Variable -ErrorAction SilentlyContinue -Scope 0  | Where-Object {($_.Value -is [System.IDisposable]) -and ($_.Name -notmatch "PS\s*")} | ForEach-Object {$_.Value.Dispose(); $_ | Clear-Variable -ErrorAction SilentlyContinue -PassThru | Remove-Variable -ErrorAction SilentlyContinue -Force;}

    return $out;
}


# Theo, in 
#   https://stackoverflow.com/questions/54037292/folderbrowserdialog-bring-to-front
# I added Edit box, and optionaly allow Files
# Show an Open Folder Dialog and return the directory selected by the user.
# .... Get-FolderName
#        [String]$Description,
#        [String]$SelectedPath = "C:\",
#        [String]$RootFolder = 'MyComputer',
#        [Switch]$ShowNewFolderButton = $false
# Show an Open Folder Dialog and return the directory selected by the user.
function Browse-FolderName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$false, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true, Position=0)]
        [string]$Description = "Select a directory.", # Message
        [String]$SelectedPath, # Not used in this function
        [string]$RootFolder = [System.Environment+SpecialFolder]::MyComputer,  # InitialDirectory
        [switch]$ShowNewFolderButton,
        [switch]$ShowFiles
    )

    # BIF_RETURNONLYFSDIRS (0x00000001)
    # BIF_NEWDIALOGSTYLE   (0x00000040)
    # BIF_EDITBOX          (0x00000010)

    $browserForFolderOptions = 0x00000041   # BIF_RETURNONLYFSDIRS -bor BIF_NEWDIALOGSTYLE
    $browserForFolderOptions += 0x00000010  # BIF_NEWDIALOGSTYLE (Edit box, allows typing path)
    If ($ShowFiles)            { $browserForFolderOptions += 0x00004000 }  # BIF_BROWSEINCLUDEFILES
    If (!$ShowNewFolderButton) { $browserForFolderOptions += 0x00000200 }  # BIF_NONEWFOLDERBUTTON
    $browser = New-Object -ComObject Shell.Application

    # To make the dialog topmost, you need to supply the Window handle of the current process
    [intPtr]$handle = [System.Diagnostics.Process]::GetCurrentProcess().MainWindowHandle

    # see: https://msdn.microsoft.com/en-us/library/windows/desktop/bb773205(v=vs.85).aspx
    $folder = $browser.BrowseForFolder($handle, $Description, $browserForFolderOptions, $RootFolder)

    $result = $null
    if ($folder) { 
        $result = $folder.Self.Path 
    } 

    # Release and remove the used Com object from memory
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($browser) | Out-Null
    [System.GC]::Collect()
    [System.GC]::WaitForPendingFinalizers()

    return $result
}








Function SaveFileDialog {
    Param (
        [String]$FileName,
        [String]$Title,
        [String]$Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
        [String]$InitialDirectory
    )

    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.SaveFileDialog -Property @{
        Filename = $FileName
    	Filter = $Filter
        Title = $Title
        InitialDirectory = $InitialDirectory
        CheckPathExists = $true
    }    
    $result = $dialog.ShowDialog()
    if($result -eq 'OK') { 
        Return $dialog.FileName
    }
}

Function OpenFileDialog {
    Param (
        [String]$FileName,
        [String]$Title,
        [String]$Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
        [String]$InitialDirectory
    )

    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.OpenFileDialog -Property @{
        Filename = $FileName
    	Filter = $Filter
        Title = $Title
        InitialDirectory = $InitialDirectory
        CheckPathExists = $true
    }
    $result = $dialog.ShowDialog()
    if($result -eq 'OK') { 
        Return $dialog.FileName
    }
}


# Get the list of repositories.
# Useful info for users...
# Name. Repository. Scheduled. Backup Size (if available after check)
Function Get-RepositoryList {
    Param ( 
        [String]$SettingsPath,
        [switch]$Showlines
    )

    #$host.ui.rawui.ForegroundColor = $color.List.f
    #$host.ui.rawui.BackgroundColor = $color.List.b
    
    $Header = "   {0,-20} {1,-20} {2,-30} {3,-3} {4,-3}"
    
    If ($Showlines) {Write-Host ($Header -F "Name", "ID", "Backup Folder", "Strg", "Filter")}

    Get-ChildItem $SettingsPath | ForEach-Object {
        If ($_.Attributes -match 'Directory' ) {
            If ($_.Name -match ".DucyBackup") { Return }

            $BackupSet = @{}

            $RepoFilter = ""
            If (Test-Path "$($_.fullname)\.Duplicacy\filters") {
                #Write-host "`nFilter: (partial)"
                #get-content "$RepoPath\.Duplicacy\filters" -TotalCount 5
                $RepoFilter = "Yes"
            }
            
            #$x = Read-Preferences $_.FullName
            $y = Get_Storage $_.FullName
            $RepoVariation = $false
            $IDVariation = $false
            $Lastrep = ""
            $RepoID  = ""
            If ($y) {
                If ($y.gettype().basetype.name -eq "Array") {
                    $Storages = $y.count
                    $Lastrep = $y[0].repository
                    $Lastid = $y[0].id
                    $RepoPath = ""
                    $RepoVariation = $false
                    $IDVariation   = $false
                    ForEach ($Item in $y) {
                        If ($Lastrep) {$RepoPath = $Lastrep}
                        If ($Lastrep -ne $Item.repository) {$RepoVariation = $true}
                        If ($Lastid  -ne $Item.id)         {$IDVariation   = $true}
                    }

                    If ($RepoVariation) {$Lastrep = "$Lastrep?" }
                    If ($IDVariation)   {$RepoId = "$Lastid?" }
                    If (!$RepoPath)     {$RepoPath = "<$($_.Name)>" }

                    $Line = $Header -F $_.Name, $Lastid, $RepoPath, $Storages, $RepoFilter

                    If ($Showlines) { Write-Host $Line }
                } Else {
                    # Only one storage
                    $RepoPath = $y.repository
                    $Lastid = $y.id
                    $Storages = 1

                    #If (!$RepoPath)     {$RepoPath = "<$($_.Name)>" }

                    #$Line = "   {0,-10} {1,-20} {2,-20} " -F $_.Name, $Lastid, $Lastrep
                    $Line = $Header -F $_.Name, $Lastid, $RepoPath, $Storages, $RepoFilter
                    If ($Showlines) { Write-Host $Line }
                }

                $BackupSet = @{
                    FullName = $_.FullName
                    Name = $_.Name
                    Lastid = $Lastid
                    RepoPath = $RepoPath
                    Storages = $Storages
                    RepoFilter = $RepoFilter
                    RepoVariation = $RepoVariation
                    IDVariation = $IDVariation
                }

            } Else {
                # Not initialized:
                #$Line = "   {0,-10} {1,-20} {2,-20} " -F $_.Name, "(none)", "Manage/Init to configure"
                $Line = $Header -F $_.Name, "(none)", "<Manage/Init to configure>", 0, ""
                If ($Showlines) { Write-Host $Line }

                $BackupSet = @{
                    FullName = $_.FullName
                    Name = $_.Name
                    Lastid = ""
                    RepoPath = ""
                    Storages = 0
                    RepoFilter = ""
                    RepoVariation = $RepoVariation
                    IDVariation = $IDVariation
                }

            }

            # Return full name to the dialog list:
            #$_.FullName

            # Return details to the list:
            [pscustomobject]$BackupSet
        }
    }
    #$host.ui.rawui.ForegroundColor = $color.Text.f
    #$host.ui.rawui.BackgroundColor = $color.Text.b
    
}

<#
Function Get-RepositoryList_XXXX {
    Param ( 
        [String]$SettingsPath,
        [switch]$Showlines
    )

    $host.ui.rawui.ForegroundColor = $color.List.f
    $host.ui.rawui.BackgroundColor = $color.List.b
    
    $Header = "   {0,-20} {1,-20} {2,-30} {3,-3} {4,-3}"
    
    If ($Showlines) {Write-Host ($Header -F "Name", "ID", "Backup Folder", "Strg", "Filter")}

    Get-ChildItem $SettingsPath | ForEach-Object {
        If ($_.Attributes -match 'Directory' ) {
            If ($_.Name -match ".DucyBackup") { Return }

            $BackupSet = @{}

            $RepoFilter = ""
            If (Test-Path "$($_.fullname)\.Duplicacy\filters") {
                #Write-host "`nFilter: (partial)"
                #get-content "$RepoPath\.Duplicacy\filters" -TotalCount 5
                $RepoFilter = "Yes"
            }



            $y = Read-Preferences $_.FullName
            $RepoVariation = $false
            $IDVariation = $false
            $Lastrep = ""
            $RepoID  = ""
            If ($y) {
                If ($y.gettype().basetype.name -eq "Array") {
                    $Storages = $y.count
                    $Lastrep = $y[0].repository
                    $Lastid = $y[0].id
                    $RepoPath = ""
                    $RepoVariation = $false
                    $IDVariation   = $false
                    ForEach ($Item in $y) {
                        If ($Lastrep) {$RepoPath = $Lastrep}
                        If ($Lastrep -ne $Item.repository) {$RepoVariation = $true}
                        If ($Lastid  -ne $Item.id)         {$IDVariation   = $true}
                    }
                    If ($RepoVariation) {$Lastrep = "$Lastrep?" }
                    If ($IDVariation)   {$RepoId = "$Lastid?" }
                    If (!$RepoPath)     {$RepoPath = "<$($_.Name)>" }

                    $Line = $Header -F $_.Name, $Lastid, $RepoPath, $Storages, $RepoFilter
                    If ($Showlines) { Write-Host $Line }
                } Else {
                    # Only one storage
                    $Lastrep = $y.repository
                    $Lastid = $y.id

                    If (!$Lastrep)     {$Lastrep = "<$($_.Name)>" }

                    #$Line = "   {0,-10} {1,-20} {2,-20} " -F $_.Name, $Lastid, $Lastrep
                    $Line = $Header -F $_.Name, $Lastid, $Lastrep, 1, $RepoFilter
                    If ($Showlines) { Write-Host $Line }
                }
            } Else {
                # Not initialized:
                #$Line = "   {0,-10} {1,-20} {2,-20} " -F $_.Name, "(none)", "Manage/Init to configure"
                $Line = $Header -F $_.Name, "(none)", "<Manage/Init to configure>", 0, ""
                If ($Showlines) { Write-Host $Line }
            }

            # Return full name to the dialog list:
            $_.FullName
        }
    }
    $host.ui.rawui.ForegroundColor = $color.Text.f
    $host.ui.rawui.BackgroundColor = $color.Text.b
    
}
#>


<#
Function Show-Repository {
    Param (
        [String]$RepoPath,
        [String]$Exclude
         #,
       # [int]$CurrentStorage,
       # [Switch]$Focus
    )
    
    $host.ui.rawui.ForegroundColor = $color.List.f
    $host.ui.rawui.BackgroundColor = $color.List.b

    # Show details of selected repository
    # Both symlinks with target and some details of Duplicacy settings

    $RepoTargets = 0

    If (!(Test-Path "$RepoPath\.Duplicacy")) {
        Write-host "Repository not initialized. Init to prepare" -ForegroundColor Red
    } Else {
        If (Test-Path "$RepoPath\.Duplicacy\Preferences") {
            # Read preference file for this repository
            $y = Read-Preferences $RepoPath -Exclude $Exclude
            $RepoVariation = $false

            If ($y.count -gt 0) {
                $Last = $y[0].repository
                # Loop through the storages, check if they have a repository specified
                ForEach ($Item in $y) {
                    If ($Last -ne $Item.repository) { $RepoVariation = $true }
                    If ($Item.repository) { $RepoTargets++ }
                }

                $StorageFormat = "   {0,-8} {1,-10} {2,-20} {3,-50} {4,-10} {5,-10}"
                $StorageFormat -F "Name", "ID", "Backup Folder", "Storage", "Encrypted", "PwdStored"
                $n = 0
                $MissingPwd = $false
                foreach ($Item in $y) {
                    $Line = $StorageFormat -F $Item.name, $Item.id, $Item.repository, $Item.storage, $Item.encrypted, $Item.PasswordStored
                    
                    If ($Item.encrypted -and !$Item.PasswordStored) {$MissingPwd = $True}
                    write-host $Line  # -ForegroundColor Black -BackgroundColor White
                }
                If ($MissingPwd) {
                    Write-Host "Storages without stored password need manual intervention for backup etc. Try List to store`nIf you assigned a blank encryption key you could try to edit the repository Preferences and set 'encryption' to 'false'" -ForegroundColor Red
                }
            }
        }

    }

    If ($RepoTargets -eq 0) {
        Write-Host "No repository target specified. Local backup; follow Symlinks and backup subdirectories" -ForegroundColor Red
    }
    If ($RepoTargets -gt 1 -and $RepoVariation) {
        Write-Host "Note that there are variations in repositories referenced in these storages." -ForegroundColor Red
        Write-Host "Recommend advanced mode to see individual storage settings." -ForegroundColor Red
    }

    # If (Test-Path "$RepoPath\.Duplicacy\filters") {
    #    Write-host "`nFilter: (partial)"
    #    get-content "$RepoPath\.Duplicacy\filters" -TotalCount 5
    #}

    $host.ui.rawui.ForegroundColor = $color.Text.f
    $host.ui.rawui.BackgroundColor = $color.Text.b
    # write-host "End of list __" -NoNewline
}
#>


# https://stackoverflow.com/questions/26593200/listen-for-a-key-press-with-powershell-but-dont-wait-for-it


Function ReadKey {
    If ($Host.name -like "consolehost") {
        If ([console]::KeyAvailable) {
            [System.Console]::ReadKey(1)
        } Else {
            sleep -Milliseconds 100
            return $null
        }
    } Else {
        # Write-host "(Only console supports readkey, trying read-host here)"
        $Input = Read-host "( '-' to simulate Escape, blank for Enter)"
        Switch ($Input) {
            '' {
                @{ 'KeyChar' = ''
                   'Key'     = 'Enter' }
            }
            
            '-' {
                @{ 'KeyChar' = ''
                   'Key'     = 'Escape' }
            }
            
            Default {
                @{ 'KeyChar' = [Char]$Input[0]
                   'Key'     = $Input.ToUpper()[0] }
            }
        }
    }
}

<#
PS C:\SWSetup\Backup\MS-Test> cmd /c dir
 Volume in drive C is PCL1938 Local Disk
 Volume Serial Number is 94B7-D686

 Directory of C:\SWSetup\Backup\MS-Test

17.10.2019  21:22    <DIR>          .
17.10.2019  21:22    <DIR>          ..
17.10.2019  21:22    <SYMLINKD>     easeus_tb_cloud [C:\easeus_tb_cloud]
13.10.2019  22:24    <SYMLINKD>     ExtremeGraphics [C:\Intel\ExtremeGraphics]
15.10.2019  23:03    <SYMLINKD>     Logs [C:\Intel\Logs]
               0 File(s)              0 bytes
               5 Dir(s)  61�763�751�936 bytes free
PS C:\SWSetup\Backup\MS-Test>
    $message = 'My Name is Kevin and my SSN is 123-45-6789.'
    if($message -match 'My Name is (?<Name>.+) and my SSN is (?<SSN>\d\d\d-\d\d-\d\d\d\d)\.')
    {
        $Matches.Name
        $Matches.SSN
    }
#>


Function Get-DirectoryItems {
    Param (
        [String]$Path
    )
    $List = @()
    C:
    
    cmd.exe /c dir $Path | Where-Object {
        $Record = ''
        if ($_ -match '(?<Date>[0-9./]+) +(?<Time>[0-9:.]+) +<(?<Type>.+)> +(?<Name>.+) \[(?<Target>.+)\]' ) {
            # Match symlink (with target)
            $Record = $matches            
        } ElseIf ($_ -match '(?<Date>[0-9./]+) +(?<Time>[0-9:.]+) +<(?<Type>.+)> +(?<Name>.+)' ) {
            # Matches item (without target)
            $Record = $matches
        } ElseIf ($_ -match '(?<Date>[0-9./]+) +(?<Time>[0-9:.]+) +(?<Size>[0-9]+) +(?<Name>.+)' ) {
            # Matches other items (size and file name)
            $Record = $matches
            $Record.Type = "FILE" 
        }
        
        # If ($Record.Name -and $Record.Name -notmatch '^\.+|^\.Duplicacy' -and $Record.Type -match '^DIR|^SYMLINKD') { $List += $Record }
        If ($Record.Name -and $Record.Name -notmatch '^\.+|^\.Duplicacy') { $List += $Record }
    }
    If ($List) {
        Write-Host "Repository items:"
        $List | ForEach-Object {
            "       {0,-20}   {1,-20}   {2,-20}" -F  $_.Name, $_.Type, $_.Target
            $x = 1
        } 
    }
}




# BlockName is a scriptblock to run
# InputString is ;-separated list of arguments
# If session is not elevated, try to run script elevated
# E.g.:
# Run-Elevated Create_SymLink "$Repo;$Name;$Target"
Function Run-Elevated {
    Param (
        [String]$BlockName,   # $BlockName
        [String]$InputString
        #[String[]]$Arguments
    )

    #https://www.jonathanmedd.net/2014/01/testing-for-admin-privileges-in-powershell.html
    If (!([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
        Write-Warning "This command requires elevation"
        
        If ($PSCommandPath[0] -eq "\") {
            Write-Warning "Script is on a network share."
            Write-Warning "Make sure the account you select for elevation has read access to:"
            Write-Warning "  $PSCommandPath"
            read-host "Enter to continue"
        }
        
        "Script:     '$PSCommandPath'"
        "Command:    '$BlockName'"
        "Parameters: `"$InputString`""
        
        #sleep -Seconds 3
        # Start-Process -nonewwindow -FilePath "powershell.exe" -Wait  -Verb "Runas" -ArgumentList "`"$PSCommandPath`"", "Create-SymlinkD", "`"$Path`"", "`"$Name`"", "`"$Target`"" 
        #Set-PSDebug -Step
        # "-noexit", 

        $ArgumentList = @("-nologo", "-noprofile", "-Executionpolicy", "Bypass", "-File", "`"$PSCommandPath`"", "-command", "Run-Elevated", "-BlockName", $BlockName, "-InputString", "`"$InputString`"")
        
        If ($Script:Debug) {
            $ArgumentList = @("-NoExit") + $ArgumentList + @("-Debug")
            Set-PSDebug -Step
        }

        #$ArgumentList += "-BlockName", $BlockName, "-InputString", $InputString
               
        Write-Host "Argument-list: $ArgumentList"

        # $y = Start-Process -FilePath "powershell.exe" -Verb "Runas" -ArgumentList $ArgumentList
        sleep -Seconds 2
        If ($Script:Debug) {
            read-host -Prompt "Enter to contiue execute"
            Set-PSDebug -Step    
        }

        # Causes "You cannot call a method on a null-valued expression.":
        $Process = Start-Process -FilePath "powershell.exe" -Verb "Runas" -ArgumentList $ArgumentList -wait
        
        # (Start-Process -FilePath "powershell.exe" -Verb "Runas" -ArgumentList $ArgumentList).waitforexit()

        If ($Process) {$Process.waitforexit()}

        # sleep -Seconds 2

        If ($Script:Debug) {
            read-host -Prompt "Enter to contiue"
            Set-PSDebug -Step
        }
        
        # "-command", "Create-SymlinkD", "-Path", "`"$Path`"", "-Name", "`"$Name`"", "-Target", "`"$Target`"" )
        
    } Else {

        Write-Host "Running elevated block $BlockName"
        write-host "InputString: $InputString"


        # Get the scriptblock specified:
        Try { $ScriptBlock = Get-Variable $BlockName -Value }
        Catch {
            Write-Warning "Scriptblock variable not found: $BlockName"
            sleep -Seconds 10
            Exit 1
        }
        
        If ($ScriptBlock) {
            Try {
                Invoke-Command $ScriptBlock -ArgumentList ($InputString -split ";")
            }
            Catch {
                Write-Warning "Error in executing $BlockName"
                sleep -Seconds 10
                Exit 1
            }
        }
    } 
}

# Run-Elevated Create-SymlinkD "$Path;$Name;$Target;$Force"
$Create_SymLink = {
    Param (
        [String]$Path,
        [String]$Name,
        [String]$Target,
        [switch]$Force
    )


    If (!(Test-IsAdmin)) {
        Write-Warning "This command requires elevation, exits"
        sleep -Seconds 1 
        exit $LASTEXITCODE
    }

    If (!(Test-Path "$Path")) {
        Write-Warning "Folder does not exist: $Path, exits"
        exit 1        
    }

    If (Test-Path "$Path\$Name") {
        If (!$Force) {
            Write-Warning "Symlink already exist, exits. (-Force to override)"
            exit 1
        } Else {
            Remove-Item "$Path\$Name" -Force
        }
    }

    # Win10:    
    # New-Item -ItemType SymbolicLink -Path $Path -Name $Name -Value $NewTarget
    
    # This works in Win7 and Win10:
    cmd.exe /c mklink /D "`"$Path\$Name`""  "`"$Target`""   
    If ($LASTEXITCODE -ne 0) {
        Write-Warning "Exit code: $LASTEXITCODE"
        #sleep -Seconds 2
    }
    
    If ($Debug) {
        Read-Host -Prompt "Result of Create Symlink: $LASTEXITCODE. Enter to continue"
    }
    
    Return $LASTEXITCODE
}



Function Get_Storage {
    Param (
        [String]$Path,
        [String]$Exclude
    )

    $PrefFile = "$Path\.Duplicacy\Preferences"

    If ((Test-Path $PrefFile)) {
        $x = Get-Content $PrefFile
        $StorageArray = ConvertFrom-Json20 $x
        If ($Exclude) {
            $StorageArray = $StorageArray | Where-Object {$_.name -notlike $Exclude}
        }
        # Produces PSCustomObject, not hashtable:
        #$StorageArray = $x | ConvertFrom-Json
    } Else {
        #$StorageArray = @{
        #}
    }
    
    # Check if encryption password stored
    #    '"LocalStorage_password":'   
    If (Test-Path "$Path\.Duplicacy\keyring") {
        $keyring = Get-Content "$Path\.Duplicacy\keyring"
    } Else {$keyring = ""} 

    foreach ($Item in $StorageArray) {
        $Name = "`"password`""
        If ($Item.name -notlike "default") {$Name = "`"$($Item.name)_password`""}
        If ($keyring -match $Name) {
            $Item.PasswordStored = "Yes"
        }

        $Line = @{}
        $Item.Keys | Where-Object {$_ -ne 'Keys'}|  ForEach-Object {
            #Write-host "Key: $_"
            $Line.$_ = "$($Item.$_)"
        }
        [psCustomObject]$Line
    }    
}







# https://stackoverflow.com/questions/28077854/powershell-2-0-convertfrom-json-and-convertto-json-implementation
# To support PS2... But this returns hashtable, not pscustomobjects...
function ConvertTo-Json20([object] $item){
    add-type -assembly system.web.extensions
    $ps_js=new-object system.web.script.serialization.javascriptSerializer
    return $ps_js.Serialize($item)
}

function ConvertFrom-Json20([object] $item){ 
    add-type -assembly system.web.extensions
    $ps_js=new-object system.web.script.serialization.javascriptSerializer
    #The comma operator is the array construction operator in PowerShell
    return @($ps_js.DeserializeObject($item))
}


Function Set-ConsoleSize {
    <#
    .Synopsis
    Set the size of the current console window

    .Description
    Set-ConsoleSize sets or resets the size of the current console window. By default, it
    sets the window to a height of 40 lines, with a 2000 line buffer, and sets the 
    the width and width buffer to 120 characters. 

    .Example
    Restore the console window to 40h x 120w:
    Set-ConsoleSize

    .Example
    Change the current console to a height = 30 lines and a width = 180 chars:
    Set-ConsoleSize -Height 30 -Width 180

    .Parameter Height
    The number of lines to which to set the current console. Default = 40 lines. 

    .Parameter Width
    The number of characters to which to set the current console. Default = 120 chars.

    .Inputs
    [int]
    [int]

    .Notes
        Author: ss64.com/ps/syntax-consolesize.html
     Last edit: 2019-08-29
    #>
    [CmdletBinding()]
    Param(
         [Parameter(Mandatory=$False,Position=0)]
         [int]$Height = 40,
         [Parameter(Mandatory=$False,Position=1)]
         [int]$Width = 120,
         [int]$BufferHeight = 9000
         )

    If ($ISEHost) { Return }


    $console = $host.ui.rawui
    $ConBuffer  = $console.BufferSize
    $ConSize = $console.WindowSize

    $currWidth = $ConSize.Width
    $currHeight = $ConSize.Height

    # if height is too large, set to max allowed size
    if ($Height -gt $host.UI.RawUI.MaxPhysicalWindowSize.Height) {
        $Height = $host.UI.RawUI.MaxPhysicalWindowSize.Height
    }

    # if width is too large, set to max allowed size
    if ($Width -gt $host.UI.RawUI.MaxPhysicalWindowSize.Width) {
        $Width = $host.UI.RawUI.MaxPhysicalWindowSize.Width
    }

    # If the Buffer is wider than the new console setting, first reduce the width
    If ($ConBuffer.Width -gt $Width ) {
       $currWidth = $Width
    }
    # If the Buffer is higher than the new console setting, first reduce the height
    If ($ConBuffer.Height -gt $Height ) {
        $currHeight = $Height
    }
    # initial resizing if needed
    $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.size($currWidth,$currHeight)

    # Set the Buffer
    $host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.size($Width,$BufferHeight)

    # Now set the WindowSize
    $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.size($Width,$Height)

    # Display result
    # "Height: " + $host.ui.rawui.WindowSize.Height
    # "Width:  " + $host.ui.rawui.WindowSize.width
}




$Icon = @"

      ____   
     /\_\_\  
    /\/\_\_\ 
    \/\/_/_/ 
     \/_/_/ DucyBackup
"@

$SmallIcon = @"
     /\_\ DucyBackup
     \/_/ 
"@

$SmallIcon = @"
     \/_/ DucyBackup
"@

$SmallIcon = @"
    \/\/_/_/ 
     \/_/_/  
"@
# DucyBackup

<#
Write-Host "Command: $Command"
write-host "Path: $Path"
Write-Host "Name: $Name"
Write-Host "Target: $Target"
Write-Host "Selectroot: $SelectRoot"
Write-Host "(Interactive) $Interactive"
Write-Host "Duplicacypath $DuplicacyPath"
Write-Host "Force: $Force"
#>

# F3: 
Function Show-Anchors {
    @(
        "MainTop",
        "AskDialogStart",
        "AskDialogTop",
        "AskDialogListPos",
        "AskFirstChoice",
        "AskDialogPromptLine",
        "AskDialogInput"#,
        #"InputCursor"
    ) | ForEach-Object {
        Try {
            $Var = Get-Variable $_
            $host.UI.RawUI.CursorPosition = $Var.Value
            Write-Host "#-$($var.Name)  " -ForegroundColor Red # -BackgroundColor Cyan
            sleep -Milliseconds 300; $host.UI.RawUI.CursorPosition = $Var.Value
            Write-Host "#-$($var.Name)  " -ForegroundColor Yellow # -BackgroundColor Cyan
            sleep 0.3
        }
        Catch {}
    }    
}



Function Execute-DCjob {
    <#
        .SYNOPSIS
            Execute backup job with actions
            When a job has completed succesfully, optionally send a signal to healthchecks.io
        .PARAMETER Path
            Path to the repository path. 
            The job settings is in the subfolder .Duplicacy\Jobs.json
        .PARAMETER Job
            Name of the job to execute
    #>

    Param (
        [Parameter(Mandatory=$true)]
        [String]$Path,  # Path to repository
        [Parameter(Mandatory=$true)]
        [String]$Job    # Name of a job for this repository
    )

    $Settings = Get-RegistrySettings "$AppKey\Settings"

    If (!($DuplicacyPath = FindDuplicacyPath)) {
        # FindDuplicacyPath will exit, this is just for clarity 
        Write-Host "Could not find Duplicacy.exe" -ForegroundColor Red
        Exit 1
    }
    
    $ThisJob = Get-DCJob -Path $Path | Where-Object Name -like $Job
    # name,actions,arguments,fields,report
    # actions contains some more settings/report

    If (!$ThisJob) { exit }

    $ThisJob.Actions | sort Order | ForEach-Object  {
        Write-host "$($_.Order): Action name: $($_.Name)"
        If ($_.Fields.Command) {
            Write-host "  Command: $($_.Fields.Command)"
            # Do command and write to log
            StartCommand -FilePath $Settings.DuplicacyPath -WorkingDirectory $Path -ArgumentList $_.Arguments
            $R = $LASTEXITCODE
            If ($R -gt 0) {
                # Error

                # If HTTPReportFailURL
                # healthchecks.io fail?
                # Abort job on error? "StopOnError"
                # Return @{Cancel = $true; Reason = "$command failed with error: $R"; Result = "Error"}
                If ($_.ActionSettings.HTTP_TEXT_ERROR) {
                    Invoke-RestMethod  -Uri $_.ActionSettings.HTTP_TEXT_ERROR `
                        -method POST
                }

                IF ($_.ActionSettings.StopOnError) {
                    Return @{Cancel = $true; Reason = "$command failed with error: $R"; Result = "Error"}
                }
                
            }
        
            If ($_.Fields.Command -match '^Backup$|^prune$' -and $_.Fields.Storage) {
                UpdateListLog -Main $Settings.SettingsPath -StorageName $_.Fields.Storage -Repository $Path -DuplicacyPath $Settings.DuplicacyPath
            }

            # healthchecks.io success
            # Store results?
            # Return @{OK = $true; Result = "OK"}
            If ($_.ActionSettings.HTTP_TEXT) {
                # Windows 10: Send healtcheck signal with log file
                # https://hc-ping.com/your-check-url
                #If ($_.ActionSettings.HTTP_TEXT -match "https?://[-a-z0-9._]+/[-/a-z0-9]+") {
                    Invoke-RestMethod  -Uri $_.ActionSettings.HTTP_TEXT `
                        -method POST
                    # -headers @{'User-Agent'='%Computername% %Stats%'} `
                    # -Infile '%Log_Stats%'
                #}
            }


        }
    }
}


Switch ($Command) {
    # Not in use now...
    'Create-SymlinkD' {
        #Write-host "Create-SymlinkD -Path $Path -Name $Name -Target $Target -Force:$Force"
        $x = Create-SymlinkD -Path $Path -Name $Name -Target $Target -Force:$Force
        # sleep -Seconds 2
        Exit $x
    }

    # Run a scheduled job
    # Read details from a task file, send info to healthchecks if configured.
    'Job' {
        # execute scheduled job/actions.
        write-host "Starting job '$Job' in Repository: $Job"
        "$(Get-Date -Format s)`tTask: $Job`tRepository: $Path" | Out-File -FilePath "$($Env:TEMP)\Tasktest.txt" -Append
        
        # 
        Execute-DCjob -path $Path -Job $Job
    }

    'Run-Elevated' {
        Run-Elevated -BlockName $BlockName -InputString $InputString
    }
    
    Default {
        Main
    }
}


